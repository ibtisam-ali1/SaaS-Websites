# Security Policy

## Security Posture & Safeguards

InsightAI is engineered with enterprise-grade security standards and zero-trust design principles.

### Key Protections
1. **Zero Hardcoded Secrets**: 
   - No API keys, secret tokens, private keys, or credentials are hardcoded in any component, script, or configuration file.
   - All environment variables are segregated and loaded exclusively via `.env` (which is strictly ignored by `.gitignore`).
   - `.env.example` contains only sanitized variable templates.
2. **Client-Side Data Sanitization**:
   - The interactive telemetry and demo data feeds utilize sanitized, synthetic enterprise datasets. No proprietary customer PII (Personally Identifiable Information) is exposed in client-side bundles.
3. **Safe Third-Party Integrations**:
   - All AI interactions and API services communicate through secure channels, and sensitive API keys are kept strictly server-side.
4. **Browser Security & Permissions**:
   - Web Speech API and synthesis operate entirely client-side within the local browser runtime—audio synthesis does not stream sensitive dashboard numbers to third-party recording servers.

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

## Reporting a Vulnerability

If you discover a security vulnerability within this repository, please report it responsibly:
- Email: `security@insightai-platform.internal` (or reach out directly through your enterprise account representative).
- Please provide detailed steps to reproduce the issue.
- Responsible disclosure reports will receive an acknowledgment within 24 hours and a prompt security patch.
