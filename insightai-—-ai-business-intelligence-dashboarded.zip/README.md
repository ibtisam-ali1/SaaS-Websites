# InsightAI - Enterprise AI Analytics & Intelligence

[![TypeScript](https://img.shields.io/badge/TypeScript-5.8-blue.svg)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/React-19.0-61dafb.svg)](https://react.dev/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4.1-38bdf8.svg)](https://tailwindcss.com/)
[![Vite](https://img.shields.io/badge/Vite-6.2-646cff.svg)](https://vitejs.dev/)
[![Security](https://img.shields.io/badge/Security-200%25_Safe-emerald.svg)](./SECURITY.md)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](./LICENSE)

**InsightAI** is an executive-grade Business Intelligence & Analytics platform engineered to turn complex business metrics into actionable, high-velocity corporate decisions. Built with React 19, TypeScript, and Tailwind CSS.

---

## 🚀 Key Features

### 1. 🧠 Executive "What-If" AI Scenario Simulator & Sandbox
- **Dynamic Parametric Levers**: Real-time simulation sliders for Enterprise Expansion, Pricing Shifts, Marketing CAC Efficiency, AI Copilot Adoption, and Churn Reduction.
- **Instant Financial Projections**: Live recalculation of projected ARR ($1.78M base up to $2.8M+), Net Revenue Retention (NRR), Cash Runway (months), and Rule of 40 score.
- **Monte Carlo Stochastic Forecasting**: 12-month forward predictive curve with P90 (Bull), P50 (Base), and P10 (Bear) statistical confidence intervals.
- **Dynamic AI Synthesis**: Situational narrative analysis generated on-the-fly based on slider configurations.
- **One-Click Target Commit**: Commit scenario models to active quarterly operating plans or export to PDF/Excel.

### 2. 🎙️ Autonomous Executive Audio Dispatch
- **60-Second In-Browser Audio Briefing**: Browser-native voice synthesis summarizing revenue acceleration, diurnal peak traffic windows, and proactive retention actions.
- **Interactive Controls**: Play, Pause, Scrub, Waveform visualization, Audio speed toggle (1x, 1.25x, 1.5x), and synchronized sentence transcript highlighting.
- **100% Private & Safe**: Operates directly in the browser's Web Speech API—no external audio streaming or credential exposure.

### 3. ⚡ Real-Time Live Telemetry Event Ingestion Feed
- **Live Event Bus**: Incoming high-velocity micro-events (Enterprise payments, query burst spikes, churn warnings, SOC2 audit verifications).
- **Interactive Stream**: Live / Pause toggle, frequency speed selector (1x, 2x, 5x), and severity filters (Revenue, Risks, All).
- **Inspection Modal**: Click any incoming event to inspect JSON payload and trigger automated workflows.

### 4. 📊 Core Performance & Diurnal Analytics
- **Executive KPIs**: Real-time ARR, MRR, Gross Margin, Retention Rate, and Active Logos with interactive sparklines.
- **Diurnal Traffic Intelligence**: Visual hourly heatmap highlighting the daily 6:00 PM – 9:00 PM enterprise query concurrency burst window.
- **Funnel Conversion & Churn Radar**: Multi-stage conversion attribution, traffic sources breakdown, and customer health risk segmentation.

### 5. 🛠️ Comprehensive Management Views
- **Customer Directory**: Enterprise, Mid-Market, and SMB cohort management with segment update drawers.
- **Sales & Product Performance**: SKU velocity matrix, margin tracking, and inventory status.
- **Scheduled & Custom Reports**: Instant generation of PDF, CSV, Excel, and JSON reports with real-time download feedback.
- **Universal Command Palette (`Cmd+K` / `Ctrl+K`)**: Rapid keyboard navigation across pages, metrics, customers, and system settings.
- **Adaptive Dark / Light Themes**: Accessible, high-contrast visual themes with smooth transitions.

---

## 🛠️ Tech Stack

- **Framework**: React 19 (SPA)
- **Language**: TypeScript 5.8
- **Styling**: Tailwind CSS 4.1
- **Icons**: Lucide React
- **Build Tool**: Vite 6.2
- **Audio Synthesis**: Native Web Speech API

---

## 💻 Local Development Setup

### Prerequisites
- Node.js 18+ or 20+
- npm, yarn, or pnpm

### Quickstart
```bash
# 1. Clone your repository
git clone https://github.com/YOUR_USERNAME/insight-ai-analytics.git
cd insight-ai-analytics

# 2. Install dependencies
npm install

# 3. Start local development server
npm run dev
```

Visit `http://localhost:3000` (or the port specified in terminal) to view the live app.

### Production Build
```bash
# Compile and package for production
npm run build

# Preview production build locally
npm run preview
```

---

## 🔒 200% Safety & Security Audit (Safe for GitHub & Client Sharing)

This codebase has undergone a complete security check:
1. **Zero Secret Leaks**: Verified zero hardcoded API keys, private tokens, passwords, or personal credentials.
2. **Safe `.gitignore` Configuration**: Automatically ignores `.env`, `.env.local`, `.env.*.local`, `node_modules`, build artifacts (`dist/`), OS files (`.DS_Store`), and logs.
3. **Client-Side Data Privacy**: All telemetry, customer accounts, and financial metrics utilize sanitized synthetic datasets. No proprietary customer PII is bundled.
4. **Isolated Environment Variables**: Only public variables are prefixed with `VITE_`. All sensitive keys remain server-side and are loaded strictly from untracked `.env` files.

---

## 📤 Step-by-Step Guide: Publishing to GitHub

Follow these simple steps in your terminal to publish this project to GitHub:

### Step 1: Initialize Git in your project
```bash
git init
```

### Step 2: Stage and review all files
```bash
git add .
git status
```
*(Notice that `node_modules/`, `dist/`, and any private `.env` files are automatically excluded by `.gitignore`)*

### Step 3: Create initial commit
```bash
git commit -m "feat: initial release of InsightAI analytics platform with What-If simulator and live telemetry"
```

### Step 4: Create a repository on GitHub
1. Go to [github.com/new](https://github.com/new).
2. Enter a repository name (e.g. `insightai-platform` or `enterprise-ai-analytics`).
3. Choose **Private** (recommended for proprietary client projects) or **Public**.
4. **Do NOT** check "Add a README file" or "Add .gitignore" (we already have pristine files ready).
5. Click **Create repository**.

### Step 5: Link your remote and push
```bash
# Set primary branch to main
git branch -M main

# Add your GitHub repository remote (replace with your repo URL)
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git

# Push the codebase
git push -u origin main
```

---

## 🤝 How to Safely Share with Your Client

### Option A: Share the Live Application (Fastest & Most Impressive)
Share your deployed application link directly with your client:
- **Client Experience**: The client can open the URL in any modern browser on desktop, tablet, or mobile.
- **Safety**: The client interacts with the compiled production bundle. They cannot see your source code, Git history, or local machine environment.

### Option B: Invite Client to Private GitHub Repository
If the client requested code delivery:
1. Navigate to your GitHub repository.
2. Go to **Settings** > **Collaborators** > **Add people**.
3. Enter your client's GitHub username or email address.
4. Select **Read** permissions (for review) or **Write** (if they are co-developing).
5. The client will receive an invitation email and can safely clone or download the ZIP.

### Option C: Deliver Clean ZIP Archive
If the client prefers a standalone package:
1. Run `git archive -o client-delivery.zip HEAD` (this generates a pristine ZIP containing only versioned source files, without `node_modules` or `.git`).
2. Deliver the archive via secure email or cloud storage.

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](./LICENSE) file for details.
