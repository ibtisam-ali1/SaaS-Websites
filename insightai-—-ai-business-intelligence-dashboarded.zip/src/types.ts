export type NavigationTab = 
  | 'landing' 
  | 'overview' 
  | 'analytics' 
  | 'insights' 
  | 'simulator'
  | 'reports' 
  | 'customers' 
  | 'sales' 
  | 'settings';

export type TimeRange = 'today' | '7d' | '30d' | '90d' | 'year' | 'custom';

export type ThemeMode = 'dark' | 'light';

export interface MetricCardData {
  id: string;
  title: string;
  value: string;
  numericValue: number;
  changePercent: number;
  changeType: 'positive' | 'negative' | 'neutral';
  comparisonPeriod: string;
  sparklineData: number[];
  prefix?: string;
  suffix?: string;
  sublabel?: string;
}

export interface RevenueDataPoint {
  date: string;
  revenue: number;
  previousRevenue: number;
  target: number;
  orders: number;
}

export interface CategorySalesData {
  id: string;
  category: string;
  revenue: number;
  percentage: number;
  growth: number;
  color: string;
}

export interface CustomerGrowthPoint {
  period: string;
  newCustomers: number;
  returningCustomers: number;
  churnedCustomers: number;
}

export interface FunnelStage {
  stage: string;
  count: number;
  percentage: number;
  conversionFromPrevious: number;
  dropoffRate: number;
}

export interface TrafficSource {
  source: string;
  visitors: number;
  percentage: number;
  conversionRate: number;
  revenue: number;
  trend: number;
}

export type PriorityLevel = 'critical' | 'high' | 'medium' | 'low';
export type InsightCategory = 'Revenue' | 'Retention' | 'Marketing' | 'Product' | 'Operations';

export interface AiInsightItem {
  id: string;
  title: string;
  summary: string;
  priority: PriorityLevel;
  category: InsightCategory;
  impact: string;
  impactValue: number;
  date: string;
  details: string;
  actionLabel: string;
  applied?: boolean;
  metricsAffected: string[];
  simulationData?: {
    current: number;
    projected: number;
    difference: string;
  };
}

export interface ReportItem {
  id: string;
  title: string;
  description: string;
  category: 'Sales' | 'Customer' | 'Revenue' | 'Marketing' | 'Executive';
  schedule: string;
  lastGenerated: string;
  fileSize: string;
  format: 'PDF' | 'CSV' | 'XLSX';
  downloadsCount: number;
  status: 'Ready' | 'Generating' | 'Scheduled';
}

export interface CustomerItem {
  id: string;
  name: string;
  email: string;
  avatar: string;
  company: string;
  orders: number;
  revenue: number;
  lastActivity: string;
  segment: 'Enterprise' | 'Mid-Market' | 'SMB' | 'Startup' | 'At-Risk';
  status: 'Active' | 'Churn-Risk' | 'New' | 'VIP';
  location: string;
  joinDate: string;
  npsScore: number;
}

export interface ProductPerformanceItem {
  id: string;
  name: string;
  sku: string;
  category: string;
  unitsSold: number;
  revenue: number;
  growth: number;
  margin: number;
  refundRate: number;
  status: 'High Growth' | 'Stable' | 'Needs Review' | 'Flagship';
}

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type: 'success' | 'info' | 'warning' | 'error';
  timestamp?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'info' | 'warning' | 'success' | 'critical';
  category: 'ai' | 'system' | 'alert' | 'report';
}

export interface UserSettings {
  profile: {
    fullName: string;
    email: string;
    role: string;
    avatarUrl: string;
    timezone: string;
    twoFactorEnabled: boolean;
  };
  business: {
    companyName: string;
    taxId: string;
    currency: string;
    fiscalYearStart: string;
    industry: string;
  };
  notifications: {
    emailAlerts: boolean;
    aiAnomalyTriggers: boolean;
    weeklyDigest: boolean;
    slackWebhook: boolean;
    desktopPushes: boolean;
  };
  dashboard: {
    defaultTimeRange: TimeRange;
    chartAnimation: boolean;
    compactView: boolean;
    autoRefreshInterval: number; // in seconds, 0 = off
    theme: ThemeMode;
  };
}

export interface TelemetryEvent {
  id: string;
  timestamp: string;
  type: 'purchase' | 'query_spike' | 'churn_risk' | 'expansion' | 'security' | 'anomaly';
  title: string;
  description: string;
  magnitude: string;
  severity: 'normal' | 'info' | 'warning' | 'critical';
  account?: string;
}

export interface ScenarioConfig {
  expansionPercent: number; // -20 to +50
  marketingBudgetPercent: number; // -30 to +60
  pricingAdjustmentPercent: number; // -15 to +35
  churnReductionPercent: number; // 0 to 50
  aiAddonAdoptionPercent: number; // 0 to 100
}

