import React from 'react';
import { X, Mail, Building, MapPin, Calendar, DollarSign, ShoppingBag, Star, ShieldCheck, ArrowUpRight } from 'lucide-react';
import { CustomerItem } from '../../types';

interface CustomerDetailModalProps {
  customer: CustomerItem | null;
  onClose: () => void;
  onUpdateSegment?: (id: string, newSegment: CustomerItem['segment']) => void;
  onTriggerToast?: (msg: string) => void;
}

export const CustomerDetailModal: React.FC<CustomerDetailModalProps> = ({
  customer,
  onClose,
  onUpdateSegment,
  onTriggerToast,
}) => {
  if (!customer) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden z-10 animate-in fade-in-50 zoom-in-95">
        {/* Header with cover glow */}
        <div className="relative h-24 bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 p-4 flex items-start justify-between">
          <span className="text-[10px] font-mono uppercase tracking-widest text-indigo-200 px-2 py-0.5 rounded bg-indigo-950/60 border border-indigo-500/30">
            Account Dossier • {customer.id}
          </span>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/70 hover:text-white hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Profile Card Info */}
        <div className="px-6 pb-6 pt-0 -mt-10">
          <div className="flex items-end justify-between mb-4">
            <div className="relative">
              <img
                src={customer.avatar}
                alt={customer.name}
                className="w-20 h-20 rounded-2xl object-cover ring-4 ring-white dark:ring-slate-900 shadow-xl"
              />
              <span className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (onTriggerToast) onTriggerToast(`Simulated direct message sent to ${customer.email}`);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:border-indigo-500 transition-colors"
              >
                <Mail className="w-3.5 h-3.5 text-indigo-500" />
                <span>Contact</span>
              </button>
            </div>
          </div>

          <div className="space-y-1 mb-4">
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {customer.name}
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-indigo-500/10 text-indigo-500 border border-indigo-500/20">
                {customer.segment}
              </span>
            </div>
            <div className="flex items-center gap-4 text-xs text-slate-400">
              <span className="flex items-center gap-1">
                <Building className="w-3.5 h-3.5" />
                {customer.company}
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" />
                {customer.location}
              </span>
            </div>
          </div>

          {/* Quick Metrics Bento */}
          <div className="grid grid-cols-3 gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-center mb-4">
            <div>
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Total Revenue</div>
              <div className="text-sm font-bold font-mono text-slate-900 dark:text-white mt-0.5">
                ${customer.revenue.toLocaleString()}
              </div>
            </div>
            <div className="border-x border-slate-200 dark:border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Orders</div>
              <div className="text-sm font-bold font-mono text-slate-900 dark:text-white mt-0.5">
                {customer.orders}
              </div>
            </div>
            <div>
              <div className="text-[10px] text-slate-400 uppercase font-semibold">NPS Score</div>
              <div className="text-sm font-bold font-mono text-emerald-500 mt-0.5">
                {customer.npsScore}/10
              </div>
            </div>
          </div>

          {/* Telemetry Details */}
          <div className="space-y-2.5 text-xs text-slate-600 dark:text-slate-300">
            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-100/60 dark:bg-slate-800/40">
              <span className="text-slate-400">Last Telemetry Ping</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">{customer.lastActivity}</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-100/60 dark:bg-slate-800/40">
              <span className="text-slate-400">Customer Since</span>
              <span className="font-mono text-slate-800 dark:text-slate-200">{customer.joinDate}</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-100/60 dark:bg-slate-800/40">
              <span className="text-slate-400">Security Tier</span>
              <span className="flex items-center gap-1 text-indigo-500 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" /> SOC2 Verified
              </span>
            </div>
          </div>

          {/* Segment Management */}
          {onUpdateSegment && (
            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Modify Tier:</span>
              <div className="flex gap-1.5">
                {(['Enterprise', 'Mid-Market', 'SMB'] as const).map((seg) => (
                  <button
                    key={seg}
                    onClick={() => onUpdateSegment(customer.id, seg)}
                    className={`px-2 py-1 rounded-lg text-[10px] font-semibold transition-all ${
                      customer.segment === seg
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {seg}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
