import React, { useState } from 'react';
import { X, Download, FileText, CheckCircle2, FileSpreadsheet, Code2 } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExport?: (format: string, scope: string) => void;
  activeTab?: string;
  onTriggerToast?: (title: string, desc?: string, type?: 'success' | 'info') => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ 
  isOpen, 
  onClose, 
  onExport,
  activeTab,
  onTriggerToast 
}) => {
  const [format, setFormat] = useState<'pdf' | 'csv' | 'xlsx' | 'json'>('pdf');
  const [scope, setScope] = useState<'current_view' | 'full_database' | 'ai_insights'>('current_view');
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  const handleRunExport = () => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      const fmt = format.toUpperCase();
      if (typeof onExport === 'function') {
        onExport(fmt, scope);
      } else if (typeof onTriggerToast === 'function') {
        onTriggerToast(
          `${fmt} Export Generated`,
          `Successfully exported ${scope.replace('_', ' ')} for ${activeTab || 'overview'}.`,
          'success'
        );
      }
      onClose();
    }, 1000);
  };

  const formats = [
    { id: 'pdf' as const, label: 'Boardroom PDF', desc: 'Vector charts, summary KPI cards & executive brief', icon: FileText },
    { id: 'csv' as const, label: 'Raw CSV Stream', desc: 'Normalized tabular dataset for Python / R / Pandas', icon: FileSpreadsheet },
    { id: 'xlsx' as const, label: 'Excel Workbook', desc: 'Pre-formatted formulas, pivot tables & data tabs', icon: FileSpreadsheet },
    { id: 'json' as const, label: 'REST API Payload (JSON)', desc: 'Full serialized schema with metadata & timestamps', icon: Code2 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden z-10 animate-in fade-in-50 zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-500">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Export Enterprise Analytics
              </h3>
              <p className="text-xs text-slate-400">
                Generate compliant reports and raw telemetry data
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Format selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2.5">
              Select Output Format
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {formats.map((f) => {
                const Icon = f.icon;
                const isSelected = format === f.id;
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setFormat(f.id)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'border-indigo-500 bg-indigo-500/10 text-slate-900 dark:text-white ring-1 ring-indigo-500'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <Icon className={`w-4 h-4 ${isSelected ? 'text-indigo-500' : 'text-slate-400'}`} />
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-indigo-500" />}
                    </div>
                    <div className="text-xs font-bold">{f.label}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5 leading-snug">{f.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Scope selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              Data Scope
            </label>
            <div className="space-y-2">
              {[
                { id: 'current_view', label: 'Active View & Applied Date Filters', count: '~1.4 MB' },
                { id: 'full_database', label: 'Comprehensive 12-Month Historical Archive', count: '~18.6 MB' },
                { id: 'ai_insights', label: 'AI Intelligence Models & Recommendation Telemetry', count: '~3.2 MB' },
              ].map((s) => (
                <label
                  key={s.id}
                  className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <input
                      type="radio"
                      name="scope"
                      checked={scope === s.id}
                      onChange={() => setScope(s.id as any)}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="font-medium text-slate-800 dark:text-slate-200">{s.label}</span>
                  </div>
                  <span className="font-mono text-[11px] text-slate-400">{s.count}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <span className="text-[11px] text-slate-400">
            Encrypted with SHA-256
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleRunExport}
              disabled={isExporting}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/25 transition-all disabled:opacity-50"
            >
              {isExporting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Package</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
