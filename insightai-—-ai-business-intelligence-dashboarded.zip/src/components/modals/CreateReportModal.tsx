import React, { useState } from 'react';
import { X, FileText, Plus, Sparkles, Check } from 'lucide-react';
import { ReportItem } from '../../types';

interface CreateReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateReport: (newReport: ReportItem) => void;
}

export const CreateReportModal: React.FC<CreateReportModalProps> = ({
  isOpen,
  onClose,
  onCreateReport,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<'Sales' | 'Customer' | 'Revenue' | 'Marketing' | 'Executive'>('Revenue');
  const [schedule, setSchedule] = useState('Weekly (Every Monday)');
  const [format, setFormat] = useState<'PDF' | 'CSV' | 'XLSX'>('PDF');
  const [includeAi, setIncludeAi] = useState(true);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const report: ReportItem = {
      id: `rep-${Date.now()}`,
      title: title.trim(),
      description: description.trim() || `Automated ${category.toLowerCase()} intelligence audit with executive summary and key metric variance.`,
      category,
      schedule,
      lastGenerated: 'Just now',
      fileSize: format === 'PDF' ? '3.4 MB' : '1.8 MB',
      format,
      downloadsCount: 0,
      status: 'Ready',
    };

    onCreateReport(report);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden z-10 animate-in fade-in-50 zoom-in-95">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-500">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Create Intelligence Report
              </h3>
              <p className="text-xs text-slate-400">
                Configure customized enterprise telemetry and automated dispatch
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Report Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Q3 Pipeline Velocity & Conversion Deep Dive"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="Revenue">Revenue & Growth</option>
                <option value="Sales">Sales & Quotas</option>
                <option value="Customer">Customer & Cohorts</option>
                <option value="Marketing">Marketing Attribution</option>
                <option value="Executive">Executive Board Brief</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Dispatch Schedule
              </label>
              <select
                value={schedule}
                onChange={(e) => setSchedule(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="On-Demand">On-Demand Only</option>
                <option value="Daily (06:00 AM)">Daily (06:00 AM)</option>
                <option value="Weekly (Every Monday)">Weekly (Every Monday)</option>
                <option value="Monthly (1st of Month)">Monthly (1st of Month)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Description / Executive Context
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Outline specific objectives, stakeholders, or key variances to highlight..."
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Format
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['PDF', 'CSV', 'XLSX'] as const).map((fmt) => (
                <button
                  type="button"
                  key={fmt}
                  onClick={() => setFormat(fmt)}
                  className={`p-2.5 rounded-xl border text-xs font-medium text-center transition-all ${
                    format === fmt
                      ? 'border-indigo-500 bg-indigo-500/10 text-indigo-500 font-bold'
                      : 'border-slate-200 dark:border-slate-800 text-slate-500 hover:border-slate-300'
                  }`}
                >
                  {fmt} Document
                </button>
              ))}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-500" />
              <span className="text-xs text-slate-800 dark:text-slate-200 font-medium">
                Include AI Anomaly & Growth Synthesis
              </span>
            </div>
            <input
              type="checkbox"
              checked={includeAi}
              onChange={(e) => setIncludeAi(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 text-xs font-medium text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/20"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Generate & Save Report</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
