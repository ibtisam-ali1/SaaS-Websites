import React, { useState, useRef } from 'react';
import { RevenueDataPoint } from '../../types';

interface AreaChartProps {
  data: RevenueDataPoint[];
  title?: string;
  subtitle?: string;
  showComparison?: boolean;
  valuePrefix?: string;
  height?: number;
}

export const AreaChart: React.FC<AreaChartProps> = ({
  data,
  showComparison = true,
  valuePrefix = '$',
  height = 320,
}) => {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  if (!data || data.length === 0) {
    return (
      <div className="flex h-64 items-center justify-center text-slate-400 text-sm">
        No chart data available
      </div>
    );
  }

  const svgWidth = 800;
  const svgHeight = height;
  const padding = { top: 20, right: 30, bottom: 40, left: 65 };
  const chartWidth = svgWidth - padding.left - padding.right;
  const chartHeight = svgHeight - padding.top - padding.bottom;

  const maxVal = Math.max(
    ...data.map((d) => Math.max(d.revenue, showComparison ? d.previousRevenue : 0)),
    100
  );
  // Round maxVal up to clean interval
  const yMax = Math.ceil(maxVal * 1.15 / 1000) * 1000 || 10000;
  const yTicks = [0, 0.25, 0.5, 0.75, 1].map((ratio) => Math.round(yMax * ratio));

  // Compute points
  const points = data.map((d, i) => {
    const x = padding.left + (i / (data.length - 1)) * chartWidth;
    const y = padding.top + chartHeight - (d.revenue / yMax) * chartHeight;
    const prevY = padding.top + chartHeight - (d.previousRevenue / yMax) * chartHeight;
    return { x, y, prevY, ...d };
  });

  // Smooth bezier curve string
  const createSmoothPath = (pts: { x: number; y: number }[]) => {
    if (pts.length < 2) return '';
    let path = `M ${pts[0].x},${pts[0].y}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const current = pts[i];
      const next = pts[i + 1];
      const cp1x = current.x + (next.x - current.x) / 2;
      const cp1y = current.y;
      const cp2x = current.x + (next.x - current.x) / 2;
      const cp2y = next.y;
      path += ` C ${cp1x},${cp1y} ${cp2x},${cp2y} ${next.x},${next.y}`;
    }
    return path;
  };

  const primaryPath = createSmoothPath(points);
  const primaryAreaPath = `${primaryPath} L ${points[points.length - 1].x},${padding.top + chartHeight} L ${points[0].x},${padding.top + chartHeight} Z`;

  const compPts = points.map((p) => ({ x: p.x, y: p.prevY }));
  const compPath = createSmoothPath(compPts);

  const activePoint = hoverIndex !== null ? points[hoverIndex] : null;

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const mouseX = ((e.clientX - rect.left) / rect.width) * svgWidth;
    
    // Find closest data point
    let closestIdx = 0;
    let minDistance = Infinity;
    points.forEach((p, idx) => {
      const dist = Math.abs(p.x - mouseX);
      if (dist < minDistance) {
        minDistance = dist;
        closestIdx = idx;
      }
    });
    setHoverIndex(closestIdx);
  };

  return (
    <div ref={containerRef} className="relative w-full select-none">
      <svg
        viewBox={`0 0 ${svgWidth} ${svgHeight}`}
        className="w-full h-auto overflow-visible cursor-crosshair"
        onMouseMove={handleMouseMove}
        onMouseLeave={() => setHoverIndex(null)}
      >
        <defs>
          <linearGradient id="area-gradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#6366f1" stopOpacity="0.4" />
            <stop offset="60%" stopColor="#4f46e5" stopOpacity="0.1" />
            <stop offset="100%" stopColor="#4338ca" stopOpacity="0.0" />
          </linearGradient>
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="4" stdDeviation="6" floodColor="#6366f1" floodOpacity="0.35" />
          </filter>
        </defs>

        {/* Horizontal Grid lines */}
        {yTicks.map((tick, idx) => {
          const y = padding.top + chartHeight - (tick / yMax) * chartHeight;
          return (
            <g key={idx} className="transition-opacity">
              <line
                x1={padding.left}
                y1={y}
                x2={svgWidth - padding.right}
                y2={y}
                stroke="currentColor"
                className="text-slate-200 dark:text-slate-800"
                strokeDasharray="4 4"
                strokeWidth="1"
              />
              <text
                x={padding.left - 12}
                y={y + 4}
                textAnchor="end"
                className="fill-slate-400 dark:fill-slate-500 text-[11px] font-mono"
              >
                {valuePrefix}{tick >= 1000 ? `${(tick / 1000).toFixed(0)}k` : tick}
              </text>
            </g>
          );
        })}

        {/* X-axis labels */}
        {points.map((p, idx) => {
          // Show every 2nd or all if <= 8 points
          const showLabel = points.length <= 8 || idx % Math.ceil(points.length / 7) === 0 || idx === points.length - 1;
          if (!showLabel) return null;
          return (
            <text
              key={idx}
              x={p.x}
              y={svgHeight - 12}
              textAnchor="middle"
              className="fill-slate-400 dark:fill-slate-500 text-[11px] font-medium"
            >
              {p.date}
            </text>
          );
        })}

        {/* Previous period comparison line */}
        {showComparison && (
          <path
            d={compPath}
            fill="none"
            stroke="#94a3b8"
            strokeWidth="1.5"
            strokeDasharray="5 5"
            strokeOpacity="0.6"
          />
        )}

        {/* Area fill */}
        <path d={primaryAreaPath} fill="url(#area-gradient)" />

        {/* Primary Line */}
        <path
          d={primaryPath}
          fill="none"
          stroke="#6366f1"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter="url(#glow)"
        />

        {/* Active hover crosshair and point */}
        {activePoint && (
          <g>
            {/* Vertical crosshair */}
            <line
              x1={activePoint.x}
              y1={padding.top}
              x2={activePoint.x}
              y2={padding.top + chartHeight}
              stroke="#6366f1"
              strokeWidth="1.5"
              strokeDasharray="3 3"
              strokeOpacity="0.8"
            />

            {/* Comparison marker */}
            {showComparison && (
              <circle
                cx={activePoint.x}
                cy={activePoint.prevY}
                r="4"
                fill="#94a3b8"
                stroke="#1e293b"
                strokeWidth="2"
              />
            )}

            {/* Main marker outer glow */}
            <circle
              cx={activePoint.x}
              cy={activePoint.y}
              r="7"
              fill="#6366f1"
              fillOpacity="0.3"
            />
            {/* Main marker inner */}
            <circle
              cx={activePoint.x}
              cy={activePoint.y}
              r="4.5"
              fill="#ffffff"
              stroke="#6366f1"
              strokeWidth="2.5"
            />
          </g>
        )}
      </svg>

      {/* Floating HTML Tooltip */}
      {activePoint && hoverIndex !== null && (
        <div
          className="absolute pointer-events-none z-20 bg-slate-900/95 dark:bg-slate-950/95 backdrop-blur-md border border-slate-700/60 shadow-xl rounded-xl p-3 text-xs text-white min-w-[170px] transform -translate-x-1/2 -translate-y-full transition-all duration-75"
          style={{
            left: `${(activePoint.x / svgWidth) * 100}%`,
            top: `${(activePoint.y / svgHeight) * 100}%`,
            marginTop: '-12px',
          }}
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-2">
            <span className="font-semibold text-slate-300">{activePoint.date}</span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800/50">
              {activePoint.orders} Orders
            </span>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-indigo-500 shadow-sm" />
                <span className="text-slate-400">Current:</span>
              </div>
              <span className="font-bold text-white font-mono">
                {valuePrefix}{activePoint.revenue.toLocaleString()}
              </span>
            </div>
            {showComparison && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-slate-400 opacity-60" />
                  <span className="text-slate-400">Previous:</span>
                </div>
                <span className="font-medium text-slate-300 font-mono">
                  {valuePrefix}{activePoint.previousRevenue.toLocaleString()}
                </span>
              </div>
            )}
            {showComparison && (
              <div className="pt-1 flex items-center justify-between text-[11px]">
                <span className="text-slate-400">Period Variance:</span>
                <span className={activePoint.revenue >= activePoint.previousRevenue ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                  {activePoint.revenue >= activePoint.previousRevenue ? '+' : ''}
                  {(((activePoint.revenue - activePoint.previousRevenue) / activePoint.previousRevenue) * 100).toFixed(1)}%
                </span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
