import React, { useState } from 'react';
import { CategorySalesData } from '../../types';

interface DonutChartProps {
  data: CategorySalesData[];
  title?: string;
  centerLabel?: string;
  height?: number;
}

export const DonutChart: React.FC<DonutChartProps> = ({
  data,
  centerLabel = 'Total Sales',
}) => {
  const [activeSegment, setActiveSegment] = useState<CategorySalesData | null>(null);

  const total = data.reduce((acc, curr) => acc + curr.revenue, 0);

  const size = 260;
  const strokeWidth = 28;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const center = size / 2;

  let accumulatedPercent = 0;

  return (
    <div className="flex flex-col md:flex-row items-center justify-between gap-6 py-2">
      {/* SVG Donut */}
      <div className="relative flex items-center justify-center shrink-0">
        <svg width={size} height={size} className="transform -rotate-90">
          {/* Background track */}
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="transparent"
            stroke="currentColor"
            className="text-slate-100 dark:text-slate-800/60"
            strokeWidth={strokeWidth}
          />
          {/* Segments */}
          {data.map((item) => {
            const strokeDasharray = `${(item.percentage / 100) * circumference} ${circumference}`;
            const strokeDashoffset = -((accumulatedPercent / 100) * circumference);
            accumulatedPercent += item.percentage;

            const isHovered = activeSegment?.id === item.id;

            return (
              <circle
                key={item.id}
                cx={center}
                cy={center}
                r={radius}
                fill="transparent"
                stroke={item.color}
                strokeWidth={isHovered ? strokeWidth + 4 : strokeWidth}
                strokeDasharray={strokeDasharray}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                className="transition-all duration-200 cursor-pointer"
                style={{
                  opacity: activeSegment && !isHovered ? 0.45 : 1,
                  filter: isHovered ? `drop-shadow(0 0 8px ${item.color}88)` : 'none',
                }}
                onMouseEnter={() => setActiveSegment(item)}
                onMouseLeave={() => setActiveSegment(null)}
              />
            );
          })}
        </svg>

        {/* Center content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center px-4">
          <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
            {activeSegment ? activeSegment.category : centerLabel}
          </span>
          <span className="text-xl font-bold text-slate-900 dark:text-white font-mono mt-0.5">
            ${(activeSegment ? activeSegment.revenue : total).toLocaleString()}
          </span>
          <span className="text-[11px] text-indigo-500 font-medium mt-0.5">
            {activeSegment ? `${activeSegment.percentage}% of total` : `${data.length} categories`}
          </span>
        </div>
      </div>

      {/* Legend list */}
      <div className="flex-1 w-full space-y-2.5">
        {data.map((item) => {
          const isHovered = activeSegment?.id === item.id;
          return (
            <div
              key={item.id}
              className={`flex items-center justify-between p-2 rounded-lg cursor-pointer transition-colors ${
                isHovered
                  ? 'bg-slate-100 dark:bg-slate-800/80 ring-1 ring-slate-300 dark:ring-slate-700'
                  : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
              }`}
              onMouseEnter={() => setActiveSegment(item)}
              onMouseLeave={() => setActiveSegment(null)}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <span
                  className="w-3 h-3 rounded-full shrink-0 shadow-sm"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-xs font-medium text-slate-800 dark:text-slate-200 truncate">
                  {item.category}
                </span>
              </div>
              <div className="flex items-center gap-3 shrink-0 text-right">
                <span className="text-xs font-mono font-semibold text-slate-900 dark:text-white">
                  ${item.revenue.toLocaleString()}
                </span>
                <span className="text-[11px] font-mono text-slate-400 w-10 text-right">
                  {item.percentage}%
                </span>
                <span
                  className={`text-[10px] font-mono font-medium px-1.5 py-0.5 rounded ${
                    item.growth >= 0
                      ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10'
                      : 'text-rose-600 dark:text-rose-400 bg-rose-500/10'
                  }`}
                >
                  {item.growth >= 0 ? `+${item.growth}%` : `${item.growth}%`}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
