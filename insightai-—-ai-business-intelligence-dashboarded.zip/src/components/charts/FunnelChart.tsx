import React, { useState } from 'react';
import { FunnelStage } from '../../types';

interface FunnelChartProps {
  stages: FunnelStage[];
}

export const FunnelChart: React.FC<FunnelChartProps> = ({ stages }) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const colors = ['#6366f1', '#4f46e5', '#4338ca', '#3730a3', '#312e81'];

  return (
    <div className="space-y-3 py-1">
      {stages.map((stage, idx) => {
        const isHovered = hoveredIndex === idx;
        const widthPercent = Math.max(stage.percentage, 8);

        return (
          <div
            key={stage.stage}
            className="group cursor-pointer"
            onMouseEnter={() => setHoveredIndex(idx)}
            onMouseLeave={() => setHoveredIndex(null)}
          >
            <div className="flex items-center justify-between text-xs mb-1.5">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded flex items-center justify-center bg-slate-100 dark:bg-slate-800 text-[10px] font-mono font-bold text-slate-500 dark:text-slate-400">
                  {idx + 1}
                </span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {stage.stage}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-mono font-bold text-slate-900 dark:text-white">
                  {stage.count.toLocaleString()}
                </span>
                <span className="text-[11px] font-mono text-slate-400 w-12 text-right">
                  {stage.percentage}%
                </span>
              </div>
            </div>

            {/* Funnel Bar Container */}
            <div className="relative h-7 w-full bg-slate-100 dark:bg-slate-800/60 rounded-md overflow-hidden p-0.5">
              <div
                className="h-full rounded transition-all duration-300 flex items-center justify-end pr-2"
                style={{
                  width: `${widthPercent}%`,
                  backgroundColor: colors[idx % colors.length],
                  opacity: hoveredIndex !== null && !isHovered ? 0.6 : 1,
                  boxShadow: isHovered ? `0 0 12px ${colors[idx % colors.length]}80` : 'none',
                }}
              >
                {idx > 0 && (
                  <span className="text-[10px] font-mono font-semibold text-white/90 drop-shadow">
                    {stage.conversionFromPrevious}% conv
                  </span>
                )}
              </div>
            </div>

            {/* Dropoff Indicator between stages */}
            {idx < stages.length - 1 && (
              <div className="flex items-center justify-end gap-2 text-[10px] text-slate-400 dark:text-slate-500 my-0.5 pr-1">
                <span>Drop-off:</span>
                <span className="font-mono text-rose-500 font-medium">
                  {stage.dropoffRate ? `${stage.dropoffRate}%` : '-'}
                </span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
