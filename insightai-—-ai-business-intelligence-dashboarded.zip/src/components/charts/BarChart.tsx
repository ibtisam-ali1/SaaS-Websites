import React, { useState } from 'react';
import { CustomerGrowthPoint } from '../../types';

interface BarChartProps {
  data: CustomerGrowthPoint[];
  height?: number;
}

export const BarChart: React.FC<BarChartProps> = ({ data, height = 260 }) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const maxVal = Math.max(
    ...data.map((d) => d.newCustomers + d.returningCustomers),
    100
  );
  const yMax = Math.ceil((maxVal * 1.1) / 500) * 500 || 5000;

  const svgWidth = 600;
  const svgHeight = height;
  const padding = { top: 20, right: 20, bottom: 35, left: 45 };
  const chartWidth = svgWidth - padding.left - padding.right;
  const chartHeight = svgHeight - padding.top - padding.bottom;

  const barGroupWidth = chartWidth / data.length;
  const barWidth = Math.min(barGroupWidth * 0.32, 22);

  return (
    <div className="relative w-full select-none">
      <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto overflow-visible">
        {/* Horizontal gridlines */}
        {[0, 0.33, 0.66, 1].map((ratio, i) => {
          const val = Math.round(yMax * ratio);
          const y = padding.top + chartHeight - ratio * chartHeight;
          return (
            <g key={i}>
              <line
                x1={padding.left}
                y1={y}
                x2={svgWidth - padding.right}
                y2={y}
                stroke="currentColor"
                className="text-slate-200 dark:text-slate-800"
                strokeDasharray="4 4"
                strokeWidth="1"
              />
              <text
                x={padding.left - 8}
                y={y + 3}
                textAnchor="end"
                className="fill-slate-400 dark:fill-slate-500 text-[10px] font-mono"
              >
                {val >= 1000 ? `${(val / 1000).toFixed(1)}k` : val}
              </text>
            </g>
          );
        })}

        {/* Bars */}
        {data.map((d, idx) => {
          const groupCenterX = padding.left + (idx + 0.5) * barGroupWidth;
          const newH = (d.newCustomers / yMax) * chartHeight;
          const retH = (d.returningCustomers / yMax) * chartHeight;

          const isHovered = hoveredIdx === idx;

          return (
            <g
              key={d.period}
              className="cursor-pointer"
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
            >
              {/* Invisible touch/hover hitbox */}
              <rect
                x={padding.left + idx * barGroupWidth}
                y={padding.top}
                width={barGroupWidth}
                height={chartHeight}
                fill="transparent"
              />

              {/* Returning customers bar */}
              <rect
                x={groupCenterX - barWidth - 2}
                y={padding.top + chartHeight - retH}
                width={barWidth}
                height={retH}
                rx="3"
                className="transition-all duration-200"
                fill="#4f46e5"
                opacity={isHovered ? 1 : 0.85}
              />

              {/* New customers bar */}
              <rect
                x={groupCenterX + 2}
                y={padding.top + chartHeight - newH}
                width={barWidth}
                height={newH}
                rx="3"
                className="transition-all duration-200"
                fill="#06b6d4"
                opacity={isHovered ? 1 : 0.85}
              />

              {/* Month label */}
              <text
                x={groupCenterX}
                y={svgHeight - 12}
                textAnchor="middle"
                className={`text-[11px] transition-colors ${
                  isHovered
                    ? 'fill-indigo-500 font-bold'
                    : 'fill-slate-400 dark:fill-slate-500 font-medium'
                }`}
              >
                {d.period}
              </text>
            </g>
          );
        })}
      </svg>

      {/* Legend & Hover Info */}
      <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-indigo-600" />
            <span className="text-slate-600 dark:text-slate-400">Returning Customers</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-cyan-500" />
            <span className="text-slate-600 dark:text-slate-400">New Customers</span>
          </div>
        </div>

        {hoveredIdx !== null ? (
          <div className="font-mono text-[11px] text-slate-800 dark:text-slate-200 font-medium">
            {data[hoveredIdx].period}:{' '}
            <span className="text-indigo-500 font-bold">
              {data[hoveredIdx].returningCustomers} ret
            </span>{' '}
            /{' '}
            <span className="text-cyan-500 font-bold">
              {data[hoveredIdx].newCustomers} new
            </span>
          </div>
        ) : (
          <span className="text-[11px] text-slate-400 font-mono">Hover bars for details</span>
        )}
      </div>
    </div>
  );
};
