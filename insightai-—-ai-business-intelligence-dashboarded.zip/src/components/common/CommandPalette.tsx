import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Sparkles, 
  FileText, 
  Users, 
  LayoutDashboard, 
  TrendingUp, 
  Settings, 
  ArrowRight, 
  X, 
  LineChart,
  Sliders,
  Sun,
  Download,
  PlusCircle,
  ExternalLink
} from 'lucide-react';
import { NavigationTab, CustomerItem, AiInsightItem, ReportItem } from '../../types';

export interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: NavigationTab) => void;
  customers?: CustomerItem[];
  insights?: AiInsightItem[];
  reports?: ReportItem[];
  onSelectCustomer?: (c: CustomerItem) => void;
  onSelectInsight?: (i: AiInsightItem) => void;
  onGoToLanding?: () => void;
  onOpenExport?: () => void;
  onOpenCreateReport?: () => void;
  onToggleTheme?: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onNavigate,
  customers = [],
  insights = [],
  reports = [],
  onSelectCustomer,
  onSelectInsight,
  onGoToLanding,
  onOpenExport,
  onOpenCreateReport,
  onToggleTheme,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
      }
    };
    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const pages = [
    { id: 'overview' as NavigationTab, label: 'Overview Dashboard', icon: LayoutDashboard, category: 'Navigation' },
    { id: 'analytics' as NavigationTab, label: 'Deep Analytics & Trends', icon: LineChart, category: 'Navigation' },
    { id: 'insights' as NavigationTab, label: 'AI Intelligence Recommendations', icon: Sparkles, category: 'Navigation' },
    { id: 'simulator' as NavigationTab, label: 'AI Scenario & Forecast Sandbox', icon: Sliders, category: 'Navigation' },
    { id: 'reports' as NavigationTab, label: 'Executive & Scheduled Reports', icon: FileText, category: 'Navigation' },
    { id: 'customers' as NavigationTab, label: 'Customer Cohort Directory', icon: Users, category: 'Navigation' },
    { id: 'sales' as NavigationTab, label: 'Sales & Product Performance', icon: TrendingUp, category: 'Navigation' },
    { id: 'settings' as NavigationTab, label: 'Workspace & Security Settings', icon: Settings, category: 'Navigation' },
  ];

  const filteredPages = pages.filter((p) =>
    p.label.toLowerCase().includes(query.toLowerCase())
  );

  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(query.toLowerCase()) ||
      c.company.toLowerCase().includes(query.toLowerCase()) ||
      c.email.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 4);

  const filteredInsights = insights.filter(
    (i) =>
      i.title.toLowerCase().includes(query.toLowerCase()) ||
      i.category.toLowerCase().includes(query.toLowerCase()) ||
      i.impact.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 3);

  const filteredReports = reports.filter(
    (r) =>
      r.title.toLowerCase().includes(query.toLowerCase()) ||
      r.category.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 3);

  const totalResults =
    filteredPages.length + filteredCustomers.length + filteredInsights.length + filteredReports.length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4">
      <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden z-10 animate-in fade-in-50 zoom-in-95 duration-150">
        {/* Search Input Box */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-200 dark:border-slate-800">
          <Search className="w-5 h-5 text-indigo-500 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search across dashboards, metrics, customers, reports, insights..."
            autoFocus
            className="w-full bg-transparent border-none outline-none text-sm text-slate-900 dark:text-white placeholder-slate-400 font-medium"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[10px] font-mono text-slate-500">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 space-y-4">
          {totalResults === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm">
              <Search className="w-8 h-8 mx-auto mb-2 opacity-30 text-indigo-400" />
              No results found for “{query}”
            </div>
          ) : (
            <>
              {/* Pages */}
              {filteredPages.length > 0 && (
                <div>
                  <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Pages & Views
                  </div>
                  <div className="space-y-0.5">
                    {filteredPages.map((p) => {
                      const Icon = p.icon;
                      return (
                        <button
                          key={p.id}
                          onClick={() => {
                            onNavigate(p.id);
                            onClose();
                          }}
                          className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors group"
                        >
                          <div className="flex items-center gap-2.5">
                            <Icon className="w-4 h-4 text-slate-400 group-hover:text-indigo-500" />
                            <span>{p.label}</span>
                          </div>
                          <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 text-indigo-500 transition-opacity" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* AI Insights */}
              {filteredInsights.length > 0 && (
                <div>
                  <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    AI Business Insights
                  </div>
                  <div className="space-y-0.5">
                    {filteredInsights.map((ins) => (
                      <button
                        key={ins.id}
                        onClick={() => {
                          onNavigate('insights');
                          if (onSelectInsight) onSelectInsight(ins);
                          onClose();
                        }}
                        className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors group text-left"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <Sparkles className="w-4 h-4 text-indigo-400 shrink-0" />
                          <span className="truncate font-medium">{ins.title}</span>
                        </div>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 shrink-0 ml-2">
                          {ins.impact}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Customers */}
              {filteredCustomers.length > 0 && (
                <div>
                  <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Customer Accounts
                  </div>
                  <div className="space-y-0.5">
                    {filteredCustomers.map((c) => (
                      <button
                        key={c.id}
                        onClick={() => {
                          onNavigate('customers');
                          if (onSelectCustomer) onSelectCustomer(c);
                          onClose();
                        }}
                        className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors group"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <img
                            src={c.avatar}
                            alt={c.name}
                            className="w-6 h-6 rounded-full object-cover shrink-0"
                          />
                          <div className="min-w-0 text-left">
                            <span className="font-semibold text-slate-900 dark:text-white truncate block">
                              {c.name}
                            </span>
                            <span className="text-[10px] text-slate-400 truncate block">
                              {c.company}
                            </span>
                          </div>
                        </div>
                        <span className="font-mono text-xs font-semibold text-slate-900 dark:text-white">
                          ${c.revenue.toLocaleString()}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Reports */}
              {filteredReports.length > 0 && (
                <div>
                  <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Generated Reports
                  </div>
                  <div className="space-y-0.5">
                    {filteredReports.map((r) => (
                      <button
                        key={r.id}
                        onClick={() => {
                          onNavigate('reports');
                          onClose();
                        }}
                        className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors group"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                          <span className="truncate font-medium">{r.title}</span>
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 uppercase">
                          {r.format}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-[11px] text-slate-400 flex items-center justify-between">
          <span>Navigate with click or arrow keys</span>
          <span className="font-mono">InsightAI Command Engine</span>
        </div>
      </div>
    </div>
  );
};
