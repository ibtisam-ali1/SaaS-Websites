import React, { useState, useRef, useEffect } from 'react';
import { TimeRange, ThemeMode, NotificationItem, NavigationTab } from '../../types';
import {
  Search,
  Calendar,
  Bell,
  Check,
  RefreshCw,
  Menu,
  Sparkles,
  ChevronDown,
  User,
  Shield,
  Download,
  ExternalLink
} from 'lucide-react';

export interface NavbarProps {
  timeRange: TimeRange;
  onChangeTimeRange?: (range: TimeRange) => void;
  onSelectTimeRange?: (range: TimeRange) => void;
  onOpenSearch?: () => void;
  onOpenCommandPalette?: () => void;
  onOpenExportModal?: () => void;
  onOpenDateModal?: () => void;
  onOpenMobileMenu?: () => void;
  onToggleMobileSidebar?: () => void;
  onRefreshData?: () => void;
  isRefreshing?: boolean;
  theme: ThemeMode;
  onToggleTheme?: () => void;
  onNavigate?: (tab: NavigationTab | 'landing') => void;
  onGoToLanding?: () => void;
  notifications?: NotificationItem[];
  onMarkNotificationRead?: (id: string) => void;
  onClearAllNotifications?: () => void;
  onTriggerToast?: (title: string, desc?: string, type?: 'success' | 'info' | 'warning' | 'critical') => void;
}

const DEFAULT_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'n-1',
    title: 'Monthly Revenue Milestone Reached',
    message: 'Revenue crossed $148,000 threshold, +14.8% above plan.',
    timestamp: '12m ago',
    read: false,
    type: 'success',
    category: 'ai'
  },
  {
    id: 'n-2',
    title: 'High-Growth Anomaly Detected',
    message: 'AI Copilot tier surged 24.6% in 48 hours.',
    timestamp: '1h ago',
    read: false,
    type: 'info',
    category: 'alert'
  },
  {
    id: 'n-3',
    title: 'Automated Executive Brief Ready',
    message: 'June Board of Directors packet generated in PDF format.',
    timestamp: '3h ago',
    read: true,
    type: 'info',
    category: 'report'
  }
];

export const Navbar: React.FC<NavbarProps> = ({
  timeRange,
  onChangeTimeRange,
  onSelectTimeRange,
  onOpenSearch,
  onOpenCommandPalette,
  onOpenExportModal,
  onOpenDateModal,
  onOpenMobileMenu,
  onToggleMobileSidebar,
  onRefreshData,
  isRefreshing = false,
  theme,
  onToggleTheme,
  onNavigate,
  onGoToLanding,
  notifications: propsNotifications,
  onMarkNotificationRead,
  onClearAllNotifications,
  onTriggerToast,
}) => {
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [timeRangeOpen, setTimeRangeOpen] = useState(false);

  const [localNotifications, setLocalNotifications] = useState<NotificationItem[]>(DEFAULT_NOTIFICATIONS);
  const notifications = propsNotifications || localNotifications;

  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);
  const timeRef = useRef<HTMLDivElement>(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotificationsOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setProfileOpen(false);
      }
      if (timeRef.current && !timeRef.current.contains(e.target as Node)) {
        setTimeRangeOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleMarkAllRead = () => {
    if (onClearAllNotifications) {
      onClearAllNotifications();
    } else {
      setLocalNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    }
  };

  const handleTimeRangeChange = (r: TimeRange) => {
    if (typeof onChangeTimeRange === 'function') {
      onChangeTimeRange(r);
    }
    if (typeof onSelectTimeRange === 'function') {
      onSelectTimeRange(r);
    }
  };

  const handleOpenSearch = () => {
    if (typeof onOpenSearch === 'function') {
      onOpenSearch();
    }
    if (typeof onOpenCommandPalette === 'function') {
      onOpenCommandPalette();
    }
  };

  const handleOpenMobileMenu = () => {
    if (typeof onOpenMobileMenu === 'function') {
      onOpenMobileMenu();
    }
    if (typeof onToggleMobileSidebar === 'function') {
      onToggleMobileSidebar();
    }
  };

  const handleOpenExport = () => {
    if (typeof onOpenExportModal === 'function') {
      onOpenExportModal();
    }
  };

  const handleOpenDateModal = () => {
    if (typeof onOpenDateModal === 'function') {
      onOpenDateModal();
    } else if (typeof onSelectTimeRange === 'function') {
      onSelectTimeRange('custom');
    } else if (typeof onChangeTimeRange === 'function') {
      onChangeTimeRange('custom');
    }
  };

  const handleNav = (tab: NavigationTab | 'landing') => {
    if (tab === 'landing') {
      if (typeof onGoToLanding === 'function') {
        onGoToLanding();
      } else if (typeof onNavigate === 'function') {
        onNavigate('landing');
      }
    } else if (typeof onNavigate === 'function') {
      onNavigate(tab);
    }
  };

  const getTimeRangeLabel = (range: TimeRange) => {
    switch (range) {
      case 'today':
        return 'Today';
      case '7d':
        return 'Last 7 Days';
      case '30d':
        return 'Last 30 Days';
      case '90d':
        return 'Last 90 Days';
      case 'year':
        return 'This Year';
      case 'custom':
        return 'Custom Range';
      default:
        return 'Last 30 Days';
    }
  };

  return (
    <header className="sticky top-0 z-20 h-16 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md transition-colors px-4 md:px-6 flex items-center justify-between gap-4">
      {/* Left side: Hamburger & Search */}
      <div className="flex items-center gap-3 flex-1 max-w-md">
        <button
          onClick={handleOpenMobileMenu}
          className="md:hidden p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
          aria-label="Open mobile navigation"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Global Search Bar */}
        <button
          onClick={handleOpenSearch}
          className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 hover:bg-slate-200/70 dark:hover:bg-slate-800 border border-transparent dark:border-slate-700/50 text-slate-500 dark:text-slate-400 text-xs transition-all group shadow-inner"
        >
          <div className="flex items-center gap-2.5">
            <Search className="w-4 h-4 text-slate-400 group-hover:text-indigo-500 transition-colors" />
            <span className="font-medium text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-200">
              Search metrics, customers, reports, insights...
            </span>
          </div>
          <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono text-[10px] text-slate-500 shadow-xs">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Right side actions */}
      <div className="flex items-center gap-2 md:gap-3 shrink-0">
        {/* Date Range Selector Dropdown */}
        <div className="relative" ref={timeRef}>
          <button
            onClick={() => setTimeRangeOpen(!timeRangeOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-200 hover:border-indigo-500 transition-colors shadow-xs"
          >
            <Calendar className="w-3.5 h-3.5 text-indigo-500" />
            <span className="hidden sm:inline">{getTimeRangeLabel(timeRange)}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {timeRangeOpen && (
            <div className="absolute right-0 mt-2 w-48 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl py-1.5 z-30 animate-in fade-in-50 zoom-in-95">
              <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:border-slate-800 mb-1">
                Select Date Period
              </div>
              {(['today', '7d', '30d', '90d', 'year'] as TimeRange[]).map((r) => (
                <button
                  key={r}
                  onClick={() => {
                    handleTimeRangeChange(r);
                    setTimeRangeOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 text-xs text-left transition-colors ${
                    timeRange === r
                      ? 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 font-semibold'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <span>{getTimeRangeLabel(r)}</span>
                  {timeRange === r && <Check className="w-3.5 h-3.5 text-indigo-500" />}
                </button>
              ))}
              <div className="border-t border-slate-100 dark:border-slate-800 mt-1 pt-1">
                <button
                  onClick={() => {
                    setTimeRangeOpen(false);
                    handleOpenDateModal();
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 font-medium"
                >
                  Custom Date Range...
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Refresh / AI Sync */}
        <button
          onClick={() => {
            if (typeof onRefreshData === 'function') {
              onRefreshData();
            } else if (typeof onTriggerToast === 'function') {
              onTriggerToast('Real-time Data Synchronized', 'Model updated with newest ingestion logs.', 'success');
            }
          }}
          disabled={isRefreshing}
          className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:text-indigo-500 hover:border-indigo-500 transition-all shadow-xs disabled:opacity-50"
          title="Simulate Real-time Data Ingestion & AI Recalibration"
        >
          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-indigo-500' : ''}`} />
        </button>

        {/* Quick Export Button */}
        <button
          onClick={handleOpenExport}
          className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-200 hover:border-indigo-500 transition-colors shadow-xs"
          title="Export current view as PDF, CSV, or XLSX"
        >
          <Download className="w-3.5 h-3.5 text-slate-400" />
          <span>Export</span>
        </button>

        {/* Notifications Dropdown */}
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => setNotificationsOpen(!notificationsOpen)}
            className="relative p-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:text-indigo-500 transition-colors shadow-xs"
            aria-label="View notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-indigo-600 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-white dark:ring-slate-900">
                {unreadCount}
              </span>
            )}
          </button>

          {notificationsOpen && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl py-2 z-30 animate-in fade-in-50 zoom-in-95">
              <div className="flex items-center justify-between px-4 py-2 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-xs text-slate-900 dark:text-white">
                    Intelligence Alerts
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                    {unreadCount} new
                  </span>
                </div>
                {unreadCount > 0 && (
                  <button
                    onClick={handleMarkAllRead}
                    className="text-[11px] text-indigo-500 hover:text-indigo-600 font-medium"
                  >
                    Mark all read
                  </button>
                )}
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-80 overflow-y-auto">
                {notifications.map((n) => (
                  <div
                    key={n.id}
                    onClick={() => onMarkNotificationRead?.(n.id)}
                    className={`p-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer ${
                      !n.read ? 'bg-indigo-50/40 dark:bg-indigo-950/20' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        {!n.read && (
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                        )}
                        <h6 className="text-xs font-semibold text-slate-900 dark:text-white">
                          {n.title}
                        </h6>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono shrink-0">
                        {n.timestamp}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 pl-3 leading-relaxed">
                      {n.message}
                    </p>
                  </div>
                ))}
              </div>

              <div className="p-2 border-t border-slate-100 dark:border-slate-800 text-center">
                <button
                  onClick={() => {
                    setNotificationsOpen(false);
                    handleNav('insights');
                  }}
                  className="text-xs font-medium text-indigo-500 hover:text-indigo-600"
                >
                  View All AI Insights →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Profile Menu */}
        <div className="relative" ref={profileRef}>
          <button
            onClick={() => setProfileOpen(!profileOpen)}
            className="flex items-center gap-2.5 p-1 sm:px-2 sm:py-1 rounded-xl border border-transparent hover:border-slate-200 dark:hover:border-slate-800 transition-colors"
          >
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                alt="Alex Reynolds"
                className="w-8 h-8 rounded-xl object-cover ring-1 ring-slate-300 dark:ring-slate-700"
              />
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
            </div>
            <div className="hidden lg:block text-left">
              <div className="text-xs font-semibold text-slate-900 dark:text-white leading-tight">
                Alex Reynolds
              </div>
              <div className="text-[10px] text-slate-400">Chief Analytics Officer</div>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
          </button>

          {profileOpen && (
            <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl py-2 z-30 animate-in fade-in-50 zoom-in-95">
              <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800">
                <div className="text-xs font-bold text-slate-900 dark:text-white">
                  Apex Data Global Corp
                </div>
                <div className="text-[11px] text-slate-400">alex.reynolds@insightai.corp</div>
                <div className="mt-1.5 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950 text-[10px] font-mono font-medium text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800/50">
                  <Shield className="w-3 h-3" /> Enterprise Admin
                </div>
              </div>

              <div className="py-1">
                <button
                  onClick={() => {
                    setProfileOpen(false);
                    handleNav('settings');
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <User className="w-4 h-4 text-slate-400" />
                  <span>Profile & Security</span>
                </button>
                <button
                  onClick={() => {
                    setProfileOpen(false);
                    handleNav('insights');
                  }}
                  className="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <Sparkles className="w-4 h-4 text-indigo-400" />
                  <span>AI Engine Preferences</span>
                </button>
                <button
                  onClick={() => {
                    setProfileOpen(false);
                    handleNav('landing');
                  }}
                  className="w-full flex items-center justify-between px-4 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <span>Public Landing Page</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </button>
              </div>

              <div className="border-t border-slate-100 dark:border-slate-800 pt-1 mt-1 px-4 py-1.5 flex items-center justify-between text-[11px] text-slate-400">
                <span>Tenant: US-East-1 (VPC)</span>
                <span className="font-mono text-emerald-500">v4.8.2</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
