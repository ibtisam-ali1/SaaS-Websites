import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  RotateCcw, 
  ChevronDown, 
  ChevronUp,
  Headphones,
  CheckCircle2,
  Clock
} from 'lucide-react';

interface ExecutiveAudioBriefingProps {
  onTriggerToast?: (title: string, desc?: string, type?: 'info' | 'success') => void;
}

const BRIEFING_SENTENCES = [
  "Good morning. Here is your 60-second InsightAI Executive Briefing for today.",
  "Total Monthly Recurring Revenue reached $148,420, tracking 14.8% above Q2 forecast.",
  "Diurnal telemetry identified peak query concurrency between 6:00 PM and 9:00 PM, driven by enterprise analytical jobs.",
  "Product Category A remains dominant with 42% revenue share, while Category C shows +24% expansion opportunity.",
  "Action recommended: Deploy automated retention playbooks for 8 at-risk Mid-Market accounts before end-of-quarter renewal."
];

export const ExecutiveAudioBriefing: React.FC<ExecutiveAudioBriefingProps> = ({ onTriggerToast }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSentenceIdx, setCurrentSentenceIdx] = useState(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<1 | 1.25 | 1.5>(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isTranscriptOpen, setIsTranscriptOpen] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);

  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const intervalRef = useRef<any>(null);

  useEffect(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      setSpeechSupported(false);
    }
    return () => {
      stopAudio();
    };
  }, []);

  const stopAudio = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsPlaying(false);
  };

  const playSentence = (index: number) => {
    if (index >= BRIEFING_SENTENCES.length) {
      setIsPlaying(false);
      setCurrentSentenceIdx(0);
      onTriggerToast?.('Audio Briefing Completed', 'You are fully caught up on executive metrics.', 'success');
      return;
    }

    setCurrentSentenceIdx(index);

    if (speechSupported && 'speechSynthesis' in window && !isMuted) {
      window.speechSynthesis.cancel();
      const text = BRIEFING_SENTENCES[index];
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = playbackSpeed;
      utterance.pitch = 1.0;
      
      utterance.onend = () => {
        playSentence(index + 1);
      };

      utterance.onerror = () => {
        // Fallback timer if speech synthesis gets interrupted
        fallbackTimer(index);
      };

      utteranceRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    } else {
      fallbackTimer(index);
    }
  };

  const fallbackTimer = (index: number) => {
    const duration = Math.max(2500, (BRIEFING_SENTENCES[index].length * 60) / playbackSpeed);
    intervalRef.current = setTimeout(() => {
      playSentence(index + 1);
    }, duration);
  };

  const handleTogglePlay = () => {
    if (isPlaying) {
      stopAudio();
    } else {
      setIsPlaying(true);
      playSentence(currentSentenceIdx);
      onTriggerToast?.('Playing AI Executive Briefing', 'Synthesizing voice briefing in real-time.', 'info');
    }
  };

  const handleReset = () => {
    stopAudio();
    setCurrentSentenceIdx(0);
  };

  const handleSpeedChange = () => {
    const nextSpeed = playbackSpeed === 1 ? 1.25 : playbackSpeed === 1.25 ? 1.5 : 1;
    setPlaybackSpeed(nextSpeed);
    if (isPlaying) {
      stopAudio();
      setIsPlaying(true);
      playSentence(currentSentenceIdx);
    }
  };

  return (
    <div className="relative overflow-hidden rounded-2xl bg-linear-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-indigo-500/30 p-4 sm:p-5 text-white shadow-xl">
      {/* Decorative ambient background */}
      <div className="absolute top-0 right-0 -mt-8 -mr-8 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/3 -mb-8 w-36 h-36 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        {/* Left info & status */}
        <div className="flex items-center gap-3.5">
          <div className="relative flex items-center justify-center w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-400 shrink-0 shadow-inner">
            <Headphones className="w-6 h-6" />
            {isPlaying && (
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold tracking-wide uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                <Sparkles className="w-2.5 h-2.5" /> AI Audio Briefing
              </span>
              <span className="text-xs text-slate-400 flex items-center gap-1 font-mono">
                <Clock className="w-3 h-3" /> ~60 sec summary
              </span>
            </div>
            <h3 className="text-sm sm:text-base font-bold text-white mt-0.5 leading-snug">
              Today's Autonomous Executive Audio Dispatch
            </h3>
            <p className="text-xs text-slate-300/80 line-clamp-1 mt-0.5">
              {BRIEFING_SENTENCES[currentSentenceIdx]}
            </p>
          </div>
        </div>

        {/* Player Controls */}
        <div className="flex items-center gap-2 sm:gap-3 w-full md:w-auto justify-between md:justify-end">
          {/* Waveform graphic bars when playing */}
          <div className="hidden sm:flex items-center gap-0.5 h-7 px-2">
            {[40, 75, 100, 60, 85, 45, 90, 65, 30].map((h, i) => (
              <div
                key={i}
                className={`w-1 rounded-full transition-all duration-300 ${
                  isPlaying ? 'bg-indigo-400 animate-pulse' : 'bg-slate-700'
                }`}
                style={{
                  height: isPlaying ? `${Math.max(20, (h * (currentSentenceIdx + 1)) % 100)}%` : '20%',
                  animationDelay: `${i * 0.12}s`,
                }}
              />
            ))}
          </div>

          {/* Speed Toggle */}
          <button
            onClick={handleSpeedChange}
            className="px-2.5 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700 text-xs font-mono font-medium text-slate-300 hover:text-white transition-colors"
            title="Toggle Audio Speed"
          >
            {playbackSpeed}x
          </button>

          {/* Mute toggle */}
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white transition-colors"
            title={isMuted ? 'Unmute Audio' : 'Mute Speech'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Restart */}
          <button
            onClick={handleReset}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white transition-colors"
            title="Restart Audio Briefing"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Play/Pause Button */}
          <button
            onClick={handleTogglePlay}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium text-xs sm:text-sm shadow-lg transition-all ${
              isPlaying
                ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/20'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Listen Briefing</span>
              </>
            )}
          </button>

          {/* Transcript toggle */}
          <button
            onClick={() => setIsTranscriptOpen(!isTranscriptOpen)}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white transition-colors ml-1"
            title="Toggle Transcript"
          >
            {isTranscriptOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Expandable Interactive Transcript */}
      {isTranscriptOpen && (
        <div className="mt-4 pt-4 border-t border-indigo-500/20 animate-in fade-in-50 duration-200">
          <div className="text-[11px] font-semibold text-indigo-300 uppercase tracking-wider mb-2 flex items-center justify-between">
            <span>Synchronized Audio Transcript</span>
            <span className="font-mono text-slate-400">Step {currentSentenceIdx + 1} of {BRIEFING_SENTENCES.length}</span>
          </div>
          <div className="space-y-2">
            {BRIEFING_SENTENCES.map((sentence, idx) => {
              const isActive = idx === currentSentenceIdx && isPlaying;
              const isPassed = idx < currentSentenceIdx;
              return (
                <div
                  key={idx}
                  onClick={() => {
                    stopAudio();
                    setIsPlaying(true);
                    playSentence(idx);
                  }}
                  className={`flex items-start gap-2.5 p-2.5 rounded-xl cursor-pointer transition-colors text-xs ${
                    isActive
                      ? 'bg-indigo-500/25 text-white font-medium border border-indigo-400/40 shadow-inner'
                      : isPassed
                      ? 'text-slate-400 hover:bg-slate-800/50'
                      : 'text-slate-300 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="mt-0.5 shrink-0">
                    {isPassed ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    ) : isActive ? (
                      <div className="w-3.5 h-3.5 rounded-full bg-indigo-400 animate-ping" />
                    ) : (
                      <div className="w-3.5 h-3.5 rounded-full border border-slate-600 text-[9px] flex items-center justify-center font-mono">
                        {idx + 1}
                      </div>
                    )}
                  </div>
                  <span className="leading-relaxed">{sentence}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
