import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, 
  Play, 
  Pause, 
  Zap, 
  ArrowUpRight, 
  AlertTriangle, 
  DollarSign, 
  ShieldCheck, 
  Database,
  Radio,
  SlidersHorizontal,
  X
} from 'lucide-react';
import { TelemetryEvent } from '../../types';

interface LiveTelemetryStreamProps {
  onTriggerToast?: (title: string, desc?: string, type?: 'info' | 'success' | 'warning') => void;
}

const INITIAL_EVENTS: TelemetryEvent[] = [
  {
    id: 'evt-101',
    timestamp: 'Just now',
    type: 'expansion',
    title: 'Enterprise Tier License Expansion',
    description: 'Vertex AI Corp added 45 seat licenses to Copilot tier.',
    magnitude: '+$6,750 ARR',
    severity: 'normal',
    account: 'Vertex AI Corp'
  },
  {
    id: 'evt-102',
    timestamp: '4s ago',
    type: 'purchase',
    title: 'Self-Serve Annual Checkout Succeeded',
    description: 'Stripe webhook verified payment for Scale Tier.',
    magnitude: '+$2,400',
    severity: 'normal',
    account: 'Nordic Logistics AS'
  },
  {
    id: 'evt-103',
    timestamp: '12s ago',
    type: 'query_spike',
    title: 'Concurrent Analytic Query Burst',
    description: '4,280 queries/min observed in US-East-1 cluster.',
    magnitude: '4.2k req/s',
    severity: 'info',
    account: 'Apex Data Global'
  },
  {
    id: 'evt-104',
    timestamp: '25s ago',
    type: 'churn_risk',
    title: 'Preemptive Churn Signal Flagged',
    description: 'Session dropoff detected on Horizon Media account.',
    magnitude: 'Risk 72%',
    severity: 'warning',
    account: 'Horizon Media Inc'
  },
  {
    id: 'evt-105',
    timestamp: '42s ago',
    type: 'security',
    title: 'Zero-Trust Role Verification',
    description: 'SOC2-compliant audit token refreshed for 12 nodes.',
    magnitude: 'Audit Pass',
    severity: 'normal',
    account: 'System Infrastructure'
  }
];

const POOL_EVENTS: Omit<TelemetryEvent, 'id' | 'timestamp'>[] = [
  {
    type: 'purchase',
    title: 'New Enterprise API Contract Signed',
    description: 'Multi-year commitment closed via Salesforce webhook.',
    magnitude: '+$48,000 ARR',
    severity: 'normal',
    account: 'Starlight Financial'
  },
  {
    type: 'expansion',
    title: 'Compute GPU Over-quota Burst',
    description: 'Customer opted into unmetered inference add-on.',
    magnitude: '+$1,820',
    severity: 'normal',
    account: 'BioGen Insights'
  },
  {
    type: 'anomaly',
    title: 'Model Latency Drift Alert',
    description: 'P99 response time increased from 18ms to 34ms.',
    magnitude: '+16ms drift',
    severity: 'warning',
    account: 'EU-West-3 Edge'
  },
  {
    type: 'purchase',
    title: 'Executive PDF Board Packet Exported',
    description: 'Real-time telemetry packaged into encrypted executive report.',
    magnitude: '14.2 MB',
    severity: 'info',
    account: 'Board of Directors'
  },
  {
    type: 'churn_risk',
    title: 'License Renewal Approaching In 14 Days',
    description: 'Proactive discount voucher generated via AI policy.',
    magnitude: 'Retention: 94%',
    severity: 'warning',
    account: 'CloudScale Technologies'
  }
];

export const LiveTelemetryStream: React.FC<LiveTelemetryStreamProps> = ({ onTriggerToast }) => {
  const [events, setEvents] = useState<TelemetryEvent[]>(INITIAL_EVENTS);
  const [isLive, setIsLive] = useState(true);
  const [speed, setSpeed] = useState<1 | 2 | 5>(1);
  const [filter, setFilter] = useState<'all' | 'warning' | 'purchase'>('all');
  const [selectedEvent, setSelectedEvent] = useState<TelemetryEvent | null>(null);
  const [eventsPerSec, setEventsPerSec] = useState(142);

  const poolIndexRef = useRef(0);

  useEffect(() => {
    if (!isLive) return;

    const intervalMs = 4500 / speed;
    const interval = setInterval(() => {
      const template = POOL_EVENTS[poolIndexRef.current % POOL_EVENTS.length];
      poolIndexRef.current += 1;

      const newEvent: TelemetryEvent = {
        ...template,
        id: `evt-${Date.now()}`,
        timestamp: 'Just now',
      };

      setEvents((prev) => [
        newEvent,
        ...prev.map((e, idx) => ({
          ...e,
          timestamp: idx === 0 ? '4s ago' : idx === 1 ? '16s ago' : `${(idx + 1) * 20}s ago`
        })).slice(0, 15)
      ]);

      setEventsPerSec((prev) => Math.floor(135 + Math.random() * 25));
    }, intervalMs);

    return () => clearInterval(interval);
  }, [isLive, speed]);

  const filteredEvents = events.filter((e) => {
    if (filter === 'all') return true;
    if (filter === 'warning') return e.severity === 'warning' || e.type === 'churn_risk';
    if (filter === 'purchase') return e.type === 'purchase' || e.type === 'expansion';
    return true;
  });

  const getEventIcon = (type: TelemetryEvent['type']) => {
    switch (type) {
      case 'purchase':
      case 'expansion':
        return <DollarSign className="w-4 h-4 text-emerald-400" />;
      case 'query_spike':
        return <Zap className="w-4 h-4 text-indigo-400" />;
      case 'churn_risk':
      case 'anomaly':
        return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case 'security':
        return <ShieldCheck className="w-4 h-4 text-cyan-400" />;
      default:
        return <Activity className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm p-4 sm:p-5 flex flex-col h-full">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 text-indigo-500">
            <Radio className="w-4 h-4" />
            {isLive && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900 animate-pulse" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                Real-Time Telemetry Feed
              </h4>
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono font-medium bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/40">
                {eventsPerSec} evt/s
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Live enterprise event ingestion & automated anomaly classification
            </p>
          </div>
        </div>

        {/* Stream Controls */}
        <div className="flex items-center gap-1.5">
          {/* Filter Pills */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800/80 p-0.5 rounded-lg text-[11px] font-medium text-slate-600 dark:text-slate-300">
            <button
              onClick={() => setFilter('all')}
              className={`px-2 py-1 rounded-md transition-colors ${
                filter === 'all' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs' : ''
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('purchase')}
              className={`px-2 py-1 rounded-md transition-colors ${
                filter === 'purchase' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs' : ''
              }`}
            >
              Revenue
            </button>
            <button
              onClick={() => setFilter('warning')}
              className={`px-2 py-1 rounded-md transition-colors ${
                filter === 'warning' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs' : ''
              }`}
            >
              Risks
            </button>
          </div>

          {/* Speed Toggle */}
          <button
            onClick={() => setSpeed(speed === 1 ? 2 : speed === 2 ? 5 : 1)}
            className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-800 text-[11px] font-mono font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            title="Stream Frequency Multiplier"
          >
            {speed}x
          </button>

          {/* Play / Pause Toggle */}
          <button
            onClick={() => {
              setIsLive(!isLive);
              onTriggerToast?.(
                isLive ? 'Telemetry Feed Paused' : 'Telemetry Feed Resumed',
                isLive ? 'Snapshot held for inspection.' : 'Listening to live event bus.',
                'info'
              );
            }}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
              isLive 
                ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700' 
                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
          >
            {isLive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span className="hidden sm:inline">{isLive ? 'Pause' : 'Stream'}</span>
          </button>
        </div>
      </div>

      {/* Events List */}
      <div className="flex-1 overflow-y-auto space-y-2 mt-3 pr-1 max-h-[360px]">
        {filteredEvents.map((evt) => (
          <div
            key={evt.id}
            onClick={() => setSelectedEvent(evt)}
            className="flex items-center justify-between p-2.5 rounded-xl border border-slate-100 dark:border-slate-800/80 hover:border-indigo-300 dark:hover:border-indigo-800/80 bg-slate-50/50 dark:bg-slate-850/40 hover:bg-indigo-50/30 dark:hover:bg-indigo-950/20 cursor-pointer transition-all group"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-7 h-7 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center shrink-0 shadow-xs">
                {getEventIcon(evt.type)}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                    {evt.title}
                  </span>
                  {evt.account && (
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono hidden sm:inline">
                      • {evt.account}
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  {evt.description}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0 pl-2">
              <span className={`text-xs font-mono font-semibold ${
                evt.type === 'purchase' || evt.type === 'expansion' 
                  ? 'text-emerald-500' 
                  : evt.severity === 'warning' 
                  ? 'text-amber-500' 
                  : 'text-indigo-400'
              }`}>
                {evt.magnitude}
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {evt.timestamp}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Detail Inspector Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 animate-in fade-in-50">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 shadow-2xl">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 flex items-center justify-center">
                  {getEventIcon(selectedEvent.type)}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {selectedEvent.title}
                  </h4>
                  <span className="text-xs text-slate-400 font-mono">
                    ID: {selectedEvent.id}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedEvent(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-2 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
                <div className="text-slate-400 text-[10px] uppercase tracking-wider mb-1 font-semibold">
                  Payload Summary
                </div>
                <div className="text-slate-700 dark:text-slate-200 leading-relaxed">
                  {selectedEvent.description}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono text-[11px]">
                <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800">
                  <div className="text-slate-400 text-[9px] uppercase">Account</div>
                  <div className="font-semibold text-slate-900 dark:text-white mt-0.5 truncate">
                    {selectedEvent.account || 'System'}
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800">
                  <div className="text-slate-400 text-[9px] uppercase">Impact Delta</div>
                  <div className="font-semibold text-emerald-500 mt-0.5">
                    {selectedEvent.magnitude}
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-5 flex gap-2">
              <button
                onClick={() => {
                  onTriggerToast?.('Automated Playbook Dispatched', `Remediation initiated for ${selectedEvent.account}`, 'success');
                  setSelectedEvent(null);
                }}
                className="flex-1 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md transition-colors"
              >
                Trigger Automated Workflow
              </button>
              <button
                onClick={() => setSelectedEvent(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
