import React from 'react';
import { NavigationTab, ThemeMode } from '../../types';
import {
  LayoutDashboard,
  LineChart,
  Sparkles,
  FileText,
  Users,
  TrendingUp,
  Settings,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Sun,
  Moon,
  Zap,
  Layers,
  X,
  Sliders
} from 'lucide-react';

export interface SidebarProps {
  activeTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  collapsed?: boolean;
  onToggleCollapse?: () => void;
  theme?: ThemeMode;
  onToggleTheme?: () => void;
  mobileOpen?: boolean;
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
  unreadInsightsCount?: number;
  insightsCount?: number;
  onOpenLanding?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  collapsed = false,
  onToggleCollapse,
  theme = 'dark',
  onToggleTheme,
  mobileOpen,
  isMobileOpen,
  onCloseMobile,
  unreadInsightsCount,
  insightsCount,
  onOpenLanding,
}) => {
  const isDrawerOpen = mobileOpen ?? isMobileOpen ?? false;
  const count = unreadInsightsCount ?? insightsCount ?? 3;

  const navItems = [
    { id: 'overview' as NavigationTab, label: 'Overview', icon: LayoutDashboard },
    { id: 'analytics' as NavigationTab, label: 'Analytics', icon: LineChart },
    { 
      id: 'insights' as NavigationTab, 
      label: 'AI Insights', 
      icon: Sparkles, 
      badge: count > 0 ? `${count} New` : undefined,
      badgeColor: 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
    },
    { 
      id: 'simulator' as NavigationTab, 
      label: 'AI Sandbox', 
      icon: Sliders, 
      badge: 'PRO',
      badgeColor: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
    },
    { id: 'reports' as NavigationTab, label: 'Reports', icon: FileText },
    { id: 'customers' as NavigationTab, label: 'Customers', icon: Users },
    { id: 'sales' as NavigationTab, label: 'Sales', icon: TrendingUp },
    { id: 'settings' as NavigationTab, label: 'Settings', icon: Settings },
  ];

  const handleNavClick = (tab: NavigationTab) => {
    if (tab === 'landing' && typeof onOpenLanding === 'function') {
      onOpenLanding();
    } else if (typeof onSelectTab === 'function') {
      onSelectTab(tab);
    }
    if (isDrawerOpen && typeof onCloseMobile === 'function') {
      onCloseMobile();
    }
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-slate-900 border-r border-slate-800 text-slate-200 transition-all duration-300 select-none">
      {/* Brand Header */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800/80">
        <div 
          onClick={() => handleNavClick('landing')}
          className="flex items-center gap-3 cursor-pointer group min-w-0"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 via-indigo-600 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 shrink-0 group-hover:scale-105 transition-transform">
            <Zap className="w-5 h-5 text-white fill-white/20" />
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-base tracking-tight text-white font-mono">
                  Insight<span className="text-indigo-400">AI</span>
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                  PRO
                </span>
              </div>
              <p className="text-[10px] text-slate-400 truncate">
                Turn data into decisions
              </p>
            </div>
          )}
        </div>

        {/* Mobile close button */}
        <button
          onClick={onCloseMobile}
          className="md:hidden text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Desktop collapse button */}
        <button
          onClick={onToggleCollapse}
          className="hidden md:flex text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <div className="mb-2 px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400">
          {!collapsed ? 'Enterprise Workspace' : '•••'}
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group relative ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60'
              } ${collapsed ? 'justify-center px-0' : ''}`}
              title={collapsed ? item.label : undefined}
            >
              <Icon
                className={`w-4 h-4 shrink-0 transition-transform ${
                  isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'
                }`}
              />

              {!collapsed && (
                <span className="truncate flex-1 text-left">{item.label}</span>
              )}

              {!collapsed && item.badge && (
                <span className={`text-[10px] font-mono font-medium px-2 py-0.5 rounded-full ${item.badgeColor || ''}`}>
                  {item.badge}
                </span>
              )}

              {/* Collapsed active indicator bar */}
              {collapsed && isActive && (
                <span className="absolute left-0 w-1 h-5 rounded-r bg-white" />
              )}
            </button>
          );
        })}

        <div className="pt-4 mt-4 border-t border-slate-800">
          <div className="mb-2 px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            {!collapsed ? 'Public & Marketing' : '•••'}
          </div>

          <button
            onClick={() => handleNavClick('landing')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
              activeTab === 'landing'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60'
            } ${collapsed ? 'justify-center px-0' : ''}`}
            title={collapsed ? 'Landing Page' : undefined}
          >
            <Layers className="w-4 h-4 shrink-0 text-slate-400 group-hover:text-indigo-400" />
            {!collapsed && (
              <>
                <span className="truncate flex-1 text-left">Marketing Landing</span>
                <ExternalLink className="w-3 h-3 opacity-60" />
              </>
            )}
          </button>
        </div>
      </div>

      {/* AI Health & System Status */}
      {!collapsed && (
        <div className="mx-3 mb-3 p-3 rounded-xl bg-slate-950/70 border border-slate-800">
          <div className="flex items-center justify-between text-[11px] mb-1">
            <span className="text-slate-400 font-medium">AI Forecasting</span>
            <span className="flex items-center gap-1.5 text-emerald-400 font-mono text-[10px]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Operational
            </span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full w-[94%]" />
          </div>
          <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1.5">
            <span>Model v4.8 Active</span>
            <span className="font-mono">94% Confidence</span>
          </div>
        </div>
      )}

      {/* Bottom Footer / Theme Switch */}
      <div className="p-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
        <button
          onClick={() => {
            if (typeof onToggleTheme === 'function') {
              onToggleTheme();
            }
          }}
          className={`flex items-center gap-2 p-2 rounded-lg text-xs text-slate-400 hover:text-white hover:bg-slate-800 transition-colors ${
            collapsed ? 'w-full justify-center' : 'flex-1'
          }`}
          title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
        >
          {theme === 'dark' ? (
            <>
              <Sun className="w-4 h-4 text-amber-400" />
              {!collapsed && <span>Light Mode</span>}
            </>
          ) : (
            <>
              <Moon className="w-4 h-4 text-indigo-400" />
              {!collapsed && <span>Dark Mode</span>}
            </>
          )}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside
        className={`hidden md:block shrink-0 transition-all duration-300 z-30 ${
          collapsed ? 'w-20' : 'w-64'
        }`}
      >
        <div className="fixed top-0 bottom-0 left-0 h-screen z-30 transition-all duration-300"
          style={{ width: collapsed ? '5rem' : '16rem' }}
        >
          {sidebarContent}
        </div>
      </aside>

      {/* Mobile Drawer Overlay */}
      {isDrawerOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity"
            onClick={() => {
              if (typeof onCloseMobile === 'function') {
                onCloseMobile();
              }
            }}
          />
          <div className="relative w-72 max-w-[85vw] h-full shadow-2xl z-10 animate-in slide-in-from-left duration-200">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
