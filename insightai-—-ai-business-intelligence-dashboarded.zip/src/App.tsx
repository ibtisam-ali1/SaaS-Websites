import React, { useState, useEffect, useCallback } from 'react';
import { 
  NavigationTab, 
  TimeRange, 
  ThemeMode, 
  ToastMessage, 
  NotificationItem, 
  ReportItem, 
  CustomerItem, 
  AiInsightItem, 
  UserSettings 
} from './types';

import { 
  INITIAL_METRICS, 
  REVENUE_SERIES, 
  CATEGORY_SALES, 
  CUSTOMER_GROWTH_DATA, 
  FUNNEL_STAGES, 
  TRAFFIC_SOURCES, 
  INITIAL_NOTIFICATIONS, 
  INITIAL_REPORTS, 
  INITIAL_CUSTOMERS, 
  PRODUCT_PERFORMANCE, 
  AI_INSIGHTS, 
  INITIAL_SETTINGS 
} from './data/mockData';

// Common Components
import { Sidebar } from './components/common/Sidebar';
import { Navbar } from './components/common/Navbar';
import { CommandPalette } from './components/common/CommandPalette';
import { ToastContainer } from './components/common/ToastContainer';

// Modals
import { ExportModal } from './components/modals/ExportModal';
import { DateRangeModal } from './components/modals/DateRangeModal';
import { CreateReportModal } from './components/modals/CreateReportModal';
import { CustomerDetailModal } from './components/modals/CustomerDetailModal';

// Views
import { LandingPageView } from './views/LandingPageView';
import { OverviewDashboardView } from './views/OverviewDashboardView';
import { AnalyticsView } from './views/AnalyticsView';
import { AiInsightsView } from './views/AiInsightsView';
import { SimulatorView } from './views/SimulatorView';
import { ReportsView } from './views/ReportsView';
import { CustomersView } from './views/CustomersView';
import { SalesView } from './views/SalesView';
import { SettingsView } from './views/SettingsView';

export function App() {
  // Navigation & Page State
  const [currentView, setCurrentView] = useState<'landing' | 'app'>('landing');
  const [activeTab, setActiveTab] = useState<NavigationTab>('overview');
  const [timeRange, setTimeRange] = useState<TimeRange>('30d');
  
  // Theme State
  const [theme, setTheme] = useState<ThemeMode>('dark');

  // Sidebar & Drawers
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Modals
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isDateRangeModalOpen, setIsDateRangeModalOpen] = useState(false);
  const [isCreateReportModalOpen, setIsCreateReportModalOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerItem | null>(null);

  // Dynamic Data States
  const [metrics, setMetrics] = useState(INITIAL_METRICS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [reports, setReports] = useState<ReportItem[]>(INITIAL_REPORTS);
  const [customers, setCustomers] = useState<CustomerItem[]>(INITIAL_CUSTOMERS);
  const [insights, setInsights] = useState<AiInsightItem[]>(AI_INSIGHTS);
  const [products] = useState(PRODUCT_PERFORMANCE);
  const [settings, setSettings] = useState<UserSettings>(INITIAL_SETTINGS);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Initialize theme class on DOM
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Global Keyboard Shortcuts (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
      if (e.key === 'Escape') {
        setIsCommandPaletteOpen(false);
        setIsExportModalOpen(false);
        setIsDateRangeModalOpen(false);
        setIsCreateReportModalOpen(false);
        setSelectedCustomer(null);
        setIsMobileSidebarOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Toast Helper
  const triggerToast = useCallback((title: string, description?: string, type: 'success' | 'info' | 'warning' | 'error' = 'success') => {
    const newToast: ToastMessage = {
      id: `toast-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      title,
      description,
      type,
    };
    setToasts((prev) => [...prev, newToast]);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Navigation handlers
  const handleNavigate = (tab: NavigationTab) => {
    setActiveTab(tab);
    setCurrentView('app');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEnterApp = (tab: NavigationTab = 'overview') => {
    setActiveTab(tab);
    setCurrentView('app');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGoToLanding = () => {
    setCurrentView('landing');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Toggle Theme
  const handleToggleTheme = (newTheme?: ThemeMode) => {
    const next = newTheme || (theme === 'dark' ? 'light' : 'dark');
    setTheme(next);
  };

  // Refresh Telemetry Action
  const handleRefreshData = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      triggerToast('Telemetry Refreshed', 'Synced latest queries from data warehouse.', 'info');
    }, 600);
  };

  // Notification actions
  const handleMarkNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const handleClearAllNotifications = () => {
    setNotifications([]);
    triggerToast('Notifications Cleared', 'All alerts marked as processed.', 'info');
  };

  // AI Insight Actions
  const handleApplyInsight = (id: string) => {
    setInsights((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nextApplied = !item.applied;
          triggerToast(
            nextApplied ? 'Insight Action Executed' : 'Action Reverted',
            `Optimization rule for "${item.title}" updated.`,
            nextApplied ? 'success' : 'info'
          );
          return { ...item, applied: nextApplied };
        }
        return item;
      })
    );
  };

  // Report creation
  const handleCreateReport = (newReport: Omit<ReportItem, 'id' | 'lastGenerated' | 'downloadsCount'>) => {
    const created: ReportItem = {
      ...newReport,
      id: `rep-${Date.now()}`,
      lastGenerated: 'Just now',
      downloadsCount: 1,
    };
    setReports((prev) => [created, ...prev]);
    triggerToast('Report Created', `"${created.title}" ready for export.`, 'success');
  };

  const handleDownloadReport = (report: ReportItem) => {
    setReports((prev) =>
      prev.map((r) => (r.id === report.id ? { ...r, downloadsCount: r.downloadsCount + 1 } : r))
    );
    triggerToast('Report Export Dispatched', `Downloading ${report.title} (${report.format})`, 'success');
  };

  // Global Export Handler
  const handleExport = (format: string, scope: string) => {
    triggerToast(
      `${format} Export Dispatched`,
      `Successfully generated export archive for ${scope.replace('_', ' ')} (${activeTab}).`,
      'success'
    );
  };

  // Customer segment update
  const handleUpdateCustomerSegment = (customerId: string, newSegment: CustomerItem['segment']) => {
    setCustomers((prev) =>
      prev.map((c) => (c.id === customerId ? { ...c, segment: newSegment } : c))
    );
    if (selectedCustomer && selectedCustomer.id === customerId) {
      setSelectedCustomer((prev) => (prev ? { ...prev, segment: newSegment } : null));
    }
    triggerToast('Customer Segment Updated', `Account reclassified as ${newSegment}.`, 'info');
  };

  // Reset Data action
  const handleResetData = () => {
    setMetrics(INITIAL_METRICS);
    setReports(INITIAL_REPORTS);
    setCustomers(INITIAL_CUSTOMERS);
    setInsights(AI_INSIGHTS);
    setSettings(INITIAL_SETTINGS);
    triggerToast('Data Reset Complete', 'Mock data restored to factory baseline.', 'info');
  };

  // If in Marketing Landing Page view, render LandingPageView
  if (currentView === 'landing') {
    return (
      <div className="font-sans antialiased">
        <LandingPageView onEnterApp={handleEnterApp} />
        <ToastContainer toasts={toasts} onDismiss={dismissToast} />
      </div>
    );
  }

  // Active Revenue Data based on selected timeRange
  const activeRevenueData = REVENUE_SERIES[timeRange] || REVENUE_SERIES['30d'];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans antialiased selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation Bar */}
      <Navbar
        theme={theme}
        onToggleTheme={handleToggleTheme}
        timeRange={timeRange}
        onChangeTimeRange={(range) => {
          if (range === 'custom') {
            setIsDateRangeModalOpen(true);
          } else {
            setTimeRange(range);
          }
        }}
        onSelectTimeRange={(range) => {
          if (range === 'custom') {
            setIsDateRangeModalOpen(true);
          } else {
            setTimeRange(range);
          }
        }}
        onOpenSearch={() => setIsCommandPaletteOpen(true)}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onOpenExportModal={() => setIsExportModalOpen(true)}
        onOpenDateModal={() => setIsDateRangeModalOpen(true)}
        onOpenMobileMenu={() => setIsMobileSidebarOpen(true)}
        onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        onRefreshData={handleRefreshData}
        isRefreshing={isRefreshing}
        onNavigate={handleNavigate}
        notifications={notifications}
        onMarkNotificationRead={handleMarkNotificationRead}
        onClearAllNotifications={handleClearAllNotifications}
        onGoToLanding={handleGoToLanding}
        onTriggerToast={triggerToast}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex max-w-[1600px] w-full mx-auto">
        {/* Persistent Responsive Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={handleNavigate}
          collapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          theme={theme}
          onToggleTheme={handleToggleTheme}
          mobileOpen={isMobileSidebarOpen}
          isMobileOpen={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
          unreadInsightsCount={insights.filter((i) => !i.applied).length}
          insightsCount={insights.filter((i) => !i.applied).length}
          onOpenLanding={handleGoToLanding}
        />

        {/* Scrollable Dashboard Viewport */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {activeTab === 'overview' && (
            <OverviewDashboardView
              metrics={metrics}
              revenueData={activeRevenueData}
              categorySales={CATEGORY_SALES}
              customerGrowth={CUSTOMER_GROWTH_DATA}
              funnelStages={FUNNEL_STAGES}
              trafficSources={TRAFFIC_SOURCES}
              aiInsights={insights}
              timeRange={timeRange}
              onOpenExport={() => setIsExportModalOpen(true)}
              onNavigateTab={handleNavigate}
              onApplyInsight={handleApplyInsight}
              onTriggerToast={triggerToast}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsView onOpenExport={() => setIsExportModalOpen(true)} />
          )}

          {activeTab === 'insights' && (
            <AiInsightsView
              insights={insights}
              onApplyInsight={handleApplyInsight}
              onTriggerToast={triggerToast}
            />
          )}

          {activeTab === 'simulator' && (
            <SimulatorView
              onTriggerToast={triggerToast}
              onOpenExportModal={() => setIsExportModalOpen(true)}
            />
          )}

          {activeTab === 'reports' && (
            <ReportsView
              reports={reports}
              onOpenCreateReport={() => setIsCreateReportModalOpen(true)}
              onDownloadReport={handleDownloadReport}
              onTriggerToast={triggerToast}
            />
          )}

          {activeTab === 'customers' && (
            <CustomersView
              customers={customers}
              onSelectCustomer={(c) => setSelectedCustomer(c)}
              onOpenExport={() => setIsExportModalOpen(true)}
            />
          )}

          {activeTab === 'sales' && (
            <SalesView
              products={products}
              onOpenExport={() => setIsExportModalOpen(true)}
              onTriggerToast={triggerToast}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              settings={settings}
              onUpdateSettings={setSettings}
              theme={theme}
              onToggleTheme={handleToggleTheme}
              onTriggerToast={triggerToast}
              onResetData={handleResetData}
            />
          )}
        </main>
      </div>

      {/* Global Modals & Dialogs */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onNavigate={handleNavigate}
        customers={customers}
        insights={insights}
        reports={reports}
        onSelectCustomer={(c) => setSelectedCustomer(c)}
        onSelectInsight={(i) => {
          setActiveTab('insights');
          handleApplyInsight(i.id);
        }}
        onGoToLanding={handleGoToLanding}
        onOpenExport={() => setIsExportModalOpen(true)}
        onOpenCreateReport={() => setIsCreateReportModalOpen(true)}
        onToggleTheme={handleToggleTheme}
      />

      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        onExport={handleExport}
        activeTab={activeTab}
        onTriggerToast={triggerToast}
      />

      <DateRangeModal
        isOpen={isDateRangeModalOpen}
        onClose={() => setIsDateRangeModalOpen(false)}
        onApply={(start, end) => {
          setTimeRange('30d');
          triggerToast('Custom Time Window Applied', `${start} to ${end}`, 'info');
        }}
        onApplyRange={(label) => {
          setTimeRange('30d');
          triggerToast('Custom Time Window Applied', label, 'info');
        }}
      />

      <CreateReportModal
        isOpen={isCreateReportModalOpen}
        onClose={() => setIsCreateReportModalOpen(false)}
        onCreateReport={handleCreateReport}
      />

      <CustomerDetailModal
        customer={selectedCustomer}
        onClose={() => setSelectedCustomer(null)}
        onUpdateSegment={handleUpdateCustomerSegment}
        onTriggerToast={triggerToast}
      />

      {/* Global Toast Notification System */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

export default App;
