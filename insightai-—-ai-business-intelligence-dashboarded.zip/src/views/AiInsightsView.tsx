import React, { useState } from 'react';
import { AiInsightItem, PriorityLevel, InsightCategory } from '../types';
import { 
  Sparkles, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  ArrowUpRight, 
  Filter, 
  BrainCircuit, 
  Zap,
  TrendingUp,
  Clock,
  Layers,
  Search
} from 'lucide-react';

interface AiInsightsViewProps {
  insights: AiInsightItem[];
  onApplyInsight: (id: string) => void;
  onTriggerToast: (title: string, desc?: string, type?: 'success' | 'info') => void;
}

export const AiInsightsView: React.FC<AiInsightsViewProps> = ({
  insights,
  onApplyInsight,
  onTriggerToast,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [expandedId, setExpandedId] = useState<string | null>('ins-1');
  
  // Interactive "Ask AI" simulator state
  const [aiQuestion, setAiQuestion] = useState('');
  const [isAsking, setIsAsking] = useState(false);
  const [conversationalAnswers, setConversationalAnswers] = useState<
    Array<{ q: string; a: string; impact: string; time: string }>
  >([
    {
      q: 'Which product bundle will optimize our Q3 sales velocity?',
      a: 'Bundling "Enterprise AI Copilot" with the "Cloud Data Pipeline" at a 15% discount accelerates deal cycles by 18 days and increases average contract value from $9.8k to $14.2k.',
      impact: '+$42,000 ARR Impact',
      time: 'Just now',
    },
  ]);

  const handleAskAi = (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuestion.trim()) return;

    setIsAsking(true);
    const userQ = aiQuestion.trim();
    setAiQuestion('');

    setTimeout(() => {
      setIsAsking(false);
      let simulatedReply = '';
      let simulatedImpact = '+$18.5k Potential';

      if (userQ.toLowerCase().includes('churn') || userQ.toLowerCase().includes('retention')) {
        simulatedReply = 'Our predictive model flags that accounts with <3 weekly queries have an 82% churn probability. Triggering proactive automated onboarding guides reduces churn by 24%.';
        simulatedImpact = '94% Retention Target';
      } else if (userQ.toLowerCase().includes('revenue') || userQ.toLowerCase().includes('growth')) {
        simulatedReply = 'Revenue velocity is tracking 14.8% higher than last period, with peak expansion clustered in enterprise multi-seat licenses in the US-East and EMEA regions.';
        simulatedImpact = '+14.8% MoM Surge';
      } else if (userQ.toLowerCase().includes('price') || userQ.toLowerCase().includes('pricing')) {
        simulatedReply = 'Pricing elasticity testing suggests high-volume API customers demonstrate 98% price inelasticity. Increasing burst token rates by $0.015 expands gross margin by 4.2%.';
        simulatedImpact = '+$38,000 Net Margin';
      } else {
        simulatedReply = `InsightAI analysis for "${userQ}": Telemetry confirms strong correlation between weekly dashboard review frequency and 12-month expansion rate. Recommendation: Dispatch automated Monday morning KPI digests.`;
        simulatedImpact = 'Confidence: 96%';
      }

      setConversationalAnswers((prev) => [
        { q: userQ, a: simulatedReply, impact: simulatedImpact, time: 'Just now' },
        ...prev,
      ]);
      onTriggerToast('InsightAI Response Ready', 'Autonomous synthesis generated from active telemetry database.', 'success');
    }, 1000);
  };

  const filteredInsights = insights.filter((item) => {
    const matchCat = selectedCategory === 'all' || item.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchPri = selectedPriority === 'all' || item.priority.toLowerCase() === selectedPriority.toLowerCase();
    return matchCat && matchPri;
  });

  const getPriorityBadge = (p: PriorityLevel) => {
    switch (p) {
      case 'critical':
        return 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900';
      case 'high':
        return 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-900';
      case 'medium':
        return 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-900';
      case 'low':
        return 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700';
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              AI Intelligence & Decision Engine
            </h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-500 font-bold border border-indigo-500/20">
              Autonomous v4.8
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Prescriptive business recommendations synthesized from continuous event telemetry and behavioral elasticity.
          </p>
        </div>

        {/* Quick Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="all">All Categories</option>
            <option value="revenue">Revenue</option>
            <option value="retention">Retention</option>
            <option value="product">Product</option>
            <option value="operations">Operations</option>
            <option value="marketing">Marketing</option>
          </select>

          {/* Priority Filter */}
          <select
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="all">All Priorities</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>

      {/* Interactive Ask AI Assistant Bar */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-indigo-900/90 via-indigo-950 to-slate-900 border border-indigo-500/40 shadow-xl text-white">
        <div className="flex items-center gap-2.5 mb-3">
          <div className="p-2 rounded-xl bg-indigo-500 text-white shadow-lg shadow-indigo-500/30">
            <BrainCircuit className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold">Ask InsightAI Anything About Your Metrics</h3>
            <p className="text-xs text-indigo-200/80">
              Natural language intelligence with simulated predictive modeling
            </p>
          </div>
        </div>

        <form onSubmit={handleAskAi} className="relative flex items-center">
          <input
            type="text"
            value={aiQuestion}
            onChange={(e) => setAiQuestion(e.target.value)}
            placeholder="e.g. How can we reduce churn in mid-market accounts? Or: Why did revenue surge 14.8%?"
            className="w-full pl-4 pr-24 py-3 rounded-xl bg-white/10 hover:bg-white/15 focus:bg-white/20 border border-white/20 text-xs sm:text-sm text-white placeholder-indigo-200/60 focus:outline-none focus:ring-2 focus:ring-indigo-400 backdrop-blur-md transition-all"
          />
          <button
            type="submit"
            disabled={isAsking || !aiQuestion.trim()}
            className="absolute right-2 px-3.5 py-1.5 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-white text-xs font-bold shadow-md transition-all disabled:opacity-50 flex items-center gap-1.5"
          >
            {isAsking ? (
              <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <span>Ask AI</span>
                <Send className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </form>

        {/* Latest Conversational Query Response Stream */}
        {conversationalAnswers.length > 0 && (
          <div className="mt-4 pt-3 border-t border-indigo-800/60 space-y-3">
            {conversationalAnswers.slice(0, 2).map((ans, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-950/60 border border-indigo-500/20 text-xs">
                <div className="flex items-center justify-between text-indigo-300 font-medium mb-1">
                  <span className="font-semibold">“{ans.q}”</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                    {ans.impact}
                  </span>
                </div>
                <p className="text-slate-300 leading-relaxed pl-1">{ans.a}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Main List of AI Recommendations */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            Recommendations ({filteredInsights.length})
          </span>
          <span className="text-xs text-slate-400 font-mono">
            Sorted by Projected ARR Impact
          </span>
        </div>

        {filteredInsights.length === 0 ? (
          <div className="p-12 text-center rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 text-slate-400">
            <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-40 text-indigo-500" />
            <p className="text-sm font-semibold">No insights match the selected filters</p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSelectedPriority('all');
              }}
              className="mt-2 text-xs text-indigo-500 underline"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          filteredInsights.map((item) => {
            const isExpanded = expandedId === item.id;

            return (
              <div
                key={item.id}
                className={`p-5 rounded-2xl border transition-all ${
                  isExpanded
                    ? 'border-indigo-500 bg-white dark:bg-slate-900 shadow-lg'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/70 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                {/* Header row: Priority, Category, Impact, Date */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider border ${getPriorityBadge(
                        item.priority
                      )}`}
                    >
                      {item.priority} Priority
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {item.category}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">{item.date}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold font-mono text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-500/20">
                      {item.impact}
                    </span>
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white mb-1.5">
                  {item.title}
                </h3>

                {/* Summary */}
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-3">
                  {item.summary}
                </p>

                {/* Expanded Details Section */}
                {isExpanded && (
                  <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3 animate-in fade-in-50">
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                      <div className="font-bold text-slate-900 dark:text-white mb-1 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                        <span>Telemetry Synthesis & Decision Reasoning</span>
                      </div>
                      {item.details}
                    </div>

                    {/* Simulation before/after card */}
                    {item.simulationData && (
                      <div className="grid grid-cols-2 gap-3 p-3 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200/60 dark:border-indigo-900/40 text-xs">
                        <div>
                          <span className="text-[10px] uppercase font-mono text-slate-400">Current Metric Baseline</span>
                          <div className="text-base font-bold font-mono text-slate-800 dark:text-slate-200 mt-0.5">
                            {item.simulationData.current.toLocaleString()}
                          </div>
                        </div>
                        <div>
                          <span className="text-[10px] uppercase font-mono text-indigo-400 font-bold">Simulated Projection</span>
                          <div className="text-base font-bold font-mono text-indigo-600 dark:text-indigo-400 mt-0.5 flex items-center gap-1.5">
                            <span>{item.simulationData.projected.toLocaleString()}</span>
                            <span className="text-[10px] font-mono text-emerald-500">
                              ({item.simulationData.difference})
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Bottom Action Footer */}
                <div className="mt-4 pt-2.5 flex items-center justify-between">
                  <button
                    onClick={() => setExpandedId(isExpanded ? null : item.id)}
                    className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                  >
                    {isExpanded ? 'Hide Details' : 'View Full Details & Simulation →'}
                  </button>

                  <button
                    onClick={() => onApplyInsight(item.id)}
                    className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs ${
                      item.applied
                        ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/30'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20'
                    }`}
                  >
                    {item.applied ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Action Deployed</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-3.5 h-3.5" />
                        <span>{item.actionLabel}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
