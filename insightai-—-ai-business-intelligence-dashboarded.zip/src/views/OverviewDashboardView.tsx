import React, { useState } from 'react';
import { 
  MetricCardData, 
  TimeRange, 
  CategorySalesData, 
  CustomerGrowthPoint, 
  FunnelStage, 
  TrafficSource, 
  AiInsightItem 
} from '../types';
import { SparkLine } from '../components/charts/SparkLine';
import { AreaChart } from '../components/charts/AreaChart';
import { DonutChart } from '../components/charts/DonutChart';
import { BarChart } from '../components/charts/BarChart';
import { FunnelChart } from '../components/charts/FunnelChart';
import { ExecutiveAudioBriefing } from '../components/common/ExecutiveAudioBriefing';
import { LiveTelemetryStream } from '../components/common/LiveTelemetryStream';
import { 
  Sparkles, 
  ArrowUpRight, 
  ArrowDownRight, 
  TrendingUp, 
  Download, 
  Info, 
  Layers, 
  CheckCircle2, 
  ChevronRight,
  Filter,
  Eye
} from 'lucide-react';

interface OverviewDashboardViewProps {
  metrics: MetricCardData[];
  revenueData: any[];
  categorySales: CategorySalesData[];
  customerGrowth: CustomerGrowthPoint[];
  funnelStages: FunnelStage[];
  trafficSources: TrafficSource[];
  aiInsights: AiInsightItem[];
  timeRange: TimeRange;
  onOpenExport: () => void;
  onNavigateTab: (tab: any) => void;
  onApplyInsight: (id: string) => void;
  onTriggerToast?: (title: string, desc?: string, type?: 'info' | 'success' | 'warning') => void;
}

export const OverviewDashboardView: React.FC<OverviewDashboardViewProps> = ({
  metrics,
  revenueData,
  categorySales,
  customerGrowth,
  funnelStages,
  trafficSources,
  aiInsights,
  timeRange,
  onOpenExport,
  onNavigateTab,
  onApplyInsight,
  onTriggerToast,
}) => {
  const [showComparison, setShowComparison] = useState(true);
  const [selectedMetricForChart, setSelectedMetricForChart] = useState<'revenue' | 'orders'>('revenue');

  // Featured AI Insights on Dashboard
  const featuredInsights = aiInsights.slice(0, 3);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner / Welcome & Quick Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Executive Performance Overview
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Real-time telemetry and AI-synthesized intelligence across all business units.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => onNavigateTab('insights')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 text-xs font-semibold hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Assistant Copilot</span>
          </button>
          <button
            onClick={onOpenExport}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-semibold hover:bg-slate-800 dark:hover:bg-slate-100 transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Report</span>
          </button>
        </div>
      </div>

      {/* Autonomous Executive Audio Dispatch Player */}
      <ExecutiveAudioBriefing onTriggerToast={onTriggerToast} />

      {/* 5 Core Dashboard KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
        {metrics.map((m) => {
          const isPos = m.changeType === 'positive';
          return (
            <div
              key={m.id}
              className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800/80 bg-white dark:bg-slate-900 shadow-xs hover:border-indigo-500/50 dark:hover:border-indigo-500/40 transition-all group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                  <span>{m.title}</span>
                  <span
                    className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                      isPos
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400'
                        : 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {isPos ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                    {m.changePercent}%
                  </span>
                </div>

                <div className="text-xl sm:text-2xl font-black font-mono tracking-tight text-slate-900 dark:text-white mt-1">
                  {m.value}
                </div>
              </div>

              <div className="mt-3 flex items-end justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800/60">
                <span className="text-[10px] text-slate-400 truncate">
                  {m.sublabel || m.comparisonPeriod}
                </span>
                <SparkLine
                  data={m.sparklineData}
                  isPositive={isPos}
                  width={68}
                  height={22}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* AI Insights Highlight Strip */}
      <div className="p-4 sm:p-5 rounded-2xl border border-indigo-200/80 dark:border-indigo-900/60 bg-gradient-to-r from-indigo-50/70 via-white to-blue-50/50 dark:from-indigo-950/40 dark:via-slate-900 dark:to-blue-950/20 shadow-xs">
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-600 text-white shadow-sm">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                Live AI Intelligence Syntheses
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Autonomous models identified 3 primary catalysts in your current data stream
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('insights')}
            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            <span>View All Insights</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {featuredInsights.map((ins) => (
            <div
              key={ins.id}
              className="p-3.5 rounded-xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between hover:border-indigo-400 dark:hover:border-indigo-600 transition-colors"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 font-semibold">
                    {ins.category}
                  </span>
                  <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                    {ins.impact}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white leading-snug">
                  “{ins.title}”
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed line-clamp-2">
                  {ins.summary}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">{ins.date}</span>
                <button
                  onClick={() => onApplyInsight(ins.id)}
                  className={`text-[11px] font-semibold px-2 py-1 rounded-lg transition-colors ${
                    ins.applied
                      ? 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/60'
                      : 'text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/60'
                  }`}
                >
                  {ins.applied ? '✓ Optimized' : ins.actionLabel}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Primary Chart Area: Revenue Over Time */}
      <div className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Revenue Trajectory & Pipeline Variance
              </h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-medium">
                Period: {timeRange.toUpperCase()}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Continuous vector regression against historical baseline and board targets.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowComparison(!showComparison)}
              className={`px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
                showComparison
                  ? 'border-indigo-500 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
                  : 'border-slate-200 dark:border-slate-800 text-slate-500 hover:border-slate-300'
              }`}
            >
              Compare Previous Period
            </button>
          </div>
        </div>

        {/* The Area Chart */}
        <AreaChart
          data={revenueData}
          showComparison={showComparison}
          valuePrefix="$"
          height={310}
        />
      </div>

      {/* Two Columns: Sales by Category & Conversion Funnel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sales by Category Donut */}
        <div className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Sales by Product Category
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Revenue distribution across active software suites
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('sales')}
              className="text-xs font-semibold text-indigo-500 hover:underline"
            >
              Sales Deep Dive →
            </button>
          </div>

          <DonutChart data={categorySales} />
        </div>

        {/* Conversion Funnel */}
        <div className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Conversion Funnel Velocity
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                From top-of-funnel visitor to activated enterprise subscription
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('analytics')}
              className="text-xs font-semibold text-indigo-500 hover:underline"
            >
              Attribution View →
            </button>
          </div>

          <FunnelChart stages={funnelStages} />
        </div>
      </div>

      {/* Two Columns: Customer Growth & Traffic Sources */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Customer Growth Bar Chart */}
        <div className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Customer Growth & Expansion
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                New enterprise logos vs returning expanding accounts
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('customers')}
              className="text-xs font-semibold text-indigo-500 hover:underline"
            >
              All Customers →
            </button>
          </div>

          <BarChart data={customerGrowth} height={230} />
        </div>

        {/* Traffic Sources Breakdown */}
        <div className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Acquisition Channels & Traffic Sources
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Conversion yield and revenue by enterprise touchpoint
              </p>
            </div>
            <span className="text-xs font-mono text-slate-400">184.5k visitors</span>
          </div>

          <div className="space-y-3.5">
            {trafficSources.map((source) => (
              <div key={source.source} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {source.source}
                  </span>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-slate-500 dark:text-slate-400">
                      {source.visitors.toLocaleString()} visits ({source.conversionRate}% conv)
                    </span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white">
                      ${source.revenue.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${source.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Live Enterprise Event Telemetry Stream */}
      <div className="pt-2">
        <LiveTelemetryStream onTriggerToast={onTriggerToast} />
      </div>
    </div>
  );
};
