import React, { useState } from 'react';
import { 
  Zap, 
  ArrowRight, 
  Sparkles, 
  TrendingUp, 
  FileText, 
  ShieldCheck, 
  CheckCircle2, 
  ChevronDown, 
  Star, 
  LineChart, 
  Layers,
  Database,
  Lock,
  Cpu,
  BarChart3
} from 'lucide-react';
import { PRICING_TIERS, FAQ_ITEMS, TESTIMONIALS } from '../data/mockData';
import { NavigationTab } from '../types';

interface LandingPageViewProps {
  onEnterApp: (tab?: NavigationTab) => void;
}

export const LandingPageView: React.FC<LandingPageViewProps> = ({ onEnterApp }) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-indigo-500 selection:text-white overflow-x-hidden">
      {/* Top Marketing Navigation Bar */}
      <header className="sticky top-0 z-40 h-20 border-b border-slate-800/80 bg-slate-950/85 backdrop-blur-xl px-6 lg:px-12 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500 via-indigo-600 to-blue-600 flex items-center justify-center text-white shadow-xl shadow-indigo-500/25">
            <Zap className="w-5 h-5 text-white fill-white/20" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-lg tracking-tight text-white font-mono">
                Insight<span className="text-indigo-400">AI</span>
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800/80">
                Enterprise BI
              </span>
            </div>
            <p className="text-[10px] text-slate-400">
              Turn business data into intelligent decisions.
            </p>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-8 text-xs font-medium text-slate-300">
          <a href="#features" className="hover:text-indigo-400 transition-colors">Features</a>
          <a href="#preview" className="hover:text-indigo-400 transition-colors">Platform Preview</a>
          <a href="#testimonials" className="hover:text-indigo-400 transition-colors">Customers</a>
          <a href="#pricing" className="hover:text-indigo-400 transition-colors">Pricing</a>
          <a href="#faq" className="hover:text-indigo-400 transition-colors">FAQ</a>
        </nav>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onEnterApp('overview')}
            className="hidden sm:inline-flex items-center px-4 py-2 rounded-xl border border-slate-800 hover:border-slate-700 bg-slate-900 text-xs font-medium text-slate-300 hover:text-white transition-colors"
          >
            Live Demo
          </button>
          <button
            onClick={() => onEnterApp('overview')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-xl shadow-indigo-600/30 transition-all hover:scale-[1.02]"
          >
            <span>Launch Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 md:pt-28 md:pb-24 px-6 lg:px-12 max-w-7xl mx-auto text-center">
        {/* Glow ambient background effects */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-indigo-600/20 blur-[130px] pointer-events-none rounded-full" />
        
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-950/80 border border-indigo-800/60 text-indigo-300 text-xs font-medium mb-6 animate-in fade-in duration-500 shadow-inner">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>InsightAI Autonomous Intelligence v4.8 Released</span>
        </div>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white max-w-5xl mx-auto leading-[1.1]">
          Understand Your Business.{' '}
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 via-blue-400 to-cyan-300">
            Act Smarter.
          </span>
        </h1>

        <p className="mt-6 text-base sm:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Stop staring at static dashboards. InsightAI continuously synthesizes revenue streams, detects silent customer churn, and delivers proactive decisions directly to your team.
        </p>

        {/* CTA Button Group */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5">
          <button
            onClick={() => onEnterApp('overview')}
            className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-bold shadow-2xl shadow-indigo-600/40 hover:shadow-indigo-600/60 transition-all hover:scale-[1.02]"
          >
            <span>Enter Main Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => onEnterApp('insights')}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800/90 border border-slate-800 text-slate-200 text-sm font-semibold transition-colors"
          >
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span>Explore AI Insights</span>
          </button>
        </div>

        {/* Trust Badges */}
        <div className="mt-12 pt-8 border-t border-slate-900 flex flex-wrap items-center justify-center gap-8 text-slate-500 text-xs font-mono">
          <span className="flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-emerald-500" /> SOC2 Type II Certified</span>
          <span className="flex items-center gap-1.5"><Lock className="w-4 h-4 text-indigo-400" /> 256-Bit VPC Isolation</span>
          <span className="flex items-center gap-1.5"><Cpu className="w-4 h-4 text-cyan-400" /> &lt;20ms Query Latency</span>
          <span className="flex items-center gap-1.5"><Database className="w-4 h-4 text-amber-400" /> Zero-ETL Connectors</span>
        </div>
      </section>

      {/* Interactive Dashboard Preview Banner */}
      <section id="preview" className="px-6 lg:px-12 max-w-7xl mx-auto mb-28">
        <div className="relative rounded-2xl md:rounded-3xl border border-slate-800 bg-slate-900/90 p-3 sm:p-5 shadow-2xl shadow-indigo-950/50 backdrop-blur-xl overflow-hidden group">
          {/* Top chrome bar */}
          <div className="flex items-center justify-between px-3 py-2 border-b border-slate-800 mb-4">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-rose-500/80" />
              <span className="w-3 h-3 rounded-full bg-amber-500/80" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80" />
              <span className="ml-2 text-xs font-mono text-slate-400">
                https://app.insightai.corp/enterprise/overview
              </span>
            </div>
            <button
              onClick={() => onEnterApp('overview')}
              className="flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
            >
              <span>Launch Live View</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Miniature interactive preview grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            {[
              { label: 'Total ARR', val: '$148,420', change: '+14.8%', color: 'text-emerald-400' },
              { label: 'Completed Orders', val: '3,842', change: '+8.2%', color: 'text-emerald-400' },
              { label: 'Active Customers', val: '12,480', change: '+19.4%', color: 'text-emerald-400' },
              { label: 'Conversion Funnel', val: '3.42%', change: '+0.6%', color: 'text-indigo-400' },
            ].map((card, i) => (
              <div key={i} className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/80">
                <div className="text-[11px] text-slate-400 font-medium">{card.label}</div>
                <div className="text-xl font-bold font-mono text-white mt-1">{card.val}</div>
                <div className={`text-[11px] font-mono mt-0.5 ${card.color}`}>{card.change} vs baseline</div>
              </div>
            ))}
          </div>

          {/* AI Banner Callout on preview */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-950/80 to-slate-900 border border-indigo-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-indigo-500 text-white shrink-0">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-white block">
                  AI Insight: Revenue increased 14.8% compared with last month.
                </span>
                <span className="text-[11px] text-slate-400">
                  Expansion in Enterprise AI Copilot plan (up 24.6%) drove +$18,920 ARR boost.
                </span>
              </div>
            </div>
            <button
              onClick={() => onEnterApp('insights')}
              className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shrink-0"
            >
              Analyze Insight →
            </button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-16 px-6 lg:px-12 max-w-7xl mx-auto border-t border-slate-900">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono uppercase tracking-widest text-indigo-400 font-bold">
            Autonomous Business Architecture
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-3">
            Built for High-Growth Enterprise Operations
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-400">
            Everything your executive, sales, and analytics teams need to navigate volatile market shifts with precision.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              icon: Sparkles,
              title: 'AI Insights Engine',
              desc: 'Autonomous anomaly detection and actionable growth recommendations updated hourly from telemetry.',
              tab: 'insights' as NavigationTab,
            },
            {
              icon: LineChart,
              title: 'Deep Analytics',
              desc: 'Interactive cohort degradation curves, CAC/LTV payback ratios, and geographic expansion heatmaps.',
              tab: 'analytics' as NavigationTab,
            },
            {
              icon: FileText,
              title: 'Automated Reports',
              desc: 'Instant boardroom-grade PDF summaries, scheduled team dispatches, and raw CSV data warehousing.',
              tab: 'reports' as NavigationTab,
            },
            {
              icon: TrendingUp,
              title: 'Predictive Forecasting',
              desc: 'Monte Carlo models simulating revenue velocity, pricing elasticity, and quarterly runway projections.',
              tab: 'sales' as NavigationTab,
            },
          ].map((f, i) => {
            const Icon = f.icon;
            return (
              <div
                key={i}
                onClick={() => onEnterApp(f.tab)}
                className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800/80 hover:border-indigo-500/50 hover:bg-slate-900 transition-all cursor-pointer group"
              >
                <div className="w-12 h-12 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-white mb-2 group-hover:text-indigo-300 transition-colors">
                  {f.title}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  {f.desc}
                </p>
                <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-400 group-hover:translate-x-1 transition-transform">
                  <span>Explore Module</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 px-6 lg:px-12 max-w-7xl mx-auto border-t border-slate-900">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-mono uppercase tracking-widest text-indigo-400 font-bold">
            Executive Validation
          </span>
          <h2 className="text-3xl font-extrabold text-white mt-2">
            Trusted by Leaders at High-Growth Enterprises
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex gap-1 text-amber-400">
                  {[...Array(t.rating)].map((_, r) => (
                    <Star key={r} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed italic">
                  “{t.quote}”
                </p>
              </div>

              <div className="flex items-center gap-3 mt-6 pt-4 border-t border-slate-800">
                <img
                  src={t.avatar}
                  alt={t.author}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/30"
                />
                <div>
                  <h5 className="text-xs font-bold text-white">{t.author}</h5>
                  <p className="text-[11px] text-slate-400">{t.role}, {t.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-6 lg:px-12 max-w-7xl mx-auto border-t border-slate-900">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-mono uppercase tracking-widest text-indigo-400 font-bold">
            Transparent Pricing
          </span>
          <h2 className="text-3xl font-extrabold text-white mt-2">
            Predictable Plans for Every Stage of Scale
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-2">
            All plans include unlimited telemetry events, SSL encryption, and native warehouse integrations.
          </p>

          {/* Billing Switch */}
          <div className="mt-6 inline-flex items-center p-1 rounded-xl bg-slate-900 border border-slate-800">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                billingCycle === 'monthly'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setBillingCycle('annual')}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                billingCycle === 'annual'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Annual Billing</span>
              <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono">
                Save 20%
              </span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {PRICING_TIERS.map((tier, idx) => {
            const price = billingCycle === 'annual' ? tier.annualPrice : tier.monthlyPrice;
            return (
              <div
                key={idx}
                className={`p-7 rounded-3xl border flex flex-col justify-between transition-all ${
                  tier.popular
                    ? 'border-indigo-500 bg-slate-900/90 shadow-2xl shadow-indigo-950/60 ring-2 ring-indigo-500/30 relative scale-[1.02]'
                    : 'border-slate-800 bg-slate-900/50'
                }`}
              >
                {tier.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-indigo-600 text-white font-mono text-[10px] font-bold tracking-wide uppercase shadow-md">
                    Enterprise Choice
                  </span>
                )}

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-base font-bold text-white">{tier.name}</h4>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                      {tier.badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 min-h-[36px]">{tier.description}</p>

                  <div className="my-6">
                    <span className="text-4xl font-extrabold font-mono text-white">${price}</span>
                    <span className="text-xs text-slate-400 ml-1">/ month</span>
                    {billingCycle === 'annual' && (
                      <p className="text-[10px] font-mono text-emerald-400 mt-1">Billed annually (${price * 12}/yr)</p>
                    )}
                  </div>

                  <div className="space-y-2.5 pt-4 border-t border-slate-800">
                    {tier.features.map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-center gap-2 text-xs text-slate-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => onEnterApp('overview')}
                  className={`mt-8 w-full py-3 rounded-xl text-xs font-bold transition-all ${
                    tier.popular
                      ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30'
                      : 'bg-slate-800 hover:bg-slate-700 text-white'
                  }`}
                >
                  {tier.cta}
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* FAQ Accordion */}
      <section id="faq" className="py-20 px-6 lg:px-12 max-w-4xl mx-auto border-t border-slate-900">
        <div className="text-center mb-12">
          <span className="text-xs font-mono uppercase tracking-widest text-indigo-400 font-bold">
            Got Questions?
          </span>
          <h2 className="text-3xl font-extrabold text-white mt-2">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="space-y-3">
          {FAQ_ITEMS.map((item, idx) => {
            const isOpen = expandedFaq === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl border border-slate-800/80 bg-slate-900/60 overflow-hidden"
              >
                <button
                  onClick={() => setExpandedFaq(isOpen ? null : idx)}
                  className="w-full flex items-center justify-between p-5 text-left text-xs sm:text-sm font-semibold text-white hover:text-indigo-400 transition-colors"
                >
                  <span>{item.q}</span>
                  <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180 text-indigo-400' : 'text-slate-400'}`} />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 text-xs text-slate-400 leading-relaxed border-t border-slate-800/60 pt-3">
                    {item.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Bottom CTA Banner */}
      <section className="py-20 px-6 lg:px-12 max-w-7xl mx-auto">
        <div className="relative rounded-3xl bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-950 border border-indigo-500/30 p-8 sm:p-14 text-center overflow-hidden">
          <div className="relative z-10 max-w-3xl mx-auto">
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
              Turn Business Data Into Intelligent Decisions Today.
            </h2>
            <p className="mt-4 text-sm sm:text-base text-indigo-200/80 max-w-xl mx-auto">
              Deploy InsightAI across your enterprise telemetry stack in less than 5 minutes. No manual SQL tuning required.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => onEnterApp('overview')}
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-white hover:bg-slate-100 text-slate-950 text-sm font-bold shadow-2xl shadow-white/20 transition-all hover:scale-105"
              >
                Launch Live Dashboard Now
              </button>
              <button
                onClick={() => onEnterApp('reports')}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-indigo-950/60 hover:bg-indigo-900/60 border border-indigo-400/30 text-white text-sm font-semibold transition-colors"
              >
                View Sample Reports
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-slate-900 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-indigo-500" />
            <span className="font-mono font-bold text-white">InsightAI</span>
            <span>— “Turn business data into intelligent decisions.”</span>
          </div>
          <p>© 2026 InsightAI Technologies Inc. All enterprise rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};
