import React, { useState } from 'react';
import { ProductPerformanceItem } from '../types';
import { 
  TrendingUp, 
  DollarSign, 
  Target, 
  Award, 
  Clock, 
  Download, 
  ArrowUpRight, 
  ArrowDownRight, 
  Sparkles, 
  CheckCircle2, 
  Package,
  Layers,
  ChevronRight
} from 'lucide-react';

interface SalesViewProps {
  products: ProductPerformanceItem[];
  onOpenExport: () => void;
  onTriggerToast: (title: string, desc?: string, type?: 'success' | 'info') => void;
}

export const SalesView: React.FC<SalesViewProps> = ({
  products,
  onOpenExport,
  onTriggerToast,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const filteredProducts = products.filter(
    (p) => activeCategory === 'all' || p.category.toLowerCase().includes(activeCategory.toLowerCase())
  );

  const getStatusBadge = (status: ProductPerformanceItem['status']) => {
    switch (status) {
      case 'Flagship':
        return 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800';
      case 'High Growth':
        return 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800';
      case 'Stable':
        return 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800';
      case 'Needs Review':
        return 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800';
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Sales Velocity & Product Telemetry
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Enterprise deal pipeline, representative quotas, and software SKU unit economics.
          </p>
        </div>

        <button
          onClick={onOpenExport}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-semibold hover:bg-slate-800 dark:hover:bg-slate-100 transition-colors shadow-xs"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Sales Ledger</span>
        </button>
      </div>

      {/* Top 4 Sales KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {[
          {
            title: 'Gross Pipeline Value',
            val: '$492,000',
            sub: '42 Qualified Opportunities',
            change: '+21.4%',
            pos: true,
            icon: Target,
          },
          {
            title: 'Closed-Won Net Revenue',
            val: '$148,420',
            sub: '106% of Q2 Board Target',
            change: '+14.8%',
            pos: true,
            icon: DollarSign,
          },
          {
            title: 'Enterprise Win Rate',
            val: '64.2%',
            sub: 'Industry benchmark: 48%',
            change: '+4.5%',
            pos: true,
            icon: Award,
          },
          {
            title: 'Avg Sales Velocity',
            val: '21.4 Days',
            sub: 'From lead to signed MSA',
            change: '-3.2 Days',
            pos: true,
            icon: Clock,
          },
        ].map((k, idx) => {
          const Icon = k.icon;
          return (
            <div
              key={idx}
              className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs"
            >
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span className="font-medium">{k.title}</span>
                <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-500">
                  <Icon className="w-3.5 h-3.5" />
                </div>
              </div>
              <div className="text-xl font-extrabold font-mono text-slate-900 dark:text-white mt-1">
                {k.val}
              </div>
              <div className="flex items-center justify-between text-[10px] mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/80">
                <span className="text-slate-400">{k.sub}</span>
                <span className="font-mono text-emerald-500 font-bold">{k.change}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* AI Sales Catalyst Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-950 border border-indigo-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-white">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-indigo-600 text-white shrink-0 shadow-md">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold">
              AI Recommendation: Product category A generated the highest growth.
            </h4>
            <p className="text-[11px] text-indigo-200/80">
              Enterprise AI Copilot drove $58,400 with a 24.6% MoM surge. Packaging with Cloud Pipeline creates a projected $24,600 cross-sell opportunity.
            </p>
          </div>
        </div>
        <button
          onClick={() => onTriggerToast('Bundle Strategy Initialized', 'Cross-sell rule applied to active checkout flow.', 'success')}
          className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors shrink-0 shadow-xs"
        >
          Deploy Bundle Discount →
        </button>
      </div>

      {/* Product Performance Table */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Product SKU Performance & Unit Economics
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Margin, volume, and refund rates for active catalog offerings
            </p>
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto">
            {['all', 'intelligence', 'infrastructure', 'analytics', 'tools'].map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize whitespace-nowrap transition-colors ${
                  activeCategory === cat
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-950/50 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                <th className="py-3 px-4">Product & SKU</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Units Sold</th>
                <th className="py-3 px-4">Gross Revenue</th>
                <th className="py-3 px-4">MoM Growth</th>
                <th className="py-3 px-4">Gross Margin</th>
                <th className="py-3 px-4">Refund Rate</th>
                <th className="py-3 px-4 text-right">Lifecycle</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
              {filteredProducts.map((p) => {
                const isGrowthPos = p.growth >= 0;
                return (
                  <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    {/* Name & SKU */}
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900 dark:text-white">{p.name}</div>
                      <div className="font-mono text-[10px] text-slate-400">{p.sku}</div>
                    </td>

                    {/* Category */}
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400">{p.category}</td>

                    {/* Units Sold */}
                    <td className="py-3 px-4 font-mono font-semibold text-slate-800 dark:text-slate-200">
                      {p.unitsSold}
                    </td>

                    {/* Revenue */}
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-white">
                      ${p.revenue.toLocaleString()}
                    </td>

                    {/* Growth */}
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center font-mono font-bold text-[11px] ${
                          isGrowthPos ? 'text-emerald-500' : 'text-rose-500'
                        }`}
                      >
                        {isGrowthPos ? '+' : ''}
                        {p.growth}%
                      </span>
                    </td>

                    {/* Margin */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                          {p.margin}%
                        </span>
                        <div className="w-12 bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                          <div
                            className="bg-indigo-500 h-full rounded-full"
                            style={{ width: `${p.margin}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    {/* Refund Rate */}
                    <td className="py-3 px-4 font-mono text-slate-500">{p.refundRate}%</td>

                    {/* Status */}
                    <td className="py-3 px-4 text-right">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border ${getStatusBadge(
                          p.status
                        )}`}
                      >
                        {p.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
