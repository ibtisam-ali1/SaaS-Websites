import React, { useState } from 'react';
import { CustomerItem } from '../types';
import { 
  Users, 
  Search, 
  Filter, 
  Download, 
  ArrowUpDown, 
  Building, 
  ChevronLeft, 
  ChevronRight,
  ExternalLink,
  MoreVertical,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface CustomersViewProps {
  customers: CustomerItem[];
  onSelectCustomer: (customer: CustomerItem) => void;
  onOpenExport: () => void;
}

export const CustomersView: React.FC<CustomersViewProps> = ({
  customers,
  onSelectCustomer,
  onOpenExport,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [segmentFilter, setSegmentFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'revenue' | 'orders' | 'name'>('revenue');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  // Filter
  const filtered = customers.filter((c) => {
    const matchSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.company.toLowerCase().includes(searchQuery.toLowerCase());

    const matchSegment =
      segmentFilter === 'all' || c.segment.toLowerCase() === segmentFilter.toLowerCase();

    const matchStatus =
      statusFilter === 'all' || c.status.toLowerCase() === statusFilter.toLowerCase();

    return matchSearch && matchSegment && matchStatus;
  });

  // Sort
  const sorted = [...filtered].sort((a, b) => {
    let comparison = 0;
    if (sortBy === 'revenue') comparison = a.revenue - b.revenue;
    else if (sortBy === 'orders') comparison = a.orders - b.orders;
    else if (sortBy === 'name') comparison = a.name.localeCompare(b.name);

    return sortOrder === 'desc' ? -comparison : comparison;
  });

  // Pagination
  const totalPages = Math.ceil(sorted.length / pageSize) || 1;
  const paginated = sorted.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const toggleSort = (field: 'revenue' | 'orders' | 'name') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  const getSegmentBadge = (seg: CustomerItem['segment']) => {
    switch (seg) {
      case 'Enterprise':
        return 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800';
      case 'Mid-Market':
        return 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800';
      case 'SMB':
        return 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 border-cyan-200 dark:border-cyan-800';
      case 'Startup':
        return 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800';
      case 'At-Risk':
        return 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-800';
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Customer Directory & Segment Cohorts
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Total active account base: 12,480 accounts across 18 enterprise clusters.
          </p>
        </div>

        <button
          onClick={onOpenExport}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-semibold hover:bg-slate-800 dark:hover:bg-slate-100 transition-colors shadow-xs"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Customer Directory</span>
        </button>
      </div>

      {/* Summary metric bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Total Enterprise ARR', val: '$284,500', count: '48 Logos' },
          { label: 'Avg Customer LTV', val: '$34,500', count: '+12% YoY' },
          { label: 'Net Retention (NDR)', val: '119.4%', count: 'Top quartile' },
          { label: 'Churn Vulnerability', val: '8 Accounts', count: 'Intervention flagged', alert: true },
        ].map((s, i) => (
          <div key={i} className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
            <div className="text-[11px] text-slate-400 font-medium">{s.label}</div>
            <div className="text-lg font-bold font-mono text-slate-900 dark:text-white mt-0.5">
              {s.val}
            </div>
            <div className={`text-[10px] font-mono mt-0.5 ${s.alert ? 'text-rose-500 font-bold' : 'text-slate-400'}`}>
              {s.count}
            </div>
          </div>
        ))}
      </div>

      {/* Table Filter Controls */}
      <div className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search by customer name, email, company..."
            className="w-full bg-transparent border-none outline-none text-xs text-slate-900 dark:text-white placeholder-slate-400"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Segment Filter */}
          <select
            value={segmentFilter}
            onChange={(e) => {
              setSegmentFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs font-medium text-slate-700 dark:text-slate-300"
          >
            <option value="all">All Segments</option>
            <option value="enterprise">Enterprise</option>
            <option value="mid-market">Mid-Market</option>
            <option value="smb">SMB</option>
            <option value="startup">Startup</option>
            <option value="at-risk">At-Risk</option>
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-xs font-medium text-slate-700 dark:text-slate-300"
          >
            <option value="all">All Statuses</option>
            <option value="vip">VIP</option>
            <option value="active">Active</option>
            <option value="churn-risk">Churn-Risk</option>
            <option value="new">New</option>
          </select>
        </div>
      </div>

      {/* Main Table */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-950/50 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                <th
                  onClick={() => toggleSort('name')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Customer & Email</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => toggleSort('orders')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Orders</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => toggleSort('revenue')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Revenue</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4">Last Activity</th>
                <th className="py-3 px-4">Customer Segment</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    No customers found matching current filters.
                  </td>
                </tr>
              ) : (
                paginated.map((c) => (
                  <tr
                    key={c.id}
                    onClick={() => onSelectCustomer(c)}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer group"
                  >
                    {/* Name, Company & Email */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={c.avatar}
                          alt={c.name}
                          className="w-8 h-8 rounded-full object-cover shrink-0 ring-1 ring-slate-200 dark:ring-slate-700"
                        />
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 dark:text-white group-hover:text-indigo-500 transition-colors">
                            {c.name}
                          </div>
                          <div className="text-[11px] text-slate-400 truncate">
                            {c.email} • <span className="text-slate-500">{c.company}</span>
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Orders */}
                    <td className="py-3 px-4 font-mono font-semibold text-slate-800 dark:text-slate-200">
                      {c.orders}
                    </td>

                    {/* Revenue */}
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-white">
                      ${c.revenue.toLocaleString()}
                    </td>

                    {/* Last Activity */}
                    <td className="py-3 px-4 text-slate-500 dark:text-slate-400 font-mono text-[11px]">
                      {c.lastActivity}
                    </td>

                    {/* Segment */}
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border ${getSegmentBadge(
                          c.segment
                        )}`}
                      >
                        {c.segment}
                      </span>
                    </td>

                    {/* Action */}
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectCustomer(c);
                        }}
                        className="p-1 text-slate-400 hover:text-indigo-500 transition-colors"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>
            Showing {(currentPage - 1) * pageSize + 1} to{' '}
            {Math.min(currentPage * pageSize, sorted.length)} of {sorted.length} accounts
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-mono px-2">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
