import React, { useState } from 'react';
import { UserSettings, ThemeMode } from '../types';
import { 
  User, 
  Building2, 
  Bell, 
  Sliders, 
  Palette, 
  Database, 
  ShieldCheck, 
  Save, 
  Check, 
  RefreshCw, 
  Sun, 
  Moon, 
  Download,
  AlertTriangle
} from 'lucide-react';

interface SettingsViewProps {
  settings: UserSettings;
  onUpdateSettings: (newSettings: UserSettings) => void;
  theme: ThemeMode;
  onToggleTheme: (newTheme: ThemeMode) => void;
  onTriggerToast: (title: string, desc?: string, type?: 'success' | 'info') => void;
  onResetData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  theme,
  onToggleTheme,
  onTriggerToast,
  onResetData,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'business' | 'notifications' | 'dashboard' | 'theme' | 'data'>('profile');
  const [formData, setFormData] = useState<UserSettings>(settings);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      onUpdateSettings(formData);
      onTriggerToast('Settings Saved', 'Workspace configuration updated successfully.', 'success');
    }, 600);
  };

  const navTabs = [
    { id: 'profile' as const, label: 'Profile', icon: User },
    { id: 'business' as const, label: 'Business', icon: Building2 },
    { id: 'notifications' as const, label: 'Notifications', icon: Bell },
    { id: 'dashboard' as const, label: 'Dashboard preferences', icon: Sliders },
    { id: 'theme' as const, label: 'Theme', icon: Palette },
    { id: 'data' as const, label: 'Data preferences', icon: Database },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          Workspace Settings & Enterprise Governance
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Manage tenant identity, notification channels, role permissions, and visual preferences.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-6 items-start">
        {/* Settings Navigation Tabs */}
        <div className="w-full md:w-64 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2 space-y-1 shrink-0 shadow-xs">
          {navTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Panels */}
        <div className="flex-1 w-full rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
          <form onSubmit={handleSave} className="space-y-6">
            {/* 1. Profile Tab */}
            {activeTab === 'profile' && (
              <div className="space-y-5 animate-in fade-in-50">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Administrator Profile
                  </h3>
                  <p className="text-xs text-slate-400">
                    Personal credentials and authentication options
                  </p>
                </div>

                <div className="flex items-center gap-4">
                  <img
                    src={formData.profile.avatarUrl}
                    alt={formData.profile.fullName}
                    className="w-16 h-16 rounded-2xl object-cover ring-2 ring-indigo-500/40 shadow-md"
                  />
                  <div>
                    <span className="text-xs font-bold text-slate-900 dark:text-white block">
                      {formData.profile.fullName}
                    </span>
                    <span className="text-xs text-slate-400">{formData.profile.role}</span>
                    <div className="mt-1 flex items-center gap-1 text-[10px] font-mono text-emerald-500">
                      <ShieldCheck className="w-3 h-3" /> Two-Factor Enabled
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Full Name
                    </label>
                    <input
                      type="text"
                      value={formData.profile.fullName}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          profile: { ...formData.profile, fullName: e.target.value },
                        })
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Corporate Email
                    </label>
                    <input
                      type="email"
                      value={formData.profile.email}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          profile: { ...formData.profile, email: e.target.value },
                        })
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Timezone
                  </label>
                  <select
                    value={formData.profile.timezone}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        profile: { ...formData.profile, timezone: e.target.value },
                      })
                    }
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white"
                  >
                    <option value="America/New_York (UTC-04:00)">Eastern Time (US & Canada)</option>
                    <option value="America/Chicago (UTC-05:00)">Central Time (US & Canada)</option>
                    <option value="America/Los_Angeles (UTC-07:00)">Pacific Time (US & Canada)</option>
                    <option value="Europe/London (UTC+00:00)">London (GMT)</option>
                    <option value="Europe/Berlin (UTC+01:00)">Berlin / Frankfurt (CET)</option>
                    <option value="Asia/Tokyo (UTC+09:00)">Tokyo (JST)</option>
                  </select>
                </div>
              </div>
            )}

            {/* 2. Business Tab */}
            {activeTab === 'business' && (
              <div className="space-y-4 animate-in fade-in-50">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Business Entity & Fiscal Structure
                  </h3>
                  <p className="text-xs text-slate-400">
                    Corporate registration and accounting periods
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Legal Company Name
                    </label>
                    <input
                      type="text"
                      value={formData.business.companyName}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          business: { ...formData.business, companyName: e.target.value },
                        })
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Corporate Tax ID / EIN
                    </label>
                    <input
                      type="text"
                      value={formData.business.taxId}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          business: { ...formData.business, taxId: e.target.value },
                        })
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs font-mono text-slate-900 dark:text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Primary Currency
                    </label>
                    <select
                      value={formData.business.currency}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          business: { ...formData.business, currency: e.target.value },
                        })
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white"
                    >
                      <option value="USD ($)">USD ($)</option>
                      <option value="EUR (€)">EUR (€)</option>
                      <option value="GBP (£)">GBP (£)</option>
                      <option value="JPY (¥)">JPY (¥)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Fiscal Year Inception
                    </label>
                    <input
                      type="text"
                      value={formData.business.fiscalYearStart}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          business: { ...formData.business, fiscalYearStart: e.target.value },
                        })
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 3. Notifications Tab */}
            {activeTab === 'notifications' && (
              <div className="space-y-4 animate-in fade-in-50">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Dispatch Channels & Telemetry Alerts
                  </h3>
                  <p className="text-xs text-slate-400">
                    Configure thresholds for anomaly triggers and executive summaries
                  </p>
                </div>

                <div className="space-y-3">
                  {[
                    {
                      key: 'emailAlerts',
                      title: 'Critical Incident Email Alerts',
                      desc: 'Instant notice if API query latency spikes or anomaly is detected.',
                    },
                    {
                      key: 'aiAnomalyTriggers',
                      title: 'Autonomous AI Anomaly Engine',
                      desc: 'Real-time telemetry evaluation and automatic revenue synthesis alerts.',
                    },
                    {
                      key: 'weeklyDigest',
                      title: 'Executive Weekly Briefing Packet',
                      desc: 'Dispatch comprehensive PDF brief every Monday at 08:00 AM.',
                    },
                    {
                      key: 'slackWebhook',
                      title: 'Slack Channel Sync',
                      desc: 'Stream live conversions and critical alerts to #revenue-intelligence.',
                    },
                  ].map((item) => (
                    <label
                      key={item.key}
                      className="flex items-start justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer"
                    >
                      <div className="pr-4">
                        <div className="text-xs font-bold text-slate-900 dark:text-white">
                          {item.title}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">
                          {item.desc}
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={(formData.notifications as any)[item.key]}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            notifications: {
                              ...formData.notifications,
                              [item.key]: e.target.checked,
                            },
                          })
                        }
                        className="rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4 mt-0.5"
                      />
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* 4. Dashboard preferences */}
            {activeTab === 'dashboard' && (
              <div className="space-y-4 animate-in fade-in-50">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Dashboard Behavior & Rendering
                  </h3>
                  <p className="text-xs text-slate-400">
                    Adjust default timeframes, chart animations, and refresh cadence
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Default Temporal Window
                    </label>
                    <select
                      value={formData.dashboard.defaultTimeRange}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          dashboard: {
                            ...formData.dashboard,
                            defaultTimeRange: e.target.value as any,
                          },
                        })
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white"
                    >
                      <option value="today">Today (Hourly)</option>
                      <option value="7d">Last 7 Days</option>
                      <option value="30d">Last 30 Days (Recommended)</option>
                      <option value="90d">Last 90 Days</option>
                      <option value="year">This Year (Monthly)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Telemetry Auto-Refresh (Seconds)
                    </label>
                    <select
                      value={formData.dashboard.autoRefreshInterval}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          dashboard: {
                            ...formData.dashboard,
                            autoRefreshInterval: Number(e.target.value),
                          },
                        })
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white"
                    >
                      <option value={0}>Off (Manual only)</option>
                      <option value={15}>Every 15 seconds</option>
                      <option value={30}>Every 30 seconds</option>
                      <option value={60}>Every 60 seconds</option>
                    </select>
                  </div>
                </div>

                <label className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 cursor-pointer">
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">
                      Vector Chart Smooth Animations
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Enable spring physics on hover crosshairs and SVG bezier curves.
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={formData.dashboard.chartAnimation}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        dashboard: {
                          ...formData.dashboard,
                          chartAnimation: e.target.checked,
                        },
                      })
                    }
                    className="rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                  />
                </label>
              </div>
            )}

            {/* 5. Theme Tab */}
            {activeTab === 'theme' && (
              <div className="space-y-4 animate-in fade-in-50">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Interface Theme & Visual Atmosphere
                  </h3>
                  <p className="text-xs text-slate-400">
                    Switch between enterprise dark navy and crisp high-contrast light mode
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Dark Mode */}
                  <div
                    onClick={() => {
                      onToggleTheme('dark');
                      onTriggerToast('Theme Updated', 'Dark navy enterprise theme enabled.', 'info');
                    }}
                    className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                      theme === 'dark'
                        ? 'border-indigo-500 bg-indigo-500/10 ring-1 ring-indigo-500'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="p-2 rounded-xl bg-slate-950 text-indigo-400 border border-slate-800">
                        <Moon className="w-5 h-5" />
                      </div>
                      {theme === 'dark' && <Check className="w-4 h-4 text-indigo-500" />}
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      Dark Navy (Default Enterprise)
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Sophisticated midnight blue canvas with glowing indigo accents.
                    </p>
                  </div>

                  {/* Light Mode */}
                  <div
                    onClick={() => {
                      onToggleTheme('light');
                      onTriggerToast('Theme Updated', 'Crisp enterprise light theme enabled.', 'info');
                    }}
                    className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                      theme === 'light'
                        ? 'border-indigo-500 bg-indigo-500/10 ring-1 ring-indigo-500'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="p-2 rounded-xl bg-amber-50 text-amber-500 border border-amber-200">
                        <Sun className="w-5 h-5" />
                      </div>
                      {theme === 'light' && <Check className="w-4 h-4 text-indigo-500" />}
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      Crisp Enterprise Light
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-1">
                      High-contrast clean white layout engineered for executive clarity.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* 6. Data preferences Tab */}
            {activeTab === 'data' && (
              <div className="space-y-4 animate-in fade-in-50">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Data Retention & Storage Management
                  </h3>
                  <p className="text-xs text-slate-400">
                    Control historical audit logs, export archives, or reset simulated telemetry
                  </p>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        Raw Telemetry Retention Window
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Historical data storage policy for raw query events.
                      </div>
                    </div>
                    <span className="text-xs font-mono font-bold text-indigo-500">
                      365 Days
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-800">
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        Reset Mock Telemetry Stream
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Re-initialize baseline datasets, AI recommendations, and reports.
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={onResetData}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-rose-300 dark:border-rose-900 text-rose-500 text-xs font-bold hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Reset Mock Data</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Save Button Bar */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-3">
              <button
                type="submit"
                disabled={isSaving}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/20 transition-all disabled:opacity-50"
              >
                {isSaving ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Saving Changes...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Changes</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
