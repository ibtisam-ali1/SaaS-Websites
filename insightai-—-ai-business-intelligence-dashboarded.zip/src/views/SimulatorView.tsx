import React, { useState, useMemo } from 'react';
import { 
  Sliders, 
  Sparkles, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  ShieldCheck, 
  RotateCcw, 
  Download, 
  Save, 
  BrainCircuit, 
  Check, 
  ArrowRight,
  HelpCircle,
  BarChart3,
  Percent,
  Layers,
  Zap
} from 'lucide-react';
import { ScenarioConfig } from '../types';

interface SimulatorViewProps {
  onTriggerToast?: (title: string, desc?: string, type?: 'success' | 'info' | 'warning') => void;
  onOpenExportModal?: () => void;
}

const BASELINE_CONFIG: ScenarioConfig = {
  expansionPercent: 12,
  marketingBudgetPercent: 15,
  pricingAdjustmentPercent: 0,
  churnReductionPercent: 10,
  aiAddonAdoptionPercent: 24,
};

const PRESETS: { name: string; desc: string; config: ScenarioConfig }[] = [
  {
    name: 'Aggressive Scale (IPO / Series B)',
    desc: 'High marketing velocity & AI copilot upsells with moderate expansion.',
    config: {
      expansionPercent: 35,
      marketingBudgetPercent: 45,
      pricingAdjustmentPercent: 10,
      churnReductionPercent: 25,
      aiAddonAdoptionPercent: 65,
    }
  },
  {
    name: 'Recession Defense & Cash Moat',
    desc: 'Tight marketing spend, price resilience, and aggressive churn defense.',
    config: {
      expansionPercent: 5,
      marketingBudgetPercent: -15,
      pricingAdjustmentPercent: 5,
      churnReductionPercent: 40,
      aiAddonAdoptionPercent: 30,
    }
  },
  {
    name: 'Product-Led AI Upsell Surge',
    desc: 'Focus on maximum AI token adoption and enterprise expansion.',
    config: {
      expansionPercent: 40,
      marketingBudgetPercent: 10,
      pricingAdjustmentPercent: 15,
      churnReductionPercent: 30,
      aiAddonAdoptionPercent: 85,
    }
  },
  {
    name: 'Current Baseline Actuals',
    desc: 'Existing calibrated Q2 run-rate and historical metrics.',
    config: BASELINE_CONFIG
  }
];

export const SimulatorView: React.FC<SimulatorViewProps> = ({ 
  onTriggerToast,
  onOpenExportModal 
}) => {
  const [config, setConfig] = useState<ScenarioConfig>(BASELINE_CONFIG);
  const [activePreset, setActivePreset] = useState<string>('Current Baseline Actuals');
  const [isSaved, setIsSaved] = useState(false);

  // Baseline figures
  const baseARR = 1781040; // $1.78M ARR
  const baseNRR = 112.4;
  const baseRunway = 24.0;
  const baseRuleOf40 = 46.8;
  const baseLtvCac = 3.8;

  // Real-time calculations derived from parametric levers
  const simulationResults = useMemo(() => {
    // Levers impact on ARR
    const expansionMultiplier = 1 + (config.expansionPercent * 0.008);
    const marketingMultiplier = 1 + (config.marketingBudgetPercent * 0.005);
    const pricingMultiplier = 1 + (config.pricingAdjustmentPercent * 0.01);
    const churnMultiplier = 1 + (config.churnReductionPercent * 0.006);
    const aiMultiplier = 1 + (config.aiAddonAdoptionPercent * 0.0035);

    const compoundGrowth = (expansionMultiplier * marketingMultiplier * pricingMultiplier * churnMultiplier * aiMultiplier) - 1;
    const projectedARR = Math.round(baseARR * (1 + compoundGrowth));
    const arrDelta = projectedARR - baseARR;
    const arrDeltaPercent = ((arrDelta / baseARR) * 100).toFixed(1);

    // NRR calculation
    const projectedNRR = +(baseNRR + (config.expansionPercent * 0.25) + (config.churnReductionPercent * 0.18) + (config.aiAddonAdoptionPercent * 0.08)).toFixed(1);

    // Cash Runway
    const burnShift = (config.marketingBudgetPercent * 0.1) - (config.pricingAdjustmentPercent * 0.15) - (config.aiAddonAdoptionPercent * 0.05);
    const projectedRunway = Math.max(12, +(baseRunway - burnShift).toFixed(1));

    // Rule of 40 (Growth rate % + FCF Margin %)
    const projectedGrowthRate = 28 + (compoundGrowth * 20);
    const projectedFcfMargin = 18.8 - (config.marketingBudgetPercent * 0.12) + (config.pricingAdjustmentPercent * 0.25);
    const projectedRuleOf40 = +(projectedGrowthRate + projectedFcfMargin).toFixed(1);

    // LTV to CAC
    const projectedLtvCac = +(baseLtvCac + (config.pricingAdjustmentPercent * 0.04) + (config.churnReductionPercent * 0.03) - (config.marketingBudgetPercent * 0.015)).toFixed(2);

    return {
      projectedARR,
      arrDelta,
      arrDeltaPercent,
      projectedNRR,
      projectedRunway,
      projectedRuleOf40,
      projectedLtvCac,
    };
  }, [config]);

  // AI Narrative Synthesis based on current levers
  const aiNarrative = useMemo(() => {
    if (config.pricingAdjustmentPercent > 15 && config.churnReductionPercent < 15) {
      return {
        verdict: 'High Yield, Elevated Churn Vulnerability',
        analysis: `Increasing pricing by ${config.pricingAdjustmentPercent}% generates rapid short-term top-line yield (+${simulationResults.arrDeltaPercent}%), but current churn mitigation (${config.churnReductionPercent}%) is insufficient. We recommend coupling pricing shifts with preemptive VIP executive retention playbooks.`,
        action: 'Recommended: Target mid-market accounts with grandfathered pricing guarantees.'
      };
    }
    if (config.aiAddonAdoptionPercent > 50 && config.expansionPercent > 20) {
      return {
        verdict: 'Super-Linear Growth Velocity',
        analysis: `Deep AI copilot adoption (${config.aiAddonAdoptionPercent}%) creates strong operational gravity, driving Net Retention to ${simulationResults.projectedNRR}%. LTV:CAC expands to ${simulationResults.projectedLtvCac}x, comfortably clearing Rule of 40 benchmarks (${simulationResults.projectedRuleOf40}%).`,
        action: 'Recommended: Accelerate GPU infrastructure reservations to sustain low token latency.'
      };
    }
    if (config.marketingBudgetPercent < 0 && config.churnReductionPercent > 25) {
      return {
        verdict: 'Fortress Margin & Extended Runway',
        analysis: `Controlling GTM spend while maximizing customer retention extends runway to ${simulationResults.projectedRunway} months while defending profitable growth. Cash flow generation increases +$380K/quarter.`,
        action: 'Recommended: Reallocate freed budget into automated AI customer onboarding pipelines.'
      };
    }
    return {
      verdict: 'Balanced Sustainable Expansion',
      analysis: `This scenario produces +$${(simulationResults.arrDelta / 1000).toFixed(0)}K in incremental ARR (+${simulationResults.arrDeltaPercent}%) with an optimal Rule of 40 score of ${simulationResults.projectedRuleOf40}%. All key liquidity and solvency parameters remain in top quartile.`,
      action: 'Recommended: Commit scenario to Board of Directors financial presentation.'
    };
  }, [config, simulationResults]);

  const handleApplyPreset = (preset: typeof PRESETS[0]) => {
    setConfig(preset.config);
    setActivePreset(preset.name);
    setIsSaved(false);
    onTriggerToast?.('Scenario Preset Loaded', preset.name, 'info');
  };

  const handleCommitScenario = () => {
    setIsSaved(true);
    onTriggerToast?.(
      'Scenario Committed as Q3 Corporate Target',
      `Target ARR updated to $${(simulationResults.projectedARR / 1000000).toFixed(2)}M.`,
      'success'
    );
  };

  // 12-month Monte Carlo stochastic curve data
  const months = ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  const p50Points = months.map((m, idx) => {
    const progress = (idx + 1) / 12;
    const value = Math.round(baseARR + (simulationResults.arrDelta * progress));
    const p90 = Math.round(value * (1 + (0.04 * (idx + 1) / 4)));
    const p10 = Math.round(value * (1 - (0.035 * (idx + 1) / 4)));
    return { month: m, p50: value, p90, p10 };
  });

  return (
    <div className="space-y-6">
      {/* Top Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-linear-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <BrainCircuit className="w-3 h-3" /> Predictive AI Engine
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Model: Monte Carlo 10,000 Iterations
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white mt-1">
            Executive "What-If" AI Scenario Simulator
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5 max-w-2xl">
            Simulate the multi-variable impact of pricing changes, AI copilot adoption, marketing efficiency, and retention on enterprise ARR and cash runway.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              setConfig(BASELINE_CONFIG);
              setActivePreset('Current Baseline Actuals');
              setIsSaved(false);
              onTriggerToast?.('Simulator Reset', 'Restored to baseline actuals.', 'info');
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-700 bg-slate-800/80 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-750 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>

          <button
            onClick={() => {
              if (onOpenExportModal) {
                onOpenExportModal();
              } else {
                onTriggerToast?.('Model Export Generated', 'Scenario data exported to Excel/PDF.', 'success');
              }
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-700 bg-slate-800/80 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-750 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Model</span>
          </button>

          <button
            onClick={handleCommitScenario}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold shadow-lg transition-all ${
              isSaved
                ? 'bg-emerald-600 text-white shadow-emerald-600/20'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
            }`}
          >
            {isSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            <span>{isSaved ? 'Committed to Plan' : 'Commit to Target'}</span>
          </button>
        </div>
      </div>

      {/* Preset Strategy Selector */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {PRESETS.map((p) => {
          const isSelected = activePreset === p.name;
          return (
            <div
              key={p.name}
              onClick={() => handleApplyPreset(p)}
              className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-indigo-950/40 border-indigo-500 shadow-md ring-1 ring-indigo-500/50'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-xs font-bold ${isSelected ? 'text-indigo-400' : 'text-slate-900 dark:text-white'}`}>
                  {p.name}
                </span>
                {isSelected && (
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                )}
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                {p.desc}
              </p>
            </div>
          );
        })}
      </div>

      {/* Main Grid: Levers (Left) & Projected Outcomes (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Parametric Levers */}
        <div className="lg:col-span-6 space-y-4">
          <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-5">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-500" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Strategic Operating Levers
                </h3>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">
                Live Feedback Loop
              </span>
            </div>

            <div className="space-y-6">
              {/* Slider 1: Enterprise Expansion */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <span>Enterprise Account Expansion</span>
                    <span className="text-[10px] text-slate-400 font-normal">(-20% to +50%)</span>
                  </label>
                  <span className={`text-xs font-mono font-bold ${config.expansionPercent >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                    {config.expansionPercent >= 0 ? `+${config.expansionPercent}%` : `${config.expansionPercent}%`}
                  </span>
                </div>
                <input
                  type="range"
                  min="-20"
                  max="50"
                  step="1"
                  value={config.expansionPercent}
                  onChange={(e) => {
                    setConfig({ ...config, expansionPercent: Number(e.target.value) });
                    setActivePreset('Custom Calibration');
                    setIsSaved(false);
                  }}
                  className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                  <span>-20% Churn drag</span>
                  <span>Baseline (+12%)</span>
                  <span>+50% Hyper-expansion</span>
                </div>
              </div>

              {/* Slider 2: AI Copilot Add-on Adoption */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <span>AI Copilot & Analytics Tier Adoption</span>
                    <span className="text-[10px] text-indigo-400 font-normal">(High-Margin Add-on)</span>
                  </label>
                  <span className="text-xs font-mono font-bold text-indigo-400">
                    {config.aiAddonAdoptionPercent}% of Accounts
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="1"
                  value={config.aiAddonAdoptionPercent}
                  onChange={(e) => {
                    setConfig({ ...config, aiAddonAdoptionPercent: Number(e.target.value) });
                    setActivePreset('Custom Calibration');
                    setIsSaved(false);
                  }}
                  className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                  <span>0% Pilot</span>
                  <span>24% Current</span>
                  <span>100% Saturation</span>
                </div>
              </div>

              {/* Slider 3: Pricing Adjustment */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <span>SaaS Pricing & Packaging Shift</span>
                    <span className="text-[10px] text-slate-400 font-normal">(-15% to +35%)</span>
                  </label>
                  <span className={`text-xs font-mono font-bold ${config.pricingAdjustmentPercent >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                    {config.pricingAdjustmentPercent >= 0 ? `+${config.pricingAdjustmentPercent}%` : `${config.pricingAdjustmentPercent}%`}
                  </span>
                </div>
                <input
                  type="range"
                  min="-15"
                  max="35"
                  step="1"
                  value={config.pricingAdjustmentPercent}
                  onChange={(e) => {
                    setConfig({ ...config, pricingAdjustmentPercent: Number(e.target.value) });
                    setActivePreset('Custom Calibration');
                    setIsSaved(false);
                  }}
                  className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                  <span>-15% Discounting</span>
                  <span>Current Price</span>
                  <span>+35% Premium</span>
                </div>
              </div>

              {/* Slider 4: Marketing / GTM Efficiency */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <span>Marketing & Customer Acquisition Spend</span>
                    <span className="text-[10px] text-slate-400 font-normal">(-30% to +60%)</span>
                  </label>
                  <span className={`text-xs font-mono font-bold ${config.marketingBudgetPercent >= 0 ? 'text-indigo-400' : 'text-amber-400'}`}>
                    {config.marketingBudgetPercent >= 0 ? `+${config.marketingBudgetPercent}%` : `${config.marketingBudgetPercent}%`}
                  </span>
                </div>
                <input
                  type="range"
                  min="-30"
                  max="60"
                  step="5"
                  value={config.marketingBudgetPercent}
                  onChange={(e) => {
                    setConfig({ ...config, marketingBudgetPercent: Number(e.target.value) });
                    setActivePreset('Custom Calibration');
                    setIsSaved(false);
                  }}
                  className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                  <span>-30% Cash preservation</span>
                  <span>+15% Plan</span>
                  <span>+60% Hyper-growth</span>
                </div>
              </div>

              {/* Slider 5: Churn Reduction */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <span>AI Preemptive Churn Mitigation</span>
                    <span className="text-[10px] text-emerald-400 font-normal">(Retention Playbooks)</span>
                  </label>
                  <span className="text-xs font-mono font-bold text-emerald-500">
                    -{config.churnReductionPercent}% Churn
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="50"
                  step="2"
                  value={config.churnReductionPercent}
                  onChange={(e) => {
                    setConfig({ ...config, churnReductionPercent: Number(e.target.value) });
                    setActivePreset('Custom Calibration');
                    setIsSaved(false);
                  }}
                  className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
                  <span>0% Standard churn</span>
                  <span>-10% Current</span>
                  <span>-50% Maximum retention</span>
                </div>
              </div>
            </div>
          </div>

          {/* Dynamic AI Executive Synthesis Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-linear-to-br from-indigo-950/60 via-slate-900 to-slate-950 border border-indigo-500/30 text-white">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider">
                AI Strategic Synthesis
              </span>
              <span className="ml-auto text-[10px] font-mono px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {aiNarrative.verdict}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {aiNarrative.analysis}
            </p>
            <div className="mt-3 pt-3 border-t border-indigo-500/20 text-[11px] text-emerald-400 flex items-center gap-1.5 font-medium">
              <Zap className="w-3.5 h-3.5 shrink-0" />
              <span>{aiNarrative.action}</span>
            </div>
          </div>
        </div>

        {/* Right Column: Projected Real-time Outcomes & Visual Curve */}
        <div className="lg:col-span-6 space-y-4">
          {/* Key Output Metrics Bento */}
          <div className="grid grid-cols-2 gap-3">
            {/* Projected ARR */}
            <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
              <div className="text-[11px] text-slate-500 dark:text-slate-400 uppercase font-semibold">
                Projected ARR
              </div>
              <div className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                ${(simulationResults.projectedARR / 1000000).toFixed(2)}M
              </div>
              <div className="flex items-center gap-1 mt-1 text-xs font-medium">
                <span className={`inline-flex items-center font-mono ${
                  simulationResults.arrDelta >= 0 ? 'text-emerald-500' : 'text-rose-500'
                }`}>
                  {simulationResults.arrDelta >= 0 ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
                  {simulationResults.arrDelta >= 0 ? `+${simulationResults.arrDeltaPercent}%` : `${simulationResults.arrDeltaPercent}%`}
                </span>
                <span className="text-slate-400 text-[10px]">vs. $1.78M baseline</span>
              </div>
            </div>

            {/* Net Revenue Retention */}
            <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
              <div className="text-[11px] text-slate-500 dark:text-slate-400 uppercase font-semibold">
                Net Revenue Retention
              </div>
              <div className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                {simulationResults.projectedNRR}%
              </div>
              <div className="flex items-center gap-1 mt-1 text-xs font-medium">
                <span className="text-emerald-500 font-mono">
                  +{(simulationResults.projectedNRR - baseNRR).toFixed(1)}%
                </span>
                <span className="text-slate-400 text-[10px]">Top quartile SaaS</span>
              </div>
            </div>

            {/* Rule of 40 Score */}
            <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
              <div className="text-[11px] text-slate-500 dark:text-slate-400 uppercase font-semibold">
                Rule of 40 Index
              </div>
              <div className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                {simulationResults.projectedRuleOf40}%
              </div>
              <div className="flex items-center gap-1 mt-1 text-xs font-medium">
                <span className="text-indigo-400 font-mono">
                  {simulationResults.projectedRuleOf40 >= 40 ? 'SaaS Health: Prime' : 'Needs Optimization'}
                </span>
              </div>
            </div>

            {/* Cash Runway & LTV:CAC */}
            <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
              <div className="text-[11px] text-slate-500 dark:text-slate-400 uppercase font-semibold">
                Cash Runway / LTV:CAC
              </div>
              <div className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                {simulationResults.projectedRunway} mo
              </div>
              <div className="flex items-center gap-1 mt-1 text-xs font-medium">
                <span className="text-emerald-500 font-mono">
                  LTV:CAC {simulationResults.projectedLtvCac}x
                </span>
              </div>
            </div>
          </div>

          {/* Visual 12-Month Stochastic Monte Carlo Forecast Chart */}
          <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  12-Month Stochastic Confidence Band
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  P90 Bull Case, P50 Base Model, and P10 Stress Test
                </p>
              </div>
              <div className="flex items-center gap-3 text-[10px] font-mono">
                <span className="flex items-center gap-1 text-indigo-400">
                  <span className="w-2 h-2 rounded-full bg-indigo-400" /> P90 Bull
                </span>
                <span className="flex items-center gap-1 text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" /> P50 Base
                </span>
                <span className="flex items-center gap-1 text-amber-400">
                  <span className="w-2 h-2 rounded-full bg-amber-400" /> P10 Bear
                </span>
              </div>
            </div>

            {/* SVG Forecast Graph */}
            <div className="h-56 w-full relative">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 600 200" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="bullBand" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#818cf8" stopOpacity="0.35" />
                    <stop offset="100%" stopColor="#818cf8" stopOpacity="0.02" />
                  </linearGradient>
                  <linearGradient id="baseBand" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#34d399" stopOpacity="0.3" />
                    <stop offset="100%" stopColor="#34d399" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Horizontal Grid lines */}
                {[40, 80, 120, 160].map((y) => (
                  <line key={y} x1="0" y1={y} x2="600" y2={y} stroke="currentColor" strokeDasharray="3 3" className="text-slate-200 dark:text-slate-800" strokeWidth="1" />
                ))}

                {/* Shaded Area between P90 and P10 */}
                {(() => {
                  const ptsP90 = p50Points.map((p, i) => `${(i / 11) * 600},${190 - ((p.p90 - 1500000) / 1500000) * 160}`).join(' ');
                  const ptsP10Rev = [...p50Points].reverse().map((p, i) => `${((11 - i) / 11) * 600},${190 - ((p.p10 - 1500000) / 1500000) * 160}`).join(' ');
                  return (
                    <polygon points={`${ptsP90} ${ptsP10Rev}`} fill="url(#bullBand)" />
                  );
                })()}

                {/* P50 Line */}
                <polyline
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="3"
                  strokeLinecap="round"
                  points={p50Points.map((p, i) => `${(i / 11) * 600},${190 - ((p.p50 - 1500000) / 1500000) * 160}`).join(' ')}
                />

                {/* P90 Line */}
                <polyline
                  fill="none"
                  stroke="#818cf8"
                  strokeWidth="2"
                  strokeDasharray="4 4"
                  points={p50Points.map((p, i) => `${(i / 11) * 600},${190 - ((p.p90 - 1500000) / 1500000) * 160}`).join(' ')}
                />

                {/* P10 Line */}
                <polyline
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="2"
                  strokeDasharray="4 4"
                  points={p50Points.map((p, i) => `${(i / 11) * 600},${190 - ((p.p10 - 1500000) / 1500000) * 160}`).join(' ')}
                />

                {/* Dots on points */}
                {p50Points.map((p, i) => (
                  <circle
                    key={i}
                    cx={(i / 11) * 600}
                    cy={190 - ((p.p50 - 1500000) / 1500000) * 160}
                    r="4"
                    fill="#10b981"
                    stroke="#ffffff"
                    strokeWidth="1.5"
                  />
                ))}
              </svg>
            </div>

            {/* X-axis labels */}
            <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-2">
              {months.map((m) => (
                <span key={m}>{m}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
