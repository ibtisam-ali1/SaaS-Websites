import React, { useState } from 'react';
import { ReportItem } from '../types';
import { 
  FileText, 
  Plus, 
  Download, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  Eye, 
  Search, 
  FileSpreadsheet, 
  Sparkles,
  Share2,
  Trash2
} from 'lucide-react';

interface ReportsViewProps {
  reports: ReportItem[];
  onOpenCreateReport: () => void;
  onDownloadReport: (report: ReportItem) => void;
  onTriggerToast: (title: string, desc?: string, type?: 'success' | 'info') => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  reports,
  onOpenCreateReport,
  onDownloadReport,
  onTriggerToast,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewingReport, setViewingReport] = useState<ReportItem | null>(null);

  const filteredReports = reports.filter((r) => {
    const matchCat = selectedCategory === 'all' || r.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchSearch = r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchSearch;
  });

  const getFormatBadge = (fmt: string) => {
    switch (fmt) {
      case 'PDF':
        return 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900';
      case 'CSV':
        return 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900';
      case 'XLSX':
        return 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-900';
      default:
        return 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400';
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Executive & Automated Intelligence Reports
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Board-ready PDF packets, cohort spreadsheets, and scheduled recurring data warehouses.
          </p>
        </div>

        <button
          onClick={onOpenCreateReport}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/25 transition-all hover:scale-[1.02] shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Create Report</span>
        </button>
      </div>

      {/* Primary Report Category Cards (Sales, Customer, Revenue, Marketing) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            category: 'Sales Report',
            count: '4 Templates',
            desc: 'Quotas, closed-won deals, sales velocity, discount variance',
            icon: FileSpreadsheet,
            color: 'text-indigo-500 bg-indigo-500/10',
            filterKey: 'sales',
          },
          {
            category: 'Customer Report',
            count: '6 Templates',
            desc: 'Retention cohorts, churn indicators, health scoring, LTV analysis',
            icon: FileText,
            color: 'text-cyan-500 bg-cyan-500/10',
            filterKey: 'customer',
          },
          {
            category: 'Revenue Report',
            count: '8 Templates',
            desc: 'MRR breakdown, ARR bridge, payback velocity, gross margin',
            icon: FileText,
            color: 'text-emerald-500 bg-emerald-500/10',
            filterKey: 'revenue',
          },
          {
            category: 'Marketing Report',
            count: '3 Templates',
            desc: 'Campaign ROI, CAC payback, multi-touch attribution, conversion funnels',
            icon: FileSpreadsheet,
            color: 'text-purple-500 bg-purple-500/10',
            filterKey: 'marketing',
          },
        ].map((c) => {
          const Icon = c.icon;
          const isCurrent = selectedCategory === c.filterKey;

          return (
            <div
              key={c.category}
              onClick={() => setSelectedCategory(isCurrent ? 'all' : c.filterKey)}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                isCurrent
                  ? 'border-indigo-500 bg-indigo-500/5 ring-1 ring-indigo-500 shadow-md'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`p-2 rounded-xl ${c.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 font-semibold">
                  {c.count}
                </span>
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                {c.category}
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                {c.desc}
              </p>
            </div>
          );
        })}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-2 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2 px-3 py-1.5 w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search report titles, summaries..."
            className="w-full bg-transparent border-none outline-none text-xs text-slate-900 dark:text-white placeholder-slate-400"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto px-2">
          <span className="text-xs text-slate-400 font-medium">Filter:</span>
          <div className="flex items-center gap-1 overflow-x-auto">
            {['all', 'sales', 'customer', 'revenue', 'marketing', 'executive'].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold capitalize whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Reports Catalog Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredReports.map((report) => (
          <div
            key={report.id}
            className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs flex flex-col justify-between hover:border-indigo-500/50 transition-all group"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <span
                  className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${getFormatBadge(
                    report.format
                  )}`}
                >
                  {report.format}
                </span>
                <span className="text-[10px] font-mono text-slate-400">{report.fileSize}</span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1.5 group-hover:text-indigo-500 transition-colors">
                {report.title}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-3 mb-4">
                {report.description}
              </p>

              <div className="space-y-1.5 text-[11px] text-slate-400 pt-3 border-t border-slate-100 dark:border-slate-800/80">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>Schedule:</span>
                  </span>
                  <span className="font-semibold text-slate-700 dark:text-slate-300 font-mono">
                    {report.schedule}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Last Generated:</span>
                  <span className="font-mono text-slate-500">{report.lastGenerated}</span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
              <button
                onClick={() => setViewingReport(report)}
                className="flex items-center gap-1 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-500 transition-colors"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Preview</span>
              </button>

              <button
                onClick={() => onDownloadReport(report)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-600 hover:text-white text-xs font-bold transition-all shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Preview Report Modal */}
      {viewingReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm"
            onClick={() => setViewingReport(null)}
          />
          <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 z-10 animate-in fade-in-50 zoom-in-95">
            <div className="flex items-start justify-between mb-4">
              <div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-500 font-bold">
                  {viewingReport.category} Intelligence Report
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                  {viewingReport.title}
                </h3>
              </div>
              <button
                onClick={() => setViewingReport(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 mb-4 space-y-2 text-xs text-slate-600 dark:text-slate-300">
              <p>{viewingReport.description}</p>
              <div className="pt-2 flex flex-wrap gap-4 text-[11px] font-mono text-slate-400">
                <span>File Size: {viewingReport.fileSize}</span>
                <span>Format: {viewingReport.format}</span>
                <span>Dispatches: {viewingReport.downloadsCount} times</span>
              </div>
            </div>

            {/* Simulated report contents */}
            <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 text-xs space-y-3 font-mono bg-white dark:bg-slate-900">
              <div className="text-slate-400 text-[11px] uppercase tracking-wider">
                Executive Synthesis Snapshot:
              </div>
              <div className="text-slate-800 dark:text-slate-200">
                • Target Revenue: $148,420 (Variance: +14.8% vs planned run-rate)
                <br />
                • Active Enterprise Logos: 12,480 accounts (NDR: 119%)
                <br />
                • AI Anomaly Status: 0 critical vulnerabilities, 1 expansion vector active
              </div>
            </div>

            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                onClick={() => setViewingReport(null)}
                className="px-4 py-2 text-xs text-slate-400 hover:text-white"
              >
                Close
              </button>
              <button
                onClick={() => {
                  onDownloadReport(viewingReport);
                  setViewingReport(null);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-500 shadow-md"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export File ({viewingReport.format})</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
