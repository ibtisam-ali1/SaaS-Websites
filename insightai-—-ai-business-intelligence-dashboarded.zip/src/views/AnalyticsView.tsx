import React, { useState } from 'react';
import { AreaChart } from '../components/charts/AreaChart';
import { DonutChart } from '../components/charts/DonutChart';
import { BarChart } from '../components/charts/BarChart';
import { REVENUE_SERIES, CATEGORY_SALES, CUSTOMER_GROWTH_DATA } from '../data/mockData';
import { 
  Download, 
  Calendar, 
  Filter, 
  Layers, 
  Globe2, 
  Clock, 
  Sparkles, 
  TrendingUp, 
  ArrowUpRight 
} from 'lucide-react';

interface AnalyticsViewProps {
  onOpenExport: () => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ onOpenExport }) => {
  const [activeGranularity, setActiveGranularity] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('monthly');
  const [selectedMetric, setSelectedMetric] = useState<'revenue' | 'mrr' | 'seats' | 'churn' | 'ltv'>('revenue');

  // Map tabs to data series
  const getChartData = () => {
    switch (activeGranularity) {
      case 'daily':
        return REVENUE_SERIES['today'];
      case 'weekly':
        return REVENUE_SERIES['7d'];
      case 'yearly':
        return REVENUE_SERIES['year'];
      case 'monthly':
      default:
        return REVENUE_SERIES['30d'];
    }
  };

  const regionalData = [
    { country: 'United States', code: 'US', revenue: 68400, percent: 46.1, change: '+18.4%' },
    { country: 'United Kingdom', code: 'UK', revenue: 28200, percent: 19.0, change: '+12.1%' },
    { country: 'Germany & EU', code: 'DE', revenue: 22400, percent: 15.1, change: '+9.4%' },
    { country: 'Japan & APAC', code: 'JP', revenue: 16800, percent: 11.3, change: '+24.2%' },
    { country: 'Canada', code: 'CA', revenue: 12620, percent: 8.5, change: '+6.8%' },
  ];

  const hourlyDistribution = [
    { hour: '00-03', label: '12 AM', level: 1, queries: '1,240' },
    { hour: '03-06', label: '3 AM', level: 1, queries: '890' },
    { hour: '06-09', label: '6 AM', level: 2, queries: '4,100' },
    { hour: '09-12', label: '9 AM', level: 4, queries: '11,400' },
    { hour: '12-15', label: '12 PM', level: 3, queries: '8,900' },
    { hour: '15-18', label: '3 PM', level: 4, queries: '12,800' },
    { hour: '18-21', label: '6 PM - 9 PM (Peak)', level: 5, queries: '24,600', peak: true },
    { hour: '21-24', label: '9 PM', level: 3, queries: '7,400' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Advanced Analytics & Cohort Modeling
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Cross-dimensional analysis across temporal frequency, customer retention, and regional expansion.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Granularity Tabs */}
          <div className="p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60 flex items-center">
            {(['daily', 'weekly', 'monthly', 'yearly'] as const).map((g) => (
              <button
                key={g}
                onClick={() => setActiveGranularity(g)}
                className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize transition-all ${
                  activeGranularity === g
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {g}
              </button>
            ))}
          </div>

          <button
            onClick={onOpenExport}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-semibold hover:bg-slate-800 dark:hover:bg-slate-100 transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Analytics</span>
          </button>
        </div>
      </div>

      {/* Metric Selector Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {[
          { id: 'revenue', label: 'Total Revenue', value: '$148,420', change: '+14.8%' },
          { id: 'mrr', label: 'Monthly Recurring (MRR)', value: '$126,800', change: '+11.2%' },
          { id: 'seats', label: 'Active Enterprise Seats', value: '48,290', change: '+22.5%' },
          { id: 'churn', label: 'Net Revenue Churn', value: '0.8%', change: '-0.3%', positive: true },
          { id: 'ltv', label: 'Enterprise LTV', value: '$34,500', change: '+8.4%' },
        ].map((m) => (
          <button
            key={m.id}
            onClick={() => setSelectedMetric(m.id as any)}
            className={`p-3.5 rounded-2xl border text-left transition-all ${
              selectedMetric === m.id
                ? 'border-indigo-500 bg-indigo-500/10 text-slate-900 dark:text-white ring-1 ring-indigo-500'
                : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:border-slate-300'
            }`}
          >
            <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">{m.label}</div>
            <div className="text-base sm:text-lg font-bold font-mono text-slate-900 dark:text-white mt-1">
              {m.value}
            </div>
            <div className="text-[10px] font-mono text-emerald-500 mt-0.5">{m.change} vs prior</div>
          </button>
        ))}
      </div>

      {/* Main Interactive Chart */}
      <div className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
              Temporal Trajectory ({activeGranularity.toUpperCase()})
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
              Confidence: 98.4%
            </span>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Telemetry source: Snowflake Enterprise Sync
          </span>
        </div>

        <AreaChart
          data={getChartData()}
          showComparison={true}
          valuePrefix="$"
          height={320}
        />
      </div>

      {/* Two columns: Hourly Activity Heatmap + Geographic Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hourly Distribution (peaks 6 PM - 9 PM) */}
        <div className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-indigo-500" />
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Diurnal Query Concurrency (Hourly)
                </h3>
                <p className="text-xs text-slate-400">
                  Telemetry pattern: activity peaks sharply between 6 PM and 9 PM
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-semibold">
              Peak Window: 18:00 - 21:00
            </span>
          </div>

          <div className="space-y-3 mt-4">
            {hourlyDistribution.map((h) => {
              const widths = [12, 8, 25, 60, 45, 68, 100, 38];
              const idx = hourlyDistribution.indexOf(h);
              const w = widths[idx];

              return (
                <div key={h.hour} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className={`font-medium ${h.peak ? 'text-indigo-500 font-bold' : 'text-slate-600 dark:text-slate-400'}`}>
                      {h.label}
                    </span>
                    <span className="font-mono text-slate-500 dark:text-slate-400 text-[11px]">
                      {h.queries} queries {h.peak && '🔥 Peak'}
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        h.peak
                          ? 'bg-gradient-to-r from-indigo-500 to-cyan-400'
                          : 'bg-slate-400 dark:bg-slate-700'
                      }`}
                      style={{ width: `${w}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Regional Performance */}
        <div className="p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Globe2 className="w-4 h-4 text-indigo-500" />
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Geographic Revenue Distribution
                </h3>
                <p className="text-xs text-slate-400">
                  Global market penetration and regional currency yield
                </p>
              </div>
            </div>
            <span className="text-xs font-mono text-slate-400">5 Active Zones</span>
          </div>

          <div className="space-y-3.5">
            {regionalData.map((reg) => (
              <div key={reg.code} className="p-3 rounded-xl border border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-950/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-500 font-mono text-xs font-bold flex items-center justify-center">
                    {reg.code}
                  </span>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 dark:text-white">{reg.country}</h5>
                    <span className="text-[10px] text-slate-400 font-mono">{reg.percent}% of gross revenue</span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs font-bold font-mono text-slate-900 dark:text-white">
                    ${reg.revenue.toLocaleString()}
                  </div>
                  <span className="text-[10px] font-mono text-emerald-500 font-semibold">
                    {reg.change} YoY
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
