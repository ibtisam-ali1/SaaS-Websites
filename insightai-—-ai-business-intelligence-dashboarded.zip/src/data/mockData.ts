import { 
  MetricCardData, 
  RevenueDataPoint, 
  CategorySalesData, 
  CustomerGrowthPoint, 
  FunnelStage, 
  TrafficSource, 
  AiInsightItem, 
  ReportItem, 
  CustomerItem, 
  ProductPerformanceItem,
  UserSettings,
  NotificationItem
} from '../types';

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'Revenue Surge Flagged by AI',
    message: 'Monthly recurring revenue increased 14.8% following enterprise expansion deals.',
    timestamp: '12 mins ago',
    read: false,
    type: 'success',
    category: 'ai'
  },
  {
    id: 'notif-2',
    title: 'Diurnal Query Concurrency Peak',
    message: 'System telemetry recorded peak workload (24,600 queries/hr) during the 6-9 PM window.',
    timestamp: '1 hour ago',
    read: false,
    type: 'info',
    category: 'system'
  },
  {
    id: 'notif-3',
    title: 'Churn Prevention Intervention',
    message: '8 Mid-Market accounts marked as at-risk due to reduced daily active queries.',
    timestamp: '3 hours ago',
    read: true,
    type: 'warning',
    category: 'alert'
  },
  {
    id: 'notif-4',
    title: 'Scheduled Executive PDF Generated',
    message: 'Sales & Revenue Performance Report for executive committee is ready for download.',
    timestamp: 'Yesterday',
    read: true,
    type: 'info',
    category: 'report'
  }
];

export const INITIAL_METRICS: MetricCardData[] = [
  {
    id: 'revenue',
    title: 'Total Revenue',
    value: '$148,420.00',
    numericValue: 148420,
    changePercent: 14.8,
    changeType: 'positive',
    comparisonPeriod: 'vs. last month',
    sparklineData: [42, 48, 51, 49, 62, 58, 71, 78, 85, 92, 88, 104, 115, 128, 148],
    prefix: '$',
    sublabel: 'Target: $140,000'
  },
  {
    id: 'orders',
    title: 'Completed Orders',
    value: '3,842',
    numericValue: 3842,
    changePercent: 8.2,
    changeType: 'positive',
    comparisonPeriod: 'vs. last month',
    sparklineData: [210, 240, 220, 260, 280, 270, 310, 320, 340, 330, 370, 390],
    sublabel: '98.4% fulfillment'
  },
  {
    id: 'customers',
    title: 'Active Customers',
    value: '12,480',
    numericValue: 12480,
    changePercent: 19.4,
    changeType: 'positive',
    comparisonPeriod: 'vs. last month',
    sparklineData: [8400, 8800, 9200, 9600, 10100, 10700, 11200, 11800, 12480],
    sublabel: '840 new this month'
  },
  {
    id: 'conversion',
    title: 'Conversion Rate',
    value: '3.42%',
    numericValue: 3.42,
    changePercent: 0.6,
    changeType: 'positive',
    comparisonPeriod: 'vs. industry avg (2.8%)',
    sparklineData: [2.9, 3.0, 3.1, 2.9, 3.2, 3.3, 3.1, 3.4, 3.42],
    suffix: '%',
    sublabel: '+0.6% vs benchmark'
  },
  {
    id: 'aov',
    title: 'Average Order Value',
    value: '$112.50',
    numericValue: 112.5,
    changePercent: 4.1,
    changeType: 'positive',
    comparisonPeriod: 'vs. last month',
    sparklineData: [98, 102, 101, 105, 104, 108, 109, 111, 112.5],
    prefix: '$',
    sublabel: 'Top tier: $240.00'
  }
];

export const REVENUE_SERIES: Record<string, RevenueDataPoint[]> = {
  '30d': [
    { date: 'May 01', revenue: 3820, previousRevenue: 3400, target: 3600, orders: 112 },
    { date: 'May 03', revenue: 4190, previousRevenue: 3700, target: 3800, orders: 125 },
    { date: 'May 06', revenue: 4620, previousRevenue: 3950, target: 4000, orders: 139 },
    { date: 'May 09', revenue: 4350, previousRevenue: 4100, target: 4100, orders: 130 },
    { date: 'May 12', revenue: 5120, previousRevenue: 4300, target: 4200, orders: 154 },
    { date: 'May 15', revenue: 5480, previousRevenue: 4600, target: 4400, orders: 168 },
    { date: 'May 18', revenue: 5200, previousRevenue: 4750, target: 4500, orders: 159 },
    { date: 'May 21', revenue: 6100, previousRevenue: 5100, target: 4800, orders: 184 },
    { date: 'May 24', revenue: 6420, previousRevenue: 5300, target: 5000, orders: 195 },
    { date: 'May 27', revenue: 6890, previousRevenue: 5600, target: 5200, orders: 210 },
    { date: 'May 30', revenue: 7420, previousRevenue: 6100, target: 5500, orders: 232 },
  ],
  '7d': [
    { date: 'Mon', revenue: 4820, previousRevenue: 4200, target: 4500, orders: 145 },
    { date: 'Tue', revenue: 5390, previousRevenue: 4600, target: 4800, orders: 162 },
    { date: 'Wed', revenue: 5910, previousRevenue: 5100, target: 5000, orders: 178 },
    { date: 'Thu', revenue: 5620, previousRevenue: 5300, target: 5100, orders: 169 },
    { date: 'Fri', revenue: 6840, previousRevenue: 5900, target: 5500, orders: 205 },
    { date: 'Sat', revenue: 7450, previousRevenue: 6400, target: 6000, orders: 228 },
    { date: 'Sun', revenue: 7980, previousRevenue: 6700, target: 6300, orders: 242 },
  ],
  'today': [
    { date: '00:00', revenue: 210, previousRevenue: 180, target: 200, orders: 6 },
    { date: '04:00', revenue: 140, previousRevenue: 120, target: 150, orders: 4 },
    { date: '08:00', revenue: 680, previousRevenue: 520, target: 600, orders: 21 },
    { date: '12:00', revenue: 1420, previousRevenue: 1100, target: 1200, orders: 43 },
    { date: '16:00', revenue: 1980, previousRevenue: 1600, target: 1700, orders: 60 },
    { date: '18:00', revenue: 2650, previousRevenue: 2100, target: 2200, orders: 81 },
    { date: '21:00', revenue: 2940, previousRevenue: 2400, target: 2400, orders: 89 },
    { date: '23:00', revenue: 1890, previousRevenue: 1500, target: 1600, orders: 58 },
  ],
  '90d': [
    { date: 'Week 1', revenue: 28400, previousRevenue: 24100, target: 26000, orders: 860 },
    { date: 'Week 3', revenue: 31200, previousRevenue: 26800, target: 28500, orders: 940 },
    { date: 'Week 5', revenue: 34800, previousRevenue: 29200, target: 31000, orders: 1050 },
    { date: 'Week 7', revenue: 38200, previousRevenue: 32400, target: 34000, orders: 1160 },
    { date: 'Week 9', revenue: 41900, previousRevenue: 35000, target: 37500, orders: 1270 },
    { date: 'Week 11', revenue: 45600, previousRevenue: 38900, target: 41000, orders: 1390 },
  ],
  'year': [
    { date: 'Jan', revenue: 84000, previousRevenue: 68000, target: 75000, orders: 2540 },
    { date: 'Feb', revenue: 91000, previousRevenue: 72000, target: 82000, orders: 2750 },
    { date: 'Mar', revenue: 104000, previousRevenue: 81000, target: 92000, orders: 3140 },
    { date: 'Apr', revenue: 118000, previousRevenue: 94000, target: 105000, orders: 3580 },
    { date: 'May', revenue: 132000, previousRevenue: 106000, target: 120000, orders: 3990 },
    { date: 'Jun', revenue: 148420, previousRevenue: 118000, target: 135000, orders: 4480 },
  ]
};

export const CATEGORY_SALES: CategorySalesData[] = [
  { id: 'cat-a', category: 'Enterprise AI Copilot', revenue: 58400, percentage: 39.3, growth: 24.6, color: '#4f46e5' },
  { id: 'cat-b', category: 'Cloud Data Pipeline', revenue: 38200, percentage: 25.7, growth: 16.2, color: '#06b6d4' },
  { id: 'cat-c', category: 'Predictive Analytics Pro', revenue: 26800, percentage: 18.1, growth: 9.8, color: '#3b82f6' },
  { id: 'cat-d', category: 'Automated Reporting API', revenue: 15400, percentage: 10.4, growth: 12.1, color: '#8b5cf6' },
  { id: 'cat-e', category: 'Developer Add-ons', revenue: 9620, percentage: 6.5, growth: -2.4, color: '#ec4899' },
];

export const CUSTOMER_GROWTH_DATA: CustomerGrowthPoint[] = [
  { period: 'Jan', newCustomers: 420, returningCustomers: 1850, churnedCustomers: 45 },
  { period: 'Feb', newCustomers: 510, returningCustomers: 2100, churnedCustomers: 52 },
  { period: 'Mar', newCustomers: 640, returningCustomers: 2450, churnedCustomers: 48 },
  { period: 'Apr', newCustomers: 720, returningCustomers: 2890, churnedCustomers: 61 },
  { period: 'May', newCustomers: 810, returningCustomers: 3340, churnedCustomers: 56 },
  { period: 'Jun', newCustomers: 940, returningCustomers: 3880, churnedCustomers: 42 },
];

export const FUNNEL_STAGES: FunnelStage[] = [
  { stage: 'Unique Visitors', count: 184500, percentage: 100, conversionFromPrevious: 100, dropoffRate: 0 },
  { stage: 'Engaged Leads', count: 42800, percentage: 23.2, conversionFromPrevious: 23.2, dropoffRate: 76.8 },
  { stage: 'Trial Signups', count: 14200, percentage: 7.7, conversionFromPrevious: 33.2, dropoffRate: 66.8 },
  { stage: 'Product Activated', count: 8650, percentage: 4.7, conversionFromPrevious: 60.9, dropoffRate: 39.1 },
  { stage: 'Paid Subscriptions', count: 3842, percentage: 2.1, conversionFromPrevious: 44.4, dropoffRate: 55.6 },
];

export const TRAFFIC_SOURCES: TrafficSource[] = [
  { source: 'Direct Enterprise Nav', visitors: 64200, percentage: 34.8, conversionRate: 4.8, revenue: 68400, trend: 14.2 },
  { source: 'Organic Search (SEO)', visitors: 48900, percentage: 26.5, conversionRate: 3.2, revenue: 39800, trend: 8.7 },
  { source: 'Referral & Integrations', visitors: 32400, percentage: 17.6, conversionRate: 3.9, revenue: 26200, trend: 22.4 },
  { source: 'Paid B2B Acquisition', visitors: 24600, percentage: 13.3, conversionRate: 2.1, revenue: 11400, trend: -3.5 },
  { source: 'Social & Industry Tech', visitors: 14400, percentage: 7.8, conversionRate: 1.6, revenue: 2620, trend: 5.1 },
];

export const AI_INSIGHTS: AiInsightItem[] = [
  {
    id: 'ins-1',
    title: 'Revenue increased 14.8% compared with last month.',
    summary: 'Accelerated enterprise tier adoption and reduced net customer churn generated an additional $18,920 in monthly recurring revenue.',
    priority: 'high',
    category: 'Revenue',
    impact: '+$18,920 ARR boost',
    impactValue: 18920,
    date: 'Updated 10m ago',
    details: 'The growth is primarily driven by expansion in the Enterprise AI Copilot plan (up 24.6%) and a 12% increase in annual contracts. The average contract value grew from $9,800 to $11,400 across 42 new mid-market and enterprise logos.',
    actionLabel: 'View Expansion Cohort',
    applied: false,
    metricsAffected: ['Revenue', 'ARR', 'Net Retention'],
    simulationData: { current: 148420, projected: 167340, difference: '+12.7% next month' }
  },
  {
    id: 'ins-2',
    title: 'Customer activity peaks between 6 PM and 9 PM.',
    summary: 'Data query concurrency spikes 3.4x during evening batch analysis windows, creating an optimal opportunity for automated sync workflows.',
    priority: 'medium',
    category: 'Operations',
    impact: '32% faster sync latency',
    impactValue: 3200,
    date: 'Updated 1h ago',
    details: 'User event telemetry across North American and European clusters confirms enterprise data teams run scheduled batch syntheses between 18:00 and 21:00 UTC. Allocating elastic compute during this 3-hour window avoids queuing and improves UX satisfaction score by 14 points.',
    actionLabel: 'Schedule Auto-Scale Pipeline',
    applied: false,
    metricsAffected: ['Query Speed', 'Server Capacity', 'User NPS'],
    simulationData: { current: 420, projected: 140, difference: '-66% query queue delay' }
  },
  {
    id: 'ins-3',
    title: 'Product category A generated the highest growth.',
    summary: '“Enterprise AI Copilot” accounted for $58,400 (39.3%) of total revenue with a 24.6% month-over-month surge.',
    priority: 'critical',
    category: 'Product',
    impact: '+$24,600 cross-sell potential',
    impactValue: 24600,
    date: 'Updated 2h ago',
    details: 'Telemetry indicates that 72% of users who activate the AI Copilot expand their pipeline ingestion capacity within 21 days. Packaging Copilot with Cloud Data Pipeline could accelerate deal velocity by an estimated 18 days.',
    actionLabel: 'Deploy Cross-Sell Bundle',
    applied: true,
    metricsAffected: ['Product Adoption', 'AOV', 'LTV'],
    simulationData: { current: 58400, projected: 76500, difference: '+31% pipeline pipeline value' }
  },
  {
    id: 'ins-4',
    title: 'Churn risk detected in 8 Mid-Market accounts.',
    summary: 'Inactivity signals in API usage and seat logins during the last 14 days suggest potential renewal drop-off without intervention.',
    priority: 'critical',
    category: 'Retention',
    impact: '$34,200 ARR at risk',
    impactValue: 34200,
    date: 'Updated 3h ago',
    details: '8 accounts have exhibited a 45% decline in daily active query volume over the past 2 weeks. Automated health check recommends dispatching CS proactive outreach and sharing the automated query migration guide.',
    actionLabel: 'Trigger CS Outreach Flow',
    applied: false,
    metricsAffected: ['Churn Rate', 'Net Revenue Retention'],
    simulationData: { current: 3.4, projected: 2.1, difference: '-1.3% target churn' }
  },
  {
    id: 'ins-5',
    title: 'Checkout drop-off at billing step decreased by 18%.',
    summary: 'Recent simplification of credit card and invoice billing decreased drop-off from 32% to 14% on the self-serve portal.',
    priority: 'low',
    category: 'Marketing',
    impact: '+142 converted subscriptions',
    impactValue: 14200,
    date: 'Updated 5h ago',
    details: 'Removing the mandatory phone number field and adding instant VAT validation reduced funnel friction significantly in the EMEA region.',
    actionLabel: 'Review Funnel Telemetry',
    applied: true,
    metricsAffected: ['Conversion Rate', 'Checkout Velocity']
  },
  {
    id: 'ins-6',
    title: 'Automated Pricing Optimization recommendation.',
    summary: 'Market elasticity testing shows willingness to pay for high-volume API quotas is 22% higher than standard pricing.',
    priority: 'high',
    category: 'Revenue',
    impact: '+$41,000 projected annual uplift',
    impactValue: 41000,
    date: 'Updated Yesterday',
    details: 'Enterprises consuming >50M tokens/month exhibit 98% price insensitivity on burst rates. Adjusting overage tier from $0.08 to $0.095 per 10k calls generates margin without impacting retention.',
    actionLabel: 'Simulate Pricing Matrix',
    applied: false,
    metricsAffected: ['Gross Margin', 'Revenue per Account']
  }
];

export const INITIAL_REPORTS: ReportItem[] = [
  {
    id: 'rep-1',
    title: 'Sales & Revenue Performance Report',
    description: 'Comprehensive analysis of quarterly sales velocity, gross merchandise value, discount impact, and regional pipeline conversion.',
    category: 'Sales',
    schedule: 'Weekly (Mondays 08:00)',
    lastGenerated: 'Today, 08:00 AM',
    fileSize: '4.2 MB',
    format: 'PDF',
    downloadsCount: 142,
    status: 'Ready'
  },
  {
    id: 'rep-2',
    title: 'Customer Cohort & Retention Analysis',
    description: 'Deep dive into 30-day, 60-day, and 90-day retention matrices, net dollar retention (NDR), churn causes, and customer health scoring.',
    category: 'Customer',
    schedule: 'Monthly (1st of month)',
    lastGenerated: 'Jun 01, 2026',
    fileSize: '6.8 MB',
    format: 'XLSX',
    downloadsCount: 89,
    status: 'Ready'
  },
  {
    id: 'rep-3',
    title: 'Executive Financial & Unit Economics Brief',
    description: 'High-level board summary covering MRR, ARR, CAC payback period, LTV:CAC ratio, gross margins, and runway forecast models.',
    category: 'Executive',
    schedule: 'Monthly (End of month)',
    lastGenerated: 'Yesterday, 18:30 PM',
    fileSize: '3.1 MB',
    format: 'PDF',
    downloadsCount: 215,
    status: 'Ready'
  },
  {
    id: 'rep-4',
    title: 'Marketing Attribution & ROI Breakdown',
    description: 'Multitouch attribution model tracking visitor-to-paid velocity across Organic Search, Paid B2B, Referral, and Event campaigns.',
    category: 'Marketing',
    schedule: 'Bi-weekly',
    lastGenerated: 'May 28, 2026',
    fileSize: '5.4 MB',
    format: 'CSV',
    downloadsCount: 64,
    status: 'Ready'
  },
  {
    id: 'rep-5',
    title: 'Product Usage & Feature Adoption Telemetry',
    description: 'Event-level telemetry breakdown of core AI tools, query latency metrics, active seat ratios, and workflow friction points.',
    category: 'Customer',
    schedule: 'Automated Daily',
    lastGenerated: 'Today, 04:00 AM',
    fileSize: '8.9 MB',
    format: 'PDF',
    downloadsCount: 178,
    status: 'Ready'
  },
  {
    id: 'rep-6',
    title: 'Revenue Forecast & Scenario Simulation',
    description: 'Monte Carlo simulation models projecting Q3/Q4 revenue under conservative, baseline, and aggressive enterprise sales pipelines.',
    category: 'Revenue',
    schedule: 'On-Demand',
    lastGenerated: 'Jun 04, 2026',
    fileSize: '2.7 MB',
    format: 'PDF',
    downloadsCount: 51,
    status: 'Ready'
  }
];

export const INITIAL_CUSTOMERS: CustomerItem[] = [
  {
    id: 'cust-1',
    name: 'Sarah Jenkins',
    email: 's.jenkins@acmecorp.global',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    company: 'Acme Global Technologies',
    orders: 48,
    revenue: 42800,
    lastActivity: '4 mins ago',
    segment: 'Enterprise',
    status: 'VIP',
    location: 'San Francisco, USA',
    joinDate: 'Jan 2024',
    npsScore: 10
  },
  {
    id: 'cust-2',
    name: 'Marcus Vance',
    email: 'm.vance@solarisdata.io',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    company: 'Solaris Cloud Data',
    orders: 34,
    revenue: 31200,
    lastActivity: '18 mins ago',
    segment: 'Enterprise',
    status: 'Active',
    location: 'London, UK',
    joinDate: 'Mar 2024',
    npsScore: 9
  },
  {
    id: 'cust-3',
    name: 'Elena Rostova',
    email: 'elena@novacrest.tech',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    company: 'NovaCrest AI Labs',
    orders: 26,
    revenue: 24500,
    lastActivity: '1 hour ago',
    segment: 'Mid-Market',
    status: 'Active',
    location: 'Berlin, Germany',
    joinDate: 'Jul 2024',
    npsScore: 9
  },
  {
    id: 'cust-4',
    name: 'David Kalu',
    email: 'dkalu@apexfintech.com',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    company: 'Apex Financial Systems',
    orders: 19,
    revenue: 18900,
    lastActivity: '3 hours ago',
    segment: 'Mid-Market',
    status: 'Active',
    location: 'Toronto, Canada',
    joinDate: 'Oct 2024',
    npsScore: 8
  },
  {
    id: 'cust-5',
    name: 'Aiko Tanaka',
    email: 'tanaka.a@zenith-robotics.jp',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    company: 'Zenith Robotics Tokyo',
    orders: 14,
    revenue: 15400,
    lastActivity: '5 hours ago',
    segment: 'Mid-Market',
    status: 'VIP',
    location: 'Tokyo, Japan',
    joinDate: 'Nov 2024',
    npsScore: 10
  },
  {
    id: 'cust-6',
    name: 'Liam O’Connor',
    email: 'liam@hyperionlogistics.eu',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    company: 'Hyperion Logistics',
    orders: 8,
    revenue: 7200,
    lastActivity: '12 hours ago',
    segment: 'SMB',
    status: 'Churn-Risk',
    location: 'Dublin, Ireland',
    joinDate: 'Feb 2025',
    npsScore: 5
  },
  {
    id: 'cust-7',
    name: 'Camila Rodriguez',
    email: 'c.rodriguez@vanguardia.co',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    company: 'Vanguardia Digital',
    orders: 11,
    revenue: 9400,
    lastActivity: 'Yesterday',
    segment: 'SMB',
    status: 'Active',
    location: 'Austin, USA',
    joinDate: 'Dec 2024',
    npsScore: 8
  },
  {
    id: 'cust-8',
    name: 'Tobias Lindholm',
    email: 'tobias@nordicstream.se',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    company: 'NordicStream Media',
    orders: 5,
    revenue: 4800,
    lastActivity: '2 days ago',
    segment: 'Startup',
    status: 'New',
    location: 'Stockholm, Sweden',
    joinDate: 'May 2025',
    npsScore: 9
  },
  {
    id: 'cust-9',
    name: 'Priya Sharma',
    email: 'psharma@omnicloud.in',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    company: 'OmniCloud Networks',
    orders: 42,
    revenue: 38700,
    lastActivity: 'Just now',
    segment: 'Enterprise',
    status: 'VIP',
    location: 'Bengaluru, India',
    joinDate: 'Jan 2024',
    npsScore: 10
  },
  {
    id: 'cust-10',
    name: 'Felix Weber',
    email: 'f.weber@bavariasystems.de',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
    company: 'Bavaria Industrial Software',
    orders: 7,
    revenue: 5900,
    lastActivity: '3 days ago',
    segment: 'SMB',
    status: 'Churn-Risk',
    location: 'Munich, Germany',
    joinDate: 'Aug 2024',
    npsScore: 6
  }
];

export const PRODUCT_PERFORMANCE: ProductPerformanceItem[] = [
  {
    id: 'prod-1',
    name: 'Enterprise AI Copilot Suite',
    sku: 'INS-AI-EXP-01',
    category: 'Artificial Intelligence',
    unitsSold: 482,
    revenue: 58400,
    growth: 24.6,
    margin: 88,
    refundRate: 0.4,
    status: 'Flagship'
  },
  {
    id: 'prod-2',
    name: 'Cloud Data Pipeline (Realtime)',
    sku: 'INS-DP-RT-02',
    category: 'Infrastructure',
    unitsSold: 312,
    revenue: 38200,
    growth: 16.2,
    margin: 76,
    refundRate: 0.8,
    status: 'High Growth'
  },
  {
    id: 'prod-3',
    name: 'Predictive Analytics Pro Tier',
    sku: 'INS-PAP-03',
    category: 'Analytics',
    unitsSold: 285,
    revenue: 26800,
    growth: 9.8,
    margin: 84,
    refundRate: 1.1,
    status: 'Stable'
  },
  {
    id: 'prod-4',
    name: 'Automated Reporting API Connectors',
    sku: 'INS-REP-API-04',
    category: 'Developer Tools',
    unitsSold: 194,
    revenue: 15400,
    growth: 12.1,
    margin: 92,
    refundRate: 0.2,
    status: 'High Growth'
  },
  {
    id: 'prod-5',
    name: 'White-Label Executive Dashboards',
    sku: 'INS-WL-DASH-05',
    category: 'Enterprise Add-on',
    unitsSold: 88,
    revenue: 9620,
    growth: -2.4,
    margin: 80,
    refundRate: 1.9,
    status: 'Needs Review'
  },
  {
    id: 'prod-6',
    name: 'Historical Data Vault (Cold Storage)',
    sku: 'INS-VAULT-06',
    category: 'Storage',
    unitsSold: 640,
    revenue: 12800,
    growth: 18.5,
    margin: 72,
    refundRate: 0.1,
    status: 'Stable'
  }
];

export const INITIAL_USER_SETTINGS: UserSettings = {
  profile: {
    fullName: 'Alex Reynolds',
    email: 'alex.reynolds@insightai.corp',
    role: 'Chief Analytics Officer & Workspace Admin',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    timezone: 'America/New_York (UTC-04:00)',
    twoFactorEnabled: true
  },
  business: {
    companyName: 'Apex Data Global Corp',
    taxId: 'US-948271049-A',
    currency: 'USD ($)',
    fiscalYearStart: 'January 1st',
    industry: 'Enterprise SaaS & Artificial Intelligence'
  },
  notifications: {
    emailAlerts: true,
    aiAnomalyTriggers: true,
    weeklyDigest: true,
    slackWebhook: true,
    desktopPushes: false
  },
  dashboard: {
    defaultTimeRange: '30d',
    chartAnimation: true,
    compactView: false,
    autoRefreshInterval: 30,
    theme: 'dark'
  }
};

export const INITIAL_SETTINGS: UserSettings = INITIAL_USER_SETTINGS;

export const FAQ_ITEMS = [
  {
    q: 'How does InsightAI connect to our existing enterprise data warehouse?',
    a: 'InsightAI provides native zero-ETL connectors to Snowflake, BigQuery, Databricks, PostgreSQL, Salesforce, and Stripe. Read-only ingestion pipelines run securely within your VPC with end-to-end encryption.'
  },
  {
    q: 'How does simulated AI forecasting work compared to standard analytics?',
    a: 'While traditional BI only charts what happened in the past, InsightAI analyzes seasonality, customer cohort degradation, and macro velocity to simulate outcomes, flag anomalies before revenue loss, and recommend optimal decisions.'
  },
  {
    q: 'Is my company data used to train public AI models?',
    a: 'Never. InsightAI enforces strict multi-tenant isolation and SOC2 Type II compliance. Your telemetry and proprietary business metrics remain 100% private to your tenant.'
  },
  {
    q: 'Can non-technical executives generate automated reports?',
    a: 'Yes. The Natural Language Query engine and automated report builder enable anyone on your team to generate boardroom-ready PDF and spreadsheet summaries in seconds.'
  },
  {
    q: 'What is the implementation timeline for enterprise deployment?',
    a: 'Self-serve connections can be activated in less than 5 minutes. Enterprise single-sign-on (SAML/Okta) and dedicated VPC deployment take less than 48 hours.'
  }
];

export const PRICING_TIERS = [
  {
    name: 'Starter',
    badge: 'Growth Stage',
    monthlyPrice: 79,
    annualPrice: 65,
    description: 'Perfect for fast-growing startups requiring foundational business metrics and core telemetry.',
    features: [
      'Up to 10 team seats',
      '3 Data warehouse connectors',
      'Daily AI anomaly detection',
      'Standard automated reports',
      '30-day data retention',
      'Community & email support'
    ],
    popular: false,
    cta: 'Start 14-Day Free Trial'
  },
  {
    name: 'Enterprise Pro',
    badge: 'Most Popular',
    monthlyPrice: 249,
    annualPrice: 199,
    description: 'The standard for scaling mid-market enterprises looking for AI-driven revenue intelligence.',
    features: [
      'Unlimited team members',
      'All 40+ native integrations',
      'Real-time automated AI recommendations',
      'Custom predictive forecast models',
      'Unlimited scheduled PDF & CSV exports',
      'Custom role-based permissions (RBAC)',
      'Dedicated Slack support channel'
    ],
    popular: true,
    cta: 'Get Started with Pro'
  },
  {
    name: 'Institutional Scale',
    badge: 'Custom Architecture',
    monthlyPrice: 799,
    annualPrice: 649,
    description: 'For global enterprises with complex compliance, multi-region residency, and custom SLAs.',
    features: [
      'Dedicated isolated VPC / On-Prem',
      'Custom fine-tuned predictive algorithms',
      'SOC2 Type II & HIPAA compliance kit',
      'Sub-second query SLA guarantees',
      'White-label executive dashboards',
      '24/7 priority phone & TAM support',
      'Custom contract & invoicing terms'
    ],
    popular: false,
    cta: 'Contact Sales Engineering'
  }
];

export const TESTIMONIALS = [
  {
    quote: 'InsightAI uncovered a $42,000 monthly churn leak that our traditional BI tools completely missed. Within 3 weeks of applying the recommended actions, our net dollar retention rose to 124%.',
    author: 'Evelyn Reed',
    role: 'VP of Revenue Operations',
    company: 'Strata Cloud Solutions',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&auto=format&fit=crop&q=80'
  },
  {
    quote: 'The conversational intelligence and automated boardroom briefings save our executive team over 15 hours every single week. It is like having a staff of senior data scientists on call 24/7.',
    author: 'Jonathan Sterling',
    role: 'Co-Founder & COO',
    company: 'Fintech Velocity',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80'
  },
  {
    quote: 'The clarity of the interface is stunning. It bridges raw engineering telemetry with executive strategy effortlessly. Our board meetings are now entirely powered by InsightAI.',
    author: 'Clara Dupond',
    role: 'Chief Financial Officer',
    company: 'Luminary Systems Europe',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80'
  }
];
