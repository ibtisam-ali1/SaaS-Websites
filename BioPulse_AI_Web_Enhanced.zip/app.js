import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.179.1/build/three.module.js";

const API = "http://127.0.0.1:8001";
const $ = (selector) => document.querySelector(selector);

const savedTheme = localStorage.getItem("biopulse-theme");
const initialTheme = savedTheme || (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark");
document.documentElement.dataset.theme = initialTheme;
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem("biopulse-theme", theme);
  const button = $("#themeToggle");
  if (button) {
    button.textContent = theme === "light" ? "☾" : "☼";
    button.setAttribute("aria-label", theme === "light" ? "Switch to dark mode" : "Switch to light mode");
    button.title = theme === "light" ? "Switch to dark mode" : "Switch to light mode";
  }
  const meta = $("#themeColor");
  if (meta) meta.content = theme === "light" ? "#f7fbff" : "#07111f";
}

const sceneHost = $("#scene");
const chartCanvas = $("#chart");
const chartEmpty = $("#chartEmpty");
const intensity = $("#intensity");
const speed = $("#speed");

let currentData = null;
let scenario = "normal";
let animationSpeed = Number(speed.value) / 900;
let refreshTimer = null;
let busy = false;
const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;

// ---------- 3D visual ----------
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(48, 1, 0.1, 100);
camera.position.set(0, 0.3, 7);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.setClearColor(0x000000, 0);
sceneHost.appendChild(renderer.domElement);

const group = new THREE.Group();
scene.add(group);

scene.add(new THREE.AmbientLight(0x91a7ff, 1.7));
const key = new THREE.PointLight(0x22d3ee, 6, 15);
key.position.set(2.5, 2.5, 4);
scene.add(key);

const core = new THREE.Mesh(
  new THREE.IcosahedronGeometry(1.18, 3),
  new THREE.MeshStandardMaterial({
    color: 0x5b5cf0, emissive: 0x24135f, roughness: 0.3, metalness: 0.6,
    transparent: true, opacity: 0.9
  })
);
group.add(core);

const wire = new THREE.Mesh(
  new THREE.IcosahedronGeometry(1.48, 2),
  new THREE.MeshBasicMaterial({ color: 0x22d3ee, wireframe: true, transparent: true, opacity: 0.25 })
);
group.add(wire);

const rings = [];
for (const [radius, tilt] of [[1.85, 0.3], [2.15, -0.5], [2.45, 0.9]]) {
  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(radius, 0.012, 8, 100),
    new THREE.MeshBasicMaterial({ color: 0x67e8f9, transparent: true, opacity: 0.28 })
  );
  ring.rotation.x = tilt;
  group.add(ring);
  rings.push(ring);
}

const count = 260;
const positions = new Float32Array(count * 3);
const base = new Float32Array(count * 3);
for (let i = 0; i < count; i++) {
  const radius = 2.1 + Math.random() * 1.5;
  const angle = Math.random() * Math.PI * 2;
  const y = (Math.random() - 0.5) * 3.2;
  const x = Math.cos(angle) * radius;
  const z = Math.sin(angle) * radius;
  positions.set([x, y, z], i * 3);
  base.set([x, y, z], i * 3);
}
const particlesGeometry = new THREE.BufferGeometry();
particlesGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
const particles = new THREE.Points(
  particlesGeometry,
  new THREE.PointsMaterial({ color: 0x67e8f9, size: 0.032, transparent: true, opacity: 0.7 })
);
group.add(particles);

function resizeScene() {
  const width = Math.max(sceneHost.clientWidth, 1);
  const height = Math.max(sceneHost.clientHeight, 1);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setSize(width, height, false);
}
window.addEventListener("resize", resizeScene);
resizeScene();

function animate(time) {
  requestAnimationFrame(animate);
  const motion = reducedMotion ? 0 : animationSpeed;
  group.rotation.y += motion;
  group.rotation.x = Math.sin(time * 0.00035) * 0.09;
  const pulse = 1 + Math.sin(time * 0.0022) * 0.025 * (Number(intensity.value) / 50);
  core.scale.setScalar(pulse);
  wire.rotation.y -= motion * 1.7;
  rings.forEach((ring, i) => {
    ring.rotation.z += motion * (i + 1) * 0.7;
    ring.scale.setScalar(1 + Math.sin(time * 0.001 + i) * 0.025);
  });

  const p = particlesGeometry.attributes.position.array;
  for (let i = 0; i < count; i++) {
    const j = i * 3;
    p[j] = base[j] + Math.sin(time * 0.001 + i) * 0.04;
    p[j + 1] = base[j + 1] + Math.cos(time * 0.0008 + i) * 0.035;
    p[j + 2] = base[j + 2] + Math.sin(time * 0.0007 + i * 0.3) * 0.04;
  }
  particlesGeometry.attributes.position.needsUpdate = true;
  renderer.render(scene, camera);
}
requestAnimationFrame(animate);

// ---------- Telemetry ----------
function format(value, digits = 1) {
  return Number(value).toFixed(digits);
}

function setService(dot, state, ok) {
  $(dot).className = ok ? "service-ok" : "service-bad";
  $(state).textContent = ok ? "online" : "offline";
}

function renderMetrics(data) {
  const m = data.metrics;
  const signal = Number(m.signal);
  $("#metricSignal").textContent = format(signal);
  $("#metricPeak").textContent = format(m.peak);
  $("#metricFloor").textContent = format(m.floor);
  $("#metricConfidence").textContent = `${Math.round(Number(m.confidence) * 100)}%`;
  $("#signalMeter").style.width = `${Math.max(0, Math.min(100, signal))}%`;

  $("#chartCurrent").textContent = format(signal);
  $("#chartAverage").textContent = format(data.series.reduce((a, b) => a + b, 0) / data.series.length);
  $("#chartRange").textContent = `${format(m.floor)}–${format(m.peak)}`;
  $("#insightPeak").textContent = format(m.peak);
  $("#insightFloor").textContent = format(m.floor);
  $("#insightConfidence").textContent = `${Math.round(Number(m.confidence) * 100)}%`;

  const status = String(data.status || "nominal").toLowerCase();
  $("#statusBadge").textContent = status.toUpperCase();
  $("#statusBadge").className = `status-badge ${status === "attention" ? "attention" : "nominal"}`;
  $("#visualStatus").textContent = status.toUpperCase();
  $("#statusText").textContent = status === "attention"
    ? "The simulated signal is elevated. Review the stream and ask BioPulse AI for a concise interpretation."
    : "The simulated signal is within the dashboard's nominal range. Ask BioPulse AI to explore the current pattern.";

  $("#lastUpdate").textContent = `Updated ${new Date().toLocaleTimeString()}`;
  $("#visualTime").textContent = new Date().toLocaleTimeString();
  $("#chartEmpty").hidden = false;
  chartEmpty.style.display = "none";
  drawChart(data.series);
}

function drawChart(values) {
  const rect = chartCanvas.getBoundingClientRect();
  if (!rect.width || !rect.height) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const width = Math.max(Math.floor(rect.width * dpr), 1);
  const height = Math.max(Math.floor(rect.height * dpr), 1);
  chartCanvas.width = width;
  chartCanvas.height = height;

  const ctx = chartCanvas.getContext("2d");
  ctx.clearRect(0, 0, width, height);

  const pad = { left: 10 * dpr, right: 12 * dpr, top: 18 * dpr, bottom: 22 * dpr };
  const plotW = width - pad.left - pad.right;
  const plotH = height - pad.top - pad.bottom;
  const min = 0, max = 100;

  ctx.strokeStyle = "rgba(148,163,184,.11)";
  ctx.lineWidth = 1 * dpr;
  ctx.font = `${10 * dpr}px Inter, sans-serif`;
  ctx.fillStyle = "rgba(148,163,184,.65)";
  [0, 25, 50, 75, 100].forEach((tick) => {
    const y = pad.top + plotH - (tick / 100) * plotH;
    ctx.beginPath();
    ctx.moveTo(pad.left, y);
    ctx.lineTo(width - pad.right, y);
    ctx.stroke();
    ctx.fillText(String(tick), 0, y + 3 * dpr);
  });

  const points = values.map((value, i) => ({
    x: pad.left + (i / Math.max(values.length - 1, 1)) * plotW,
    y: pad.top + plotH - (Number(value) / (max - min)) * plotH
  }));

  const gradient = ctx.createLinearGradient(0, pad.top, 0, height);
  gradient.addColorStop(0, "rgba(34,211,238,.22)");
  gradient.addColorStop(1, "rgba(34,211,238,0)");

  ctx.beginPath();
  points.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
  ctx.lineTo(points.at(-1).x, pad.top + plotH);
  ctx.lineTo(points[0].x, pad.top + plotH);
  ctx.closePath();
  ctx.fillStyle = gradient;
  ctx.fill();

  ctx.beginPath();
  points.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
  ctx.strokeStyle = "#67e8f9";
  ctx.lineWidth = 2.5 * dpr;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.stroke();

  const last = points.at(-1);
  ctx.beginPath();
  ctx.arc(last.x, last.y, 5 * dpr, 0, Math.PI * 2);
  ctx.fillStyle = "#071018";
  ctx.fill();
  ctx.beginPath();
  ctx.arc(last.x, last.y, 3 * dpr, 0, Math.PI * 2);
  ctx.fillStyle = "#67e8f9";
  ctx.fill();
}

async function loadHealth() {
  try {
    const response = await fetch(`${API}/api/health`, { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    setService("#apiDot", "#apiState", true);
    const ollamaOk = Boolean(data.ollama_available);
    setService("#ollamaDot", "#ollamaState", ollamaOk);
    $("#liveDot").className = ollamaOk ? "live-ok" : "live-warn";
    $("#liveText").textContent = ollamaOk ? "LIVE · AI READY" : "LIVE · AI OFFLINE";
    $("#aiStatusDot").className = ollamaOk ? "ai-online" : "ai-offline";
    $("#aiStatus").textContent = ollamaOk ? "READY" : "OFFLINE";
  } catch (error) {
    setService("#apiDot", "#apiState", false);
    setService("#ollamaDot", "#ollamaState", false);
    $("#liveDot").className = "live-bad";
    $("#liveText").textContent = "API OFFLINE";
    $("#aiStatusDot").className = "ai-offline";
    $("#aiStatus").textContent = "OFFLINE";
  }
}

async function loadData() {
  try {
    const response = await fetch(
      `${API}/api/data?scenario=${encodeURIComponent(scenario)}&intensity=${encodeURIComponent(intensity.value)}`,
      { cache: "no-store" }
    );
    if (!response.ok) throw new Error(`Telemetry HTTP ${response.status}`);
    currentData = await response.json();
    renderMetrics(currentData);
  } catch (error) {
    $("#chartEmpty").textContent = "Telemetry unavailable — check the FastAPI service on port 8001.";
    $("#chartEmpty").style.display = "grid";
    $("#liveText").textContent = "API OFFLINE";
  }
}

function addMessage(role, text) {
  const row = document.createElement("div");
  row.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = role === "assistant" ? "AI" : "YOU";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (role === "assistant") {
    const strong = document.createElement("strong");
    strong.textContent = "BioPulse AI";
    bubble.appendChild(strong);
  }
  const p = document.createElement("p");
  p.textContent = text;
  bubble.appendChild(p);
  row.append(avatar, bubble);
  $("#chat").appendChild(row);
  $("#chat").scrollTop = $("#chat").scrollHeight;
  return p;
}

async function askAI(prompt) {
  const question = String(prompt || "").trim();
  if (!question || busy) return;
  busy = true;
  $("#sendBtn").disabled = true;
  $("#aiStatus").textContent = "THINKING";
  $("#aiStatusDot").className = "ai-thinking";
  addMessage("user", question);
  const output = addMessage("assistant", "Thinking…");
  const startedAt = performance.now();

  const compactContext = currentData ? {
    app: currentData.app,
    status: currentData.status,
    signal: currentData.metrics.signal,
    peak: currentData.metrics.peak,
    floor: currentData.metrics.floor,
    confidence: currentData.metrics.confidence,
    series: currentData.series,
    scenario,
    intensity: Number(intensity.value)
  } : { scenario, intensity: Number(intensity.value) };

  try {
    const response = await fetch(`${API}/api/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt: question,
        context: compactContext
      })
    });
    const data = await response.json();
    output.textContent = data.analysis || "No response returned.";
    const elapsed = ((performance.now() - startedAt) / 1000).toFixed(1);
    $("#aiLatency").textContent = `${elapsed}s`;
    const aiOk = data.source === "ollama";
    $("#aiStatus").textContent = aiOk ? "READY" : "FALLBACK";
    $("#aiStatusDot").className = aiOk ? "ai-online" : "ai-offline";
  } catch (error) {
    output.textContent = `The assistant could not respond. Check that Ollama and FastAPI are running. (${error.message})`;
    $("#aiStatus").textContent = "ERROR";
    $("#aiStatusDot").className = "ai-offline";
  } finally {
    busy = false;
    $("#sendBtn").disabled = false;

  }
}

$("#aiForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const input = $("#aiInput");
  const value = input.value.trim();
  input.value = "";
  askAI(value);
});

$("#aiInput").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    $("#aiForm").requestSubmit();
  }
});

document.querySelectorAll(".quick-actions button").forEach((button) => {
  button.addEventListener("click", () => askAI(button.dataset.prompt));
});

$("#themeToggle")?.addEventListener("click", () => {
  applyTheme(document.documentElement.dataset.theme === "light" ? "dark" : "light");
  if (currentData) drawChart(currentData.series);
});

$("#exportBtn")?.addEventListener("click", () => {
  if (!currentData) return;
  const snapshot = {
    exported_at: new Date().toISOString(),
    application: "BioPulse AI",
    operator: "Engr. Muhammad Ibtisam Ali",
    scenario,
    intensity: Number(intensity.value),
    telemetry: currentData
  };
  const blob = new Blob([JSON.stringify(snapshot, null, 2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `biopulse-ai-${new Date().toISOString().replace(/[:.]/g,"-")}.json`;
  a.click();
  URL.revokeObjectURL(url);
});

applyTheme(initialTheme);

$("#refreshBtn").addEventListener("click", async () => {
  await loadHealth();
  await loadData();
});

$("#focusAiBtn").addEventListener("click", () => {
  $("#aiPanel").scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: "center" });
  $("#aiInput").focus();
});

document.querySelectorAll(".scenario").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".scenario").forEach((b) => b.classList.remove("active"));
    button.classList.add("active");
    scenario = button.dataset.scenario;
    $("#scenarioLabel").textContent = scenario.toUpperCase();
    loadData();
  });
});

intensity.addEventListener("input", () => {
  $("#intensityValue").textContent = intensity.value;
});
intensity.addEventListener("change", loadData);

speed.addEventListener("input", () => {
  $("#speedValue").textContent = speed.value;
  animationSpeed = Number(speed.value) / 900;
});

window.addEventListener("resize", () => {
  resizeScene();
  if (currentData) drawChart(currentData.series);
});

await loadHealth();
await loadData();
refreshTimer = setInterval(loadData, 2000);
setInterval(loadHealth, 10000);
