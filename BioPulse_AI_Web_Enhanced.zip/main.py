from __future__ import annotations

import math
import os
import random
import time
from datetime import datetime, timezone
from typing import Any

import httpx
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

APP_NAME = "BioPulse"
CATEGORY = "Health & Medicine"
FEATURE = "3D Human Anatomy Telemetry"
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")
MODEL_NAME = os.getenv("OLLAMA_MODEL", "qwen2.5-coder:1.5b")

app = FastAPI(title=APP_NAME, version="1.2.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:8081",
        "http://localhost:8081",
        "http://127.0.0.1:8080",
        "http://localhost:8080",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class AnalyzeRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=1200)
    context: dict[str, Any] = Field(default_factory=dict)


def base_payload() -> dict[str, Any]:
    return {
        "app": APP_NAME,
        "category": CATEGORY,
        "feature": FEATURE,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "ollama": {"host": OLLAMA_HOST, "model": MODEL_NAME},
    }


@app.get("/api/health")
async def health():
    payload = base_payload()
    try:
        async with httpx.AsyncClient(timeout=2.5) as client:
            response = await client.get(f"{OLLAMA_HOST}/api/tags")
            response.raise_for_status()
            models = response.json().get("models", [])
            payload["ollama_available"] = any(
                m.get("name") == MODEL_NAME
                or str(m.get("name", "")).split(":")[0] == MODEL_NAME.split(":")[0]
                for m in models
            )
            payload["ollama_models"] = [m.get("name") for m in models]
    except Exception as exc:
        payload["ollama_available"] = False
        payload["ollama_error"] = str(exc)
        payload["ollama_models"] = []
    return payload


@app.get("/api/data")
async def data(scenario: str = "normal", intensity: int = 64):
    scenario = scenario.lower().strip()
    intensity = max(10, min(100, int(intensity)))
    seed = int(time.time() // 2)
    rng = random.Random(seed)

    base = 48 + (intensity - 50) * 0.28
    if scenario == "stress":
        base += 20
    elif scenario == "recovery":
        base -= 10
    elif scenario == "random":
        base = rng.uniform(30, 78)

    phase = (time.time() % 24) / 24 * math.tau
    values: list[float] = []
    for i in range(12):
        wave = math.sin(phase + i * 0.55) * (7 if scenario != "stress" else 10)
        noise = rng.uniform(-4.5, 4.5)
        if scenario == "recovery":
            wave *= 0.7
        value = max(8, min(98, base + wave + noise))
        values.append(round(value, 1))

    average = sum(values) / len(values)
    peak = max(values)
    floor = min(values)
    spread = peak - floor
    confidence = max(0.78, min(0.98, 0.97 - spread / 900))
    status = "attention" if scenario == "stress" or average >= 78 else "nominal"

    payload = base_payload()
    payload.update(
        {
            "series": values,
            "status": status,
            "scenario": scenario,
            "metrics": {
                "signal": round(average, 1),
                "peak": peak,
                "floor": floor,
                "confidence": round(confidence, 2),
            },
        }
    )
    return payload


@app.post("/api/analyze")
async def analyze(req: AnalyzeRequest):
    context = req.context
    system = (
        f"You are BioPulse AI, a concise local assistant inside {APP_NAME}. "
        "This is a simulated telemetry application, not a medical diagnostic tool. "
        "Use only the supplied telemetry context. Explain patterns clearly, avoid diagnosis, "
        "and avoid claiming certainty. For medical-sounding questions, explicitly state that "
        "the values are simulated and not a clinical assessment. Keep responses under 120 words. "
        "Answer the user's actual question directly."
    )
    user = f"User question: {req.prompt}\n\nTelemetry context: {context}"

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                f"{OLLAMA_HOST}/api/chat",
                json={
                    "model": MODEL_NAME,
                    "stream": False,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                    "options": {
                        "temperature": 0.15,
                        "num_predict": 140,
                    },
                },
            )
            response.raise_for_status()
            data = response.json()
            text = data.get("message", {}).get("content", "").strip()
            if text:
                return {
                    "ok": True,
                    "source": "ollama",
                    "model": MODEL_NAME,
                    "analysis": text,
                }
    except Exception as exc:
        return {
            "ok": False,
            "source": "local-fallback",
            "model": MODEL_NAME,
            "analysis": (
                "I couldn't reach the local Ollama model. The telemetry dashboard is still "
                "running normally. Start Ollama and make sure the configured model is available."
            ),
            "error": str(exc),
        }

    return {
        "ok": False,
        "source": "local-fallback",
        "model": MODEL_NAME,
        "analysis": "No model response was returned. Check the local Ollama service and model.",
    }
