<?php
declare(strict_types=1);

$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$publicRoot = __DIR__;

$routes = [
    '/' => 'index.html',
    '/index.html' => 'index.html',
    '/style.css' => 'style.css',
    '/app.js' => 'app.js',
];

if (isset($routes[$uri])) {
    $file = $publicRoot . DIRECTORY_SEPARATOR . $routes[$uri];
    if (is_file($file)) {
        $ext = pathinfo($file, PATHINFO_EXTENSION);
        $types = [
            'html' => 'text/html; charset=UTF-8',
            'css'  => 'text/css; charset=UTF-8',
            'js'   => 'application/javascript; charset=UTF-8',
        ];
        header('Content-Type: ' . ($types[$ext] ?? 'application/octet-stream'));
        header('Cache-Control: no-store');
        readfile($file);
        exit;
    }
}

if (str_starts_with($uri, '/api/')) {
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'API routes are handled by the FastAPI service on port 8001.']);
    exit;
}

if (preg_match('/\.[a-zA-Z0-9]+$/', $uri)) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=UTF-8');
    echo "Not found";
    exit;
}

header('Content-Type: text/html; charset=UTF-8');
readfile(__DIR__ . '/index.html');
?>