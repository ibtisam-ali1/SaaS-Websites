# BioPulse AI

**Category:** Health & Medicine

**Core feature:** Map simulated heart rate, oxygen saturation, temperature, blood pressure and respiratory rate onto a futuristic human-body telemetry view, with Qwen-powered symptom analysis.

## Architecture

- PHP 8.x built-in server for routing/static delivery.
- FastAPI + Uvicorn on `127.0.0.1:8001`.
- Vanilla HTML/CSS/JavaScript.
- Tailwind CSS CDN.
- Three.js CDN.
- Optional local Ollama integration using `BioPulse`-specific prompts.
- Default model: `qwen2.5-coder:1.5b`.

## Windows setup

### 1. Requirements

Install:
- Python 3.11+ (3.14 is also supported by the project code)
- PHP 8.x
- Node.js + npm
- Ollama

Verify:

```powershell
python --version
php -v
node --version
npm --version
ollama --version
```

### 2. Install the local Qwen model

```powershell
ollama pull qwen2.5-coder:1.5b
```

### 3. Install Python dependencies

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Install the tiny npm development dependency

```powershell
npm run setup
```

### 5. Start the app

Make sure Ollama is running, then:

```powershell
ollama serve
```

Open a second PowerShell in this project:

```powershell
npm run dev
```

Open:

```text
http://127.0.0.1:8081/
```

FastAPI health endpoint:

```text
http://127.0.0.1:8001/api/health
```

## Production notes

The default configuration is local-first and intentionally lightweight. For deployment, put PHP/FastAPI behind a real reverse proxy, disable Uvicorn reload mode, pin dependency versions after your environment validation, serve static CDN assets locally if offline operation is required, and add authentication/rate limiting before exposing Ollama-backed endpoints publicly.
