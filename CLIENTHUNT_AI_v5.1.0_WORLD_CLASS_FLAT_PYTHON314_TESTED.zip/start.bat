@echo off
setlocal
if not exist .venv\Scripts\python.exe python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
set ENVIRONMENT=development
if "%APP_SECRET%"=="" set APP_SECRET=dev-only-change-this-secret
python -m uvicorn app.saas_main:app --host 127.0.0.1 --port 8000 --reload
