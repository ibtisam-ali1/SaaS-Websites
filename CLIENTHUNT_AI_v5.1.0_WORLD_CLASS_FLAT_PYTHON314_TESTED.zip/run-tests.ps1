$ErrorActionPreference = 'Stop'
$py = '.\.venv\Scripts\python.exe'
if (-not (Test-Path $py)) { throw '.venv is missing. Run .\setup-windows.ps1 first.' }
$env:PYTHONPATH='.'
$env:ENVIRONMENT='test'
$env:APP_SECRET='local-test-secret'
$env:RATE_LIMIT_ENABLED='0'
& $py -m pytest -q tests/test_commercial.py
& $py -m compileall -q app
Write-Host 'ALL LOCAL TESTS PASSED.' -ForegroundColor Green
