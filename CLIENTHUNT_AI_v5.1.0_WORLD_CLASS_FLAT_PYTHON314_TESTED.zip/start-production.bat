@echo off
setlocal
if "%ENVIRONMENT%"=="" set ENVIRONMENT=production
if "%APP_SECRET%"=="" echo ERROR: APP_SECRET is required in production & exit /b 1
python -m uvicorn app.saas_main:app --host 0.0.0.0 --port 8000 --workers 2
