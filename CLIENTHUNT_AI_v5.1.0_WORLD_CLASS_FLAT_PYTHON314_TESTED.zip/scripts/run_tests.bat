@echo off
setlocal
set PYTHONPATH=.
python -m compileall -q app || exit /b 1
python -m pytest -q tests/test_commercial.py || exit /b 1
echo ALL COMMERCIAL TESTS PASSED
