import sys, urllib.request, json
base=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8000'
for path in ['/register','/login','/api/health','/api/ready','/docs','/openapi.json']:
    with urllib.request.urlopen(base+path, timeout=5) as r:
        assert r.status==200, (path,r.status)
        print('PASS',path,r.status)
print('SMOKE PASS')
