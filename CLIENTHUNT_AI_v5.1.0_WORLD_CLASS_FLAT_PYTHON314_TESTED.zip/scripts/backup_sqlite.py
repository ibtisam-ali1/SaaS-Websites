from pathlib import Path
import shutil, datetime
root=Path(__file__).resolve().parents[1]
src=root/'data'/'clienthunt_saas.db'
out=root/'backups'
out.mkdir(exist_ok=True)
if not src.exists(): raise SystemExit('SQLite database does not exist yet; start the app first.')
dst=out/f"clienthunt_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
shutil.copy2(src,dst)
print(dst)
