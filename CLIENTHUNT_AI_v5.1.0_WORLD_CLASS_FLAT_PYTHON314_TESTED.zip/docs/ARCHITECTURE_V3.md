# Architecture

Browser / API clients → HTTPS reverse proxy → FastAPI SaaS → PostgreSQL → optional SMTP / payment provider / local AI / automation worker.

The application keeps tenant ownership explicit in every business table. Browser sessions are signed server-side cookies. API integrations use hashed bearer keys. The UI has human approval before email sending.

The local SQLite mode is for development/testing. PostgreSQL is the intended production database.
