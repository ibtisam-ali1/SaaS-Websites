# CLIENTHUNT AI v5.0.1

Compatibility patch for modern Python environments.

- Updated `psycopg[binary]` from 3.2.9 to 3.3.5.
- Psycopg 3.2.9 did not publish a CPython 3.14 Windows wheel; this caused installation failure on Python 3.14.
- Psycopg 3.3.5 publishes a CPython 3.14 Windows x86-64 wheel.
- No application behavior was changed by this dependency-only patch.
