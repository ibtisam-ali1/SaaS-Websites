# Architecture v4

Browser / API client
        |
     FastAPI
        |
  +-----+-------------------------+
  |                               |
Tenant/Auth                     Business agents
  |                               |
PostgreSQL / SQLite          scoring / outreach / followups
  |                               |
Audit + API keys             SMTP / Ollama / Stripe adapters

Every business query is scoped by `org_id`.

Production topology:
Internet -> HTTPS reverse proxy -> FastAPI workers -> PostgreSQL
                                            |-> SMTP
                                            |-> Stripe
                                            |-> optional Ollama/private model

SQLite mode is for development/testing, not multi-instance production.
