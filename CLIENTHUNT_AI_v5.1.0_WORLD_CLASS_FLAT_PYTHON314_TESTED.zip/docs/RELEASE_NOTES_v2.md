# CLIENTHUNT AI v2.0.0

## Major upgrades from v1
- Premium 3D/CSS animated command center.
- Opportunity Radar and problem-first scoring.
- Agent Orchestrator and audit history.
- Campaign agent execution.
- Follow-up scheduler.
- Suppression/opt-out protection.
- Duplicate detection for manual/API/CSV intake.
- Local Ollama health endpoint and model detection.
- Service recommendation engine.
- Expanded REST API and analytics.
- Stronger regression suite.

## Deliberate next-stage integrations
- Permitted discovery connectors for specific public business sources.
- Email provider integration with authentication, bounce handling and rate limits.
- Reply ingestion/classification.
- Calendar/meeting integration.
- Optional self-hosted n8n orchestration.
- Production authentication, roles, encryption and multi-user deployment.

These are not represented as implemented in v2.0.0.
