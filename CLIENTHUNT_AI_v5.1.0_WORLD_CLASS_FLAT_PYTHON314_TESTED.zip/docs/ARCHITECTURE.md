# CLIENTHUNT AI v2.0 Architecture

## Runtime
Windows → FastAPI → SQLite → browser UI
Optional: FastAPI → local Ollama

## Agent pipeline
1. Scout: accepts legitimate/manual/CSV business prospects.
2. Research: records observable evidence supplied by the user/source.
3. Scoring: calculates transparent 0–100 priority score.
4. Opportunity: detects problem signals and recommends a service.
5. Personalization: creates a draft using Ollama or deterministic fallback.
6. Human approval: outbound draft must be reviewed/approved.
7. Follow-up: schedules controlled follow-up tasks.
8. Learning/analytics: records outcomes and activity for later optimization.

## UI/UX system
- Premium dark sapphire/cyan visual identity.
- Glass panels, soft gradients, depth shadows and animated CSS radar.
- Responsive desktop/tablet/mobile layouts.
- Clear hierarchy: command center → radar → pipeline → activity.
- Strong status/score semantics without relying only on color.
- No external frontend framework required.

## Data model
services, campaigns, leads, outreach, followups, suppression, agent_runs, activities, settings.

## Important boundaries
The core package does not claim universal web scraping, private-data access, CAPTCHA bypass, guaranteed client acquisition, automatic bulk email, or platform-rule evasion. Discovery connectors and outbound providers are deliberately integration points for a later compliant deployment.
