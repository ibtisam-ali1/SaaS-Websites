# v4.0 Commercial SaaS Release

Major production-oriented upgrade from the prototype line.

- Clean SaaS-only application package
- Multi-tenant workspaces
- Team invitation workflow
- Password policy and login lockout
- API idempotency
- Plan limits
- Stripe Checkout and Billing Portal adapter
- Signed Stripe webhook verification
- Calendar export fix
- Lead status and outreach rejection workflows
- Stronger rate limiting
- Forward-compatible schema additions/indexes
- Production Compose configuration with environment-based secrets
- Comprehensive test suite and explicit environment limitations
