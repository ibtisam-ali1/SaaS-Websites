# CLIENTHUNT AI v5.0 — Production Readiness

## Software capabilities implemented
- [x] Multi-tenancy and tenant-scoped authorization
- [x] Roles and team invitations
- [x] Authentication, lockout, CSRF, password reset and verification flow
- [x] Lead CRM and scoring
- [x] Public-site research with SSRF protection
- [x] Campaigns and human approval
- [x] SMTP adapter + suppression
- [x] Follow-up queue/worker
- [x] Reply intelligence
- [x] Meetings and calendar
- [x] Proposals
- [x] Learning engine
- [x] API keys and idempotency
- [x] Stripe adapter and signed webhooks
- [x] Health/readiness/metrics
- [x] Audit/security controls
- [x] Data export and owner deletion
- [x] Docker/PostgreSQL deployment baseline
- [x] Automated regression tests

## Deployment resources (not application features)
- [ ] Real PostgreSQL instance
- [ ] Real domain + HTTPS certificate
- [ ] Strong production secrets stored outside source control
- [ ] SMTP sender/domain authentication (SPF/DKIM/DMARC)
- [ ] Stripe account/products/prices/webhook secret if selling subscriptions
- [ ] Automated encrypted backups and a verified restore drill
- [ ] Monitoring/error alerting/log retention
- [ ] Privacy policy, terms, retention/deletion policy and compliant outreach process
- [ ] Staging environment and CI/CD credentials

These deployment items cannot be pre-created inside a ZIP because they belong to the eventual operator/infrastructure.
