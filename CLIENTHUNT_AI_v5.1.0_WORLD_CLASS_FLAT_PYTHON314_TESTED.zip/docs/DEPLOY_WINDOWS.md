# Windows Development Guide

1. Install Python 3.12+ and VS Code.
2. Extract the ZIP.
3. Open the project folder in VS Code.
4. Create a virtual environment.
5. Install requirements.
6. Start Uvicorn.
7. Register a workspace.
8. Add test leads.
9. Run the full pytest suite.
10. Test every navigation item and workflow in Chrome.

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:PYTHONPATH="."
python -m pytest -q tests/test_commercial.py
$env:APP_SECRET="dev-only-change-this-secret"
python -m uvicorn app.saas_main:app --host 127.0.0.1 --port 8000 --reload
```
