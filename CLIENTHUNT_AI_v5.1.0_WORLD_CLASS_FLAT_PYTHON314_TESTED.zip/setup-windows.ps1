$ErrorActionPreference = 'Stop'
Write-Host 'CLIENTHUNT AI - Windows Setup' -ForegroundColor Cyan
if (-not (Test-Path '.\requirements.txt')) { throw 'requirements.txt not found. Run this script from the project root.' }
if (-not (Test-Path '.\.venv')) { py -3 -m venv .venv }
$py = '.\.venv\Scripts\python.exe'
& $py -m pip install --upgrade pip
& $py -m pip install -r requirements.txt
Write-Host ''
Write-Host 'Setup complete.' -ForegroundColor Green
& $py -c "import sys, psycopg; print('Python:', sys.version); print('Psycopg:', psycopg.__version__)"
Write-Host 'Next: .\run-tests.ps1' -ForegroundColor Yellow
Write-Host 'Then: .\run-dev.ps1' -ForegroundColor Yellow
