import os, tempfile, re, json, hashlib, hmac, time
DB=os.path.join(tempfile.gettempdir(),'clienthunt_commercial_test.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['DATABASE_URL']='sqlite:///'+DB
os.environ['APP_SECRET']='test-secret-for-suite-123456789'
os.environ['ENVIRONMENT']='test'
os.environ['RATE_LIMIT_ENABLED']='0'
from fastapi.testclient import TestClient
from app.saas_main import app, db_init, q, execsql


def token(c, page='/register'):
    r=c.get(page); assert r.status_code==200
    m=re.search(r'name="csrf" value="([^"]+)"',r.text); assert m
    return m.group(1)


def register(c,email='owner@example.com',company='Acme Agency'):
    r=c.post('/auth/register',data={'csrf':token(c),'email':email,'password':'StrongPassword123!','full_name':'Owner','company':company},follow_redirects=False)
    assert r.status_code==303


def make_lead(c,name='Alpha Clinic',email='hello@alpha.test'):
    return c.post('/leads/new',data={'csrf':token(c),'company_name':name,'industry':'Dental Clinic','email':email,'evidence':'old website no booking no chatbot','website_score':30,'need_score':50,'service_match':90,'contact_score':90},follow_redirects=False)


def test_registration_auth_and_security():
    db_init(); c=TestClient(app)
    assert c.get('/').status_code==401
    assert c.get('/register').status_code==200
    bad=c.post('/auth/register',data={'csrf':token(c),'email':'bad@example.com','password':'weak','full_name':'A','company':'A'},follow_redirects=False)
    assert bad.status_code==400
    register(c)
    assert c.get('/').status_code==200
    h=c.get('/api/health'); assert h.status_code==200 and h.headers['x-content-type-options']=='nosniff'


def test_leads_campaign_and_outreach_pipeline():
    c=TestClient(app); register(c,'owner2@example.com','Second Agency')
    r=make_lead(c,'Alpha Clinic','hello@alpha.test'); assert r.status_code==303
    detail=c.get('/leads/1'); assert detail.status_code==200 and 'Alpha Clinic' in detail.text
    r=c.post('/leads/1/status',data={'csrf':token(c,'/leads/1'),'status':'qualified'},follow_redirects=False); assert r.status_code==303
    r=c.post('/leads/1/message',data={'csrf':token(c,'/leads/1'),'service':'AI Automation'},follow_redirects=False); assert r.status_code==303
    # find outreach and approve/reject paths
    oid=q('SELECT id FROM outreach WHERE lead_id=1')['id']
    r=c.post(f'/outreach/{oid}/approve',data={'csrf':token(c,'/leads/1')},follow_redirects=False); assert r.status_code==303
    r=c.post(f'/outreach/{oid}/send',data={'csrf':token(c,'/leads/1')},follow_redirects=False); assert r.status_code==503
    r=c.post('/leads/1/followup',data={'csrf':token(c,'/leads/1'),'days':'3','note':'Call with useful plan'},follow_redirects=False); assert r.status_code==303
    fid=q('SELECT id FROM followups WHERE lead_id=1')['id']
    cal=c.get('/api/v1/calendar.ics',params={'followup_id':fid}); assert cal.status_code==200 and 'BEGIN:VCALENDAR' in cal.text
    r=c.post('/leads/1/suppress',data={'csrf':token(c,'/leads/1'),'reason':'opt-out'},follow_redirects=False); assert r.status_code==303
    r=c.post('/campaigns',data={'csrf':token(c),'name':'Dental Campaign','industry':'Dental Clinic','min_score':'60'},follow_redirects=False); assert r.status_code==303
    cid=q('SELECT id FROM campaigns ORDER BY id DESC')['id']
    r=c.post(f'/campaigns/{cid}/run',data={'csrf':token(c,'/campaigns')},follow_redirects=False); assert r.status_code==303


def test_api_key_idempotency_and_isolation():
    c=TestClient(app); register(c,'owner3@example.com','Third Agency')
    r=c.post('/settings/api-key',data={'csrf':token(c),'name':'integration'},follow_redirects=False); assert r.status_code==200
    key=r.text.splitlines()[-1].strip(); assert key.startswith('cha_')
    r=c.post('/api/v1/leads',headers={'Authorization':'Bearer '+key,'Idempotency-Key':'abc-123'},json={'company_name':'Beta School','industry':'School','email':'b@test.example','evidence':'manual excel only'}); assert r.status_code==201
    first=r.json()
    r=c.post('/api/v1/leads',headers={'Authorization':'Bearer '+key,'Idempotency-Key':'abc-123'},json={'company_name':'DIFFERENT','email':'different@test.example'}); assert r.status_code==201 and r.json()==first
    r=c.get('/api/v1/leads',headers={'Authorization':'Bearer '+key}); assert r.status_code==200 and len(r.json())==1
    # Another tenant cannot use the first tenant's key after logout/register.
    c.post('/auth/logout',data={'csrf':token(c)},follow_redirects=False)
    register(c,'owner4@example.com','Fourth Agency')
    assert 'Beta School' not in c.get('/leads').text


def test_team_invite():
    c=TestClient(app); register(c,'owner5@example.com','Fifth Agency')
    r=c.post('/team/invite',data={'csrf':token(c,'/team'),'email':'member@example.com','role':'member'},follow_redirects=False); assert r.status_code==200
    invite=r.text.splitlines()[-1].strip(); assert invite
    c2=TestClient(app)
    csrf=token(c2,'/register')
    # accept requires CSRF session token and invite token
    r=c2.post('/team/accept',data={'csrf':csrf,'email':'member@example.com','password':'MemberPassword123!','full_name':'Member','token':invite},follow_redirects=False); assert r.status_code==303
    assert c2.get('/team').status_code==200


def test_stripe_signature_and_duplicate():
    secret='whsec_test_secret'; os.environ['STRIPE_WEBHOOK_SECRET']=secret
    payload=json.dumps({'id':'evt_test_1','type':'customer.subscription.updated','data':{'object':{'id':'sub_test','status':'active'}}}).encode()
    ts=int(time.time()); sig=hmac.new(secret.encode(),f'{ts}.'.encode()+payload,hashlib.sha256).hexdigest()
    c=TestClient(app)
    r=c.post('/api/webhooks/stripe',content=payload,headers={'stripe-signature':f't={ts},v1={sig}'}); assert r.status_code==200 and r.json()['ok'] is True
    r=c.post('/api/webhooks/stripe',content=payload,headers={'stripe-signature':f't={ts},v1={sig}'}); assert r.status_code==200 and r.json()['duplicate'] is True
    bad=c.post('/api/webhooks/stripe',content=payload,headers={'stripe-signature':'t=1,v1=bad'}); assert bad.status_code==400


def test_v5_discovery_reply_proposal_meeting_learning_and_data_export():
    from app import saas_main
    c=TestClient(app); register(c,'owner6@example.com','Sixth Agency')
    r=make_lead(c,'Gamma Business','hello@gamma.test'); assert r.status_code==303
    lead=q('SELECT id FROM leads WHERE company_name=:n AND org_id=(SELECT org_id FROM users WHERE email=:e)',{'n':'Gamma Business','e':'owner6@example.com'})
    lid=lead['id']
    execsql('UPDATE leads SET website=:w WHERE id=:i',{'w':'https://example.com','i':lid})
    # Research endpoint is SSRF-safe; public URL policy rejects localhost/private targets.
    assert not saas_main.safe_public_url('http://127.0.0.1:8000')
    assert not saas_main.safe_public_url('file:///etc/passwd')
    saas_main.research_public_site=lambda url:{'status':'ok','http_status':200,'title':'Gamma','evidence':'Public-site research: booking, mobile','latency_ms':12,'final_url':url}
    r=c.post(f'/discovery/research/{lid}',data={'csrf':token(c,f'/leads/{lid}')},follow_redirects=False); assert r.status_code==303
    assert 'booking' in q('SELECT evidence FROM leads WHERE id=:i',{'i':lid})['evidence']
    r=c.post('/replies/new',data={'csrf':token(c,'/replies'),'lead_id':lid,'sender':'hello@gamma.test','body':'Interested — can we book a meeting next week?'},follow_redirects=False); assert r.status_code==303
    assert q('SELECT classification FROM reply_events WHERE lead_id=:l ORDER BY id DESC',{'l':lid})['classification']=='meeting_request'
    r=c.post('/proposals',data={'csrf':token(c,'/proposals'),'lead_id':lid,'title':'Growth Automation Proposal','summary':'Automate lead capture and follow-up.','amount':'250000','currency':'PKR'},follow_redirects=False); assert r.status_code==303
    pid=q('SELECT id FROM proposals WHERE lead_id=:l ORDER BY id DESC',{'l':lid})['id']
    r=c.post(f'/proposals/{pid}/status',data={'csrf':token(c,'/proposals'),'status':'sent'},follow_redirects=False); assert r.status_code==303
    r=c.post('/meetings',data={'csrf':token(c,'/meetings'),'lead_id':lid,'title':'Discovery call','starts_at':'2026-09-04T10:00:00+00:00','duration_minutes':'30'},follow_redirects=False); assert r.status_code==303
    assert c.get('/learning').status_code==200
    r=c.post('/settings/export.json',data={'csrf':token(c,'/settings')}); assert r.status_code==200 and 'Gamma Business' in r.text


def test_v5_password_reset_verification_and_workspace_delete():
    c=TestClient(app); register(c,'owner7@example.com','Seventh Agency')
    r=c.post('/auth/request-verification',data={'csrf':token(c,'/settings'),'email':'owner7@example.com'}); assert r.status_code==200 and len(r.text)>20
    verification=r.text
    r=c.post('/auth/verify',data={'csrf':token(c,'/settings'),'token':verification},follow_redirects=False); assert r.status_code==303
    assert q('SELECT email_verified FROM users WHERE email=:e',{'e':'owner7@example.com'})['email_verified']==1
    r=c.post('/auth/reset-request',data={'csrf':token(c,'/settings'),'email':'owner7@example.com'}); assert r.status_code==200
    reset=r.text
    r=c.post('/auth/reset',data={'csrf':token(c,'/settings'),'token':reset,'password':'NewStrongPassword123!'},follow_redirects=False); assert r.status_code==303
    # owner can irreversibly delete only with exact workspace-name confirmation
    r=c.post('/settings/delete-workspace',data={'csrf':token(c,'/settings'),'confirmation':'Seventh Agency'},follow_redirects=False); assert r.status_code==303
    assert q('SELECT id FROM organizations WHERE name=:n',{'n':'Seventh Agency'}) is None
