from __future__ import annotations
import os, re, csv, io, json, secrets, hashlib, hmac, base64, html, smtplib, uuid, threading
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from pathlib import Path
from urllib.parse import urlparse, urlencode
import socket, ipaddress, urllib.request

from fastapi import FastAPI, Request, Form, UploadFile, File, Depends, HTTPException
from contextlib import asynccontextmanager
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, StreamingResponse, PlainTextResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

BASE = Path(__file__).resolve().parent
DB_URL = os.getenv('DATABASE_URL', f"sqlite:///{BASE.parent/'data'/'clienthunt_saas.db'}")
if DB_URL.startswith('postgres://'): DB_URL = DB_URL.replace('postgres://','postgresql+psycopg://',1)
if DB_URL.startswith('postgresql://'): DB_URL = DB_URL.replace('postgresql://','postgresql+psycopg://',1)
connect_args = {'check_same_thread': False} if DB_URL.startswith('sqlite') else {}
engine: Engine = create_engine(DB_URL, future=True, pool_pre_ping=True, connect_args=connect_args)
if engine.dialect.name == 'sqlite':
    from sqlalchemy import event
    @event.listens_for(engine, 'connect')
    def _sqlite_fk(dbapi_connection, connection_record):
        cur=dbapi_connection.cursor(); cur.execute('PRAGMA foreign_keys=ON'); cur.close()
ENVIRONMENT = os.getenv('ENVIRONMENT','development')
SECRET = os.getenv('APP_SECRET','')
if not SECRET: SECRET = secrets.token_urlsafe(48) if ENVIRONMENT != 'production' else (_ for _ in ()).throw(RuntimeError('APP_SECRET must be set in production'))
CSRF_SECRET = os.getenv('CSRF_SECRET', SECRET)
INTERNAL_KEY = os.getenv('INTERNAL_CRON_KEY', '')
APP_URL = os.getenv('APP_URL', 'http://127.0.0.1:8000')
COOKIE_SECURE = os.getenv('COOKIE_SECURE','0') == '1'


class SecurityHeaders(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['X-Frame-Options']='DENY'
        response.headers['Referrer-Policy']='strict-origin-when-cross-origin'
        response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
        response.headers['Content-Security-Policy']="default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data: https:; frame-ancestors 'none'"
        if COOKIE_SECURE: response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
        return response

_rate_window = {}
_rate_lock = threading.Lock()
class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        if os.getenv('RATE_LIMIT_ENABLED','1') != '0':
            now_ts=int(datetime.now(timezone.utc).timestamp())
            bucket=now_ts//60
            host=request.client.host if request.client else 'unknown'
            key=(host,bucket)
            limit=int(os.getenv('RATE_LIMIT_PER_MINUTE','120'))
            with _rate_lock:
                # keep only the last two minutes
                for k in list(_rate_window):
                    if k[1] < bucket-1: _rate_window.pop(k,None)
                count=_rate_window.get(key,0)+1
                _rate_window[key]=count
            if count>limit:
                return JSONResponse({'detail':'Rate limit exceeded'},status_code=429,headers={'Retry-After':'60'})
        return await call_next(request)

SCHEMA = '''
CREATE TABLE IF NOT EXISTS organizations (id INTEGER PRIMARY KEY, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, plan TEXT NOT NULL DEFAULT 'free', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, email TEXT NOT NULL, password_hash TEXT NOT NULL, full_name TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'member', active INTEGER NOT NULL DEFAULT 1, email_verified INTEGER NOT NULL DEFAULT 0, failed_logins INTEGER NOT NULL DEFAULT 0, locked_until TEXT, created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE, UNIQUE(org_id,email));
CREATE TABLE IF NOT EXISTS invites (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, email TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'member', token_hash TEXT NOT NULL UNIQUE, expires_at TEXT NOT NULL, accepted_at TEXT, created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS password_resets (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, token_hash TEXT NOT NULL UNIQUE, expires_at TEXT NOT NULL, used_at TEXT, created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS leads (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, company_name TEXT NOT NULL, website TEXT NOT NULL DEFAULT '', country TEXT NOT NULL DEFAULT '', city TEXT NOT NULL DEFAULT '', industry TEXT NOT NULL DEFAULT '', contact_name TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT 'manual', status TEXT NOT NULL DEFAULT 'new', website_score INTEGER NOT NULL DEFAULT 0, need_score INTEGER NOT NULL DEFAULT 0, service_match INTEGER NOT NULL DEFAULT 0, contact_score INTEGER NOT NULL DEFAULT 0, lead_score INTEGER NOT NULL DEFAULT 0, opportunity TEXT NOT NULL DEFAULT '', evidence TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, UNIQUE(org_id, company_name, website), FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS campaigns (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, name TEXT NOT NULL, industry TEXT NOT NULL DEFAULT '', country TEXT NOT NULL DEFAULT '', service TEXT NOT NULL DEFAULT '', min_score INTEGER NOT NULL DEFAULT 70, status TEXT NOT NULL DEFAULT 'draft', created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS outreach (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, lead_id INTEGER NOT NULL, channel TEXT NOT NULL DEFAULT 'email', subject TEXT NOT NULL, body TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'draft', scheduled_at TEXT, sent_at TEXT, created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE, FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS followups (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, lead_id INTEGER NOT NULL, outreach_id INTEGER, due_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE, FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS suppression (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, email TEXT NOT NULL, reason TEXT NOT NULL DEFAULT 'opt-out', created_at TEXT NOT NULL, UNIQUE(org_id,email), FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, user_id INTEGER, action TEXT NOT NULL, entity TEXT NOT NULL DEFAULT '', entity_id TEXT NOT NULL DEFAULT '', details TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS api_keys (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, name TEXT NOT NULL, key_hash TEXT NOT NULL UNIQUE, key_prefix TEXT NOT NULL, created_at TEXT NOT NULL, last_used_at TEXT, active INTEGER NOT NULL DEFAULT 1, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS idempotency_keys (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, idem_key TEXT NOT NULL, route TEXT NOT NULL, response_json TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(org_id,idem_key,route), FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS subscriptions (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL UNIQUE, provider TEXT NOT NULL DEFAULT 'manual', customer_id TEXT, subscription_id TEXT, status TEXT NOT NULL DEFAULT 'trialing', plan TEXT NOT NULL DEFAULT 'free', current_period_end TEXT, updated_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS webhook_events (id INTEGER PRIMARY KEY, provider TEXT NOT NULL, event_id TEXT NOT NULL UNIQUE, payload TEXT NOT NULL, received_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS agent_runs (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, agent TEXT NOT NULL, status TEXT NOT NULL, input_count INTEGER NOT NULL DEFAULT 0, output_count INTEGER NOT NULL DEFAULT 0, message TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS contacts (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, lead_id INTEGER NOT NULL, name TEXT NOT NULL, email TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', title TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE, FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS research_runs (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, lead_id INTEGER NOT NULL, url TEXT NOT NULL, status TEXT NOT NULL, http_status INTEGER, title TEXT NOT NULL DEFAULT '', evidence TEXT NOT NULL DEFAULT '', latency_ms INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE, FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS proposals (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, lead_id INTEGER NOT NULL, title TEXT NOT NULL, summary TEXT NOT NULL DEFAULT '', amount TEXT NOT NULL DEFAULT '', currency TEXT NOT NULL DEFAULT 'PKR', status TEXT NOT NULL DEFAULT 'draft', valid_until TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE, FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS meetings (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, lead_id INTEGER NOT NULL, title TEXT NOT NULL, starts_at TEXT NOT NULL, duration_minutes INTEGER NOT NULL DEFAULT 30, status TEXT NOT NULL DEFAULT 'scheduled', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE, FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS reply_events (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, lead_id INTEGER NOT NULL, outreach_id INTEGER, channel TEXT NOT NULL DEFAULT 'email', sender TEXT NOT NULL DEFAULT '', body TEXT NOT NULL, classification TEXT NOT NULL DEFAULT 'unclassified', confidence INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE, FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS learning_events (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, lead_id INTEGER, event_type TEXT NOT NULL, value TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE, FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS webhook_deliveries (id INTEGER PRIMARY KEY, org_id INTEGER, provider TEXT NOT NULL, event_type TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'queued', attempts INTEGER NOT NULL DEFAULT 0, next_attempt_at TEXT, last_error TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS app_settings (id INTEGER PRIMARY KEY, org_id INTEGER NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL, UNIQUE(org_id,key), FOREIGN KEY(org_id) REFERENCES organizations(id) ON DELETE CASCADE);
'''

def now(): return datetime.now(timezone.utc).isoformat()
def db_init():
    schema = SCHEMA
    if engine.dialect.name == 'postgresql':
        schema = schema.replace(' INTEGER PRIMARY KEY', ' BIGSERIAL PRIMARY KEY')
    with engine.begin() as c:
        for stmt in schema.split(';'):
            if stmt.strip(): c.execute(text(stmt))
        # Lightweight forward-compatible migrations for installations upgrading from v2/v3.
        additions={
            'users':['email_verified INTEGER NOT NULL DEFAULT 0','failed_logins INTEGER NOT NULL DEFAULT 0','locked_until TEXT'],
        }
        if engine.dialect.name=='sqlite':
            for table,cols in additions.items():
                existing={r[1] for r in c.execute(text(f'PRAGMA table_info({table})')).fetchall()}
                for col in cols:
                    name=col.split()[0]
                    if name not in existing: c.execute(text(f'ALTER TABLE {table} ADD COLUMN {col}'))
        else:
            for table,cols in additions.items():
                for col in cols:
                    name=col.split()[0]; c.execute(text(f'ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {col}'))
        c.execute(text('CREATE INDEX IF NOT EXISTS idx_leads_org_score ON leads(org_id,lead_score DESC)'))
        c.execute(text('CREATE INDEX IF NOT EXISTS idx_outreach_org_status ON outreach(org_id,status)'))
        c.execute(text('CREATE INDEX IF NOT EXISTS idx_followups_due ON followups(org_id,status,due_at)'))
        c.execute(text('CREATE INDEX IF NOT EXISTS idx_audit_org_time ON audit_log(org_id,created_at)'))

@asynccontextmanager
async def lifespan(app):
    db_init()
    yield

app = FastAPI(title='CLIENTHUNT AI SaaS', version='5.0.0', description='Commercial multi-tenant client acquisition platform', lifespan=lifespan)
app.add_middleware(SecurityHeaders)
app.add_middleware(RateLimitMiddleware)
app.add_middleware(SessionMiddleware, secret_key=SECRET, https_only=COOKIE_SECURE, same_site='lax', max_age=60*60*24*14)
templates = Jinja2Templates(directory=str(BASE/'templates'))

def q(sql, params=None, many=False):
    with engine.begin() as c:
        r=c.execute(text(sql), params or {})
        if many: return [dict(x._mapping) for x in r.fetchall()]
        x=r.fetchone(); return dict(x._mapping) if x else None

def qall(sql, params=None): return q(sql,params,True)
def execsql(sql,params=None):
    with engine.begin() as c:
        return c.execute(text(sql),params or {})

def insert_id(sql, params=None):
    sql = sql.rstrip().rstrip(';')
    if ' RETURNING ' not in sql.upper(): sql += ' RETURNING id'
    with engine.begin() as c:
        r=c.execute(text(sql),params or {})
        row=r.fetchone()
        return row[0] if row else None

def password_ok(password):
    return isinstance(password,str) and len(password)>=10 and any(c.isupper() for c in password) and any(c.islower() for c in password) and any(c.isdigit() for c in password)
def pbkdf(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    dk=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,310000)
    return base64.urlsafe_b64encode(salt+dk).decode()
def verify(password, encoded):
    try:
        raw=base64.urlsafe_b64decode(encoded.encode()); salt,expected=raw[:16],raw[16:]
        got=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,310000)
        return hmac.compare_digest(got,expected)
    except Exception: return False

def csrf_for(request):
    token=request.session.get('csrf')
    if not token:
        token=secrets.token_urlsafe(24); request.session['csrf']=token
    return token

def require_csrf(request, token):
    if not token or not hmac.compare_digest(token, request.session.get('csrf','')): raise HTTPException(403,'Invalid CSRF token')

def current_user(request):
    uid=request.session.get('user_id')
    if not uid: return None
    u=q('SELECT * FROM users WHERE id=:id AND active=1',{'id':uid})
    if not u: request.session.clear()
    return u

def require_user(request):
    u=current_user(request)
    if not u: raise HTTPException(401,'Authentication required')
    return u

def require_role(user, roles):
    if user['role'] not in roles: raise HTTPException(403,'Insufficient permissions')

def audit(user, action, entity='', entity_id='', details=''):
    execsql('INSERT INTO audit_log(org_id,user_id,action,entity,entity_id,details,created_at) VALUES(:o,:u,:a,:e,:i,:d,:n)',{'o':user['org_id'],'u':user['id'],'a':action,'e':entity,'i':str(entity_id),'d':details[:4000],'n':now()})

def render(request, page, **ctx):
    u=current_user(request); ctx.update(user=u,csrf=csrf_for(request)); return templates.TemplateResponse(request,f'{page}.html',ctx)

def score(data):
    def n(v):
        try:return max(0,min(100,int(v)))
        except:return 50
    ev=(data.get('evidence') or '').lower(); opp=50
    signals=['no booking','no appointment','outdated','old website','slow','not mobile','manual','no online ordering','no chatbot','no crm','poor ux','broken','excel only','paper based','no automation','no portal']
    hits=sum(s in ev for s in signals); opp=min(100,50+hits*8)
    need=max(n(data.get('need_score',50)),opp); ws=n(data.get('website_score',50)); sm=n(data.get('service_match',50)); cs=n(data.get('contact_score',50))
    sc=round(ws*.25+need*.35+sm*.25+cs*.15); tier='hot' if sc>=90 else 'high' if sc>=75 else 'medium' if sc>=60 else 'low'
    return need,sc,tier

def slugify(s): return re.sub(r'[^a-z0-9]+','-',s.lower()).strip('-')[:60] or secrets.token_hex(4)
PLAN_LIMITS={'free':{'leads':100,'users':2,'api_keys':2},'starter':{'leads':5000,'users':5,'api_keys':10},'pro':{'leads':25000,'users':20,'api_keys':50},'enterprise':{'leads':1000000,'users':1000,'api_keys':200}}
def enforce_limit(org_id, resource):
    org=q('SELECT plan FROM organizations WHERE id=:o',{'o':org_id}) or {'plan':'free'}
    limit=PLAN_LIMITS.get(org.get('plan','free'),PLAN_LIMITS['free']).get(resource)
    if limit is None:return
    table={'leads':'leads','users':'users','api_keys':'api_keys'}[resource]
    count=(q(f'SELECT COUNT(*) count FROM {table} WHERE org_id=:o',{'o':org_id}) or {'count':0})['count']
    if count>=limit: raise HTTPException(402,f'{resource} limit reached for {org.get("plan","free")} plan')

def service_for(lead):
    x=(lead.get('industry','')+' '+lead.get('evidence','')).lower()
    if any(k in x for k in ['clinic','dental','hospital','school','college']): return 'Clinic / School Management'
    if any(k in x for k in ['crm','lead','sales','follow']): return 'CRM / Sales Automation'
    if any(k in x for k in ['manual','excel','paper','automation']): return 'AI Automation'
    if any(k in x for k in ['website','mobile','ux','outdated']): return 'Web Development'
    return 'Custom Business Software'

def draft(lead, service):
    name=lead.get('contact_name') or 'there'; company=lead['company_name']
    return {'subject':f'Idea for {company}', 'body':f"Hi {name},\n\nI noticed {company} may have an opportunity around {lead.get('evidence') or 'its digital workflow'}. I work on {service} solutions designed around measurable business outcomes.\n\nIf improving this is a priority, I can share a short, no-pressure plan tailored to {company}.\n\nBest,\nCLIENTHUNT AI"}

def send_email(to, subject, body):
    host=os.getenv('SMTP_HOST'); port=int(os.getenv('SMTP_PORT','587')); user=os.getenv('SMTP_USER'); pwd=os.getenv('SMTP_PASSWORD'); sender=os.getenv('SMTP_FROM',user or '')
    if not all([host,user,pwd,sender]): return False,'SMTP not configured; kept as draft.'
    msg=EmailMessage(); msg['From']=sender; msg['To']=to; msg['Subject']=subject; msg.set_content(body)
    with smtplib.SMTP(host,port,timeout=20) as s:
        s.starttls(); s.login(user,pwd); s.send_message(msg)
    return True,'sent'

def api_org(request):
    auth=request.headers.get('authorization','')
    if not auth.startswith('Bearer '): return None
    key=auth[7:].strip(); h=hashlib.sha256(key.encode()).hexdigest()
    row=q('SELECT * FROM api_keys WHERE key_hash=:h AND active=1',{'h':h})
    if not row:return None
    execsql('UPDATE api_keys SET last_used_at=:n WHERE id=:id',{'n':now(),'id':row['id']})
    return q('SELECT * FROM organizations WHERE id=:id',{'id':row['org_id']})


@app.post('/auth/request-verification')
def request_verification(request:Request,email:str=Form(...),csrf:str=Form(...)):
    require_csrf(request,csrf); u=q('SELECT * FROM users WHERE lower(email)=lower(:e)',{'e':email.strip()})
    if not u: return HTMLResponse('If the account exists, a verification token has been generated.',200)
    token=secrets.token_urlsafe(32); h=hashlib.sha256(token.encode()).hexdigest()
    execsql('DELETE FROM password_resets WHERE user_id=:u AND used_at IS NULL',{'u':u['id']})
    execsql('INSERT INTO password_resets(user_id,token_hash,expires_at,created_at) VALUES(:u,:h,:e,:n)',{'u':u['id'],'h':h,'e':(datetime.now(timezone.utc)+timedelta(hours=24)).isoformat(),'n':now()})
    # In local/testing mode the token is returned so no paid email service is needed.
    return PlainTextResponse(token if ENVIRONMENT!='production' else 'Verification request accepted.')

@app.post('/auth/reset-request')
def reset_request(request:Request,email:str=Form(...),csrf:str=Form(...)):
    require_csrf(request,csrf); u=q('SELECT * FROM users WHERE lower(email)=lower(:e)',{'e':email.strip()})
    if not u: return PlainTextResponse('If the account exists, a reset token has been generated.')
    token=secrets.token_urlsafe(32); h=hashlib.sha256(token.encode()).hexdigest()
    execsql('DELETE FROM password_resets WHERE user_id=:u AND used_at IS NULL',{'u':u['id']})
    execsql('INSERT INTO password_resets(user_id,token_hash,expires_at,created_at) VALUES(:u,:h,:e,:n)',{'u':u['id'],'h':h,'e':(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat(),'n':now()})
    return PlainTextResponse(token if ENVIRONMENT!='production' else 'Reset request accepted.')

@app.post('/auth/reset')
def reset_password(request:Request,token:str=Form(...),password:str=Form(...),csrf:str=Form(...)):
    require_csrf(request,csrf)
    if not password_ok(password): raise HTTPException(400,'Password must be at least 10 characters and contain upper/lowercase letters and a digit')
    h=hashlib.sha256(token.encode()).hexdigest(); row=q('SELECT * FROM password_resets WHERE token_hash=:h AND used_at IS NULL',{'h':h})
    if not row or row['expires_at']<now(): raise HTTPException(400,'Invalid or expired reset token')
    execsql('UPDATE users SET password_hash=:p,failed_logins=0,locked_until=NULL WHERE id=:u',{'p':pbkdf(password),'u':row['user_id']})
    execsql('UPDATE password_resets SET used_at=:n WHERE id=:i',{'n':now(),'i':row['id']})
    return RedirectResponse('/login',303)

@app.post('/auth/verify')
def verify_email(request:Request,token:str=Form(...),csrf:str=Form(...)):
    require_csrf(request,csrf); h=hashlib.sha256(token.encode()).hexdigest(); row=q('SELECT * FROM password_resets WHERE token_hash=:h AND used_at IS NULL',{'h':h})
    if not row or row['expires_at']<now(): raise HTTPException(400,'Invalid or expired verification token')
    execsql('UPDATE users SET email_verified=1 WHERE id=:u',{'u':row['user_id']}); execsql('UPDATE password_resets SET used_at=:n WHERE id=:i',{'n':now(),'i':row['id']}); return RedirectResponse('/settings',303)

@app.get('/login',response_class=HTMLResponse)
def login_page(request:Request): return render(request,'saas_login',mode='login')
@app.get('/register',response_class=HTMLResponse)
def register_page(request:Request): return render(request,'saas_login',mode='register')
@app.post('/auth/register')
def register(request:Request,email:str=Form(...),password:str=Form(...),full_name:str=Form(...),company:str=Form(...),csrf:str=Form(...)):
    require_csrf(request,csrf)
    if len(password)<10:return HTMLResponse('Password must be at least 10 characters.',400)
    if q('SELECT id FROM users WHERE lower(email)=lower(:e)',{'e':email}): return HTMLResponse('Email already registered.',409)
    slug=slugify(company)+'-'+secrets.token_hex(3); n=now()
    with engine.begin() as c:
        oid=c.execute(text('INSERT INTO organizations(name,slug,plan,created_at) VALUES(:n,:s,\'free\',:t) RETURNING id'),{'n':company,'s':slug,'t':n}).scalar()
        uid=c.execute(text('INSERT INTO users(org_id,email,password_hash,full_name,role,created_at) VALUES(:o,:e,:p,:f,\'owner\',:t) RETURNING id'),{'o':oid,'e':email.lower().strip(),'p':pbkdf(password),'f':full_name.strip(),'t':n}).scalar()
        c.execute(text('INSERT INTO subscriptions(org_id,status,plan,updated_at) VALUES(:o,\'trialing\',\'free\',:t)'),{'o':oid,'t':n})
    request.session['user_id']=uid; request.session.pop('csrf',None); audit(current_user(request),'register','organization',oid,'Workspace created')
    return RedirectResponse('/',303)
@app.post('/auth/login')
def auth_login(request:Request,email:str=Form(...),password:str=Form(...),csrf:str=Form(...)):
    require_csrf(request,csrf); u=q('SELECT * FROM users WHERE lower(email)=lower(:e) AND active=1',{'e':email.lower().strip()})
    if u and u.get('locked_until') and u['locked_until']>now(): return HTMLResponse('Account temporarily locked. Try again later.',429)
    if not u or not verify(password,u['password_hash']):
        if u:
            failed=int(u.get('failed_logins') or 0)+1; lock=(datetime.now(timezone.utc)+timedelta(minutes=15)).isoformat() if failed>=5 else None
            execsql('UPDATE users SET failed_logins=:f, locked_until=:l WHERE id=:i',{'f':failed,'l':lock,'i':u['id']})
        return HTMLResponse('Invalid email or password.',401)
    execsql('UPDATE users SET failed_logins=0, locked_until=NULL WHERE id=:i',{'i':u['id']})
    request.session.clear(); request.session['user_id']=u['id']; csrf_for(request); audit(u,'login')
    return RedirectResponse('/',303)
@app.post('/auth/logout')
def logout(request:Request,csrf:str=Form(...)):
    u=current_user(request); require_csrf(request,csrf)
    if u:audit(u,'logout')
    request.session.clear(); return RedirectResponse('/login',303)

@app.get('/',response_class=HTMLResponse)
def home(request:Request):
    u=require_user(request); o=q('SELECT * FROM organizations WHERE id=:id',{'id':u['org_id']})
    stats=q('SELECT COUNT(*) total, SUM(CASE WHEN lead_score>=75 THEN 1 ELSE 0 END) qualified, SUM(CASE WHEN status=\'contacted\' THEN 1 ELSE 0 END) contacted, SUM(CASE WHEN status=\'won\' THEN 1 ELSE 0 END) won FROM leads WHERE org_id=:o',{'o':u['org_id']}) or {}
    hot=qall('SELECT * FROM leads WHERE org_id=:o ORDER BY lead_score DESC,id DESC LIMIT 8',{'o':u['org_id']})
    acts=qall('SELECT * FROM audit_log WHERE org_id=:o ORDER BY id DESC LIMIT 8',{'o':u['org_id']})
    return render(request,'saas_dashboard',org=o,stats=stats,hot=hot,acts=acts)

@app.get('/leads',response_class=HTMLResponse)
def leads(request:Request,qry:str='',status:str='',opportunity:str=''):
    u=require_user(request); sql='SELECT * FROM leads WHERE org_id=:o'; p={'o':u['org_id']}
    if qry:sql+=' AND (company_name LIKE :q OR industry LIKE :q OR email LIKE :q OR country LIKE :q)';p['q']=f'%{qry}%'
    if status:sql+=' AND status=:s';p['s']=status
    if opportunity:sql+=' AND opportunity=:op';p['op']=opportunity
    return render(request,'saas_leads',leads=qall(sql+' ORDER BY lead_score DESC,id DESC',p),qry=qry,status=status,opportunity=opportunity)
@app.get('/leads/new',response_class=HTMLResponse)
def newlead(request:Request): require_user(request); return render(request,'saas_lead_form')
@app.post('/leads/new')
def addlead(request:Request,company_name:str=Form(...),website:str=Form(''),country:str=Form(''),city:str=Form(''),industry:str=Form(''),contact_name:str=Form(''),email:str=Form(''),phone:str=Form(''),evidence:str=Form(''),notes:str=Form(''),website_score:int=Form(50),need_score:int=Form(50),service_match:int=Form(50),contact_score:int=Form(50),csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf); enforce_limit(u['org_id'],'leads'); need,sc,op=score(locals()); n=now()
    try:
        with engine.begin() as c:
            lid=c.execute(text('''INSERT INTO leads(org_id,company_name,website,country,city,industry,contact_name,email,phone,website_score,need_score,service_match,contact_score,lead_score,opportunity,evidence,notes,created_at,updated_at) VALUES(:o,:c,:w,:co,:ci,:i,:cn,:e,:p,:ws,:ns,:sm,:cs,:s,:op,:ev,:no,:n,:n) RETURNING id'''),{'o':u['org_id'],'c':company_name.strip(),'w':website.strip(),'co':country,'ci':city,'i':industry,'cn':contact_name,'e':email,'p':phone,'ws':website_score,'ns':need,'sm':service_match,'cs':contact_score,'s':sc,'op':op,'ev':evidence,'no':notes,'n':n}).scalar()
    except Exception:return HTMLResponse('Duplicate lead or invalid data.',409)
    audit(u,'create','lead',lid,f'score={sc},tier={op}'); return RedirectResponse(f'/leads/{lid}',303)
@app.get('/leads/{lead_id}',response_class=HTMLResponse)
def lead_detail(request:Request,lead_id:int):
    u=require_user(request); lead=q('SELECT * FROM leads WHERE id=:id AND org_id=:o',{'id':lead_id,'o':u['org_id']})
    if not lead:raise HTTPException(404,'Lead not found')
    out=qall('SELECT * FROM outreach WHERE lead_id=:l AND org_id=:o ORDER BY id DESC',{'l':lead_id,'o':u['org_id']}); f=qall('SELECT * FROM followups WHERE lead_id=:l AND org_id=:o ORDER BY due_at',{'l':lead_id,'o':u['org_id']})
    acts=qall('SELECT * FROM audit_log WHERE org_id=:o AND (entity_id=:i OR entity=:e) ORDER BY id DESC LIMIT 20',{'o':u['org_id'],'i':str(lead_id),'e':'lead'}); services=[{'name':x} for x in ['Web Development','AI Automation','CRM / Sales Automation','Clinic / School Management','Custom Business Software']]; return render(request,'saas_lead_detail',lead=lead,outreach=out,followups=f,recommended=service_for(lead),acts=acts,services=services)
@app.post('/leads/{lead_id}/message')
def message(request:Request,lead_id:int,service:str=Form(''),csrf:str=Form(...)):
    u=require_user(request);require_csrf(request,csrf); lead=q('SELECT * FROM leads WHERE id=:id AND org_id=:o',{'id':lead_id,'o':u['org_id']})
    if not lead:raise HTTPException(404)
    if lead['email'] and q('SELECT id FROM suppression WHERE org_id=:o AND lower(email)=lower(:e)',{'o':u['org_id'],'e':lead['email']}):raise HTTPException(409,'Contact is suppressed')
    m=draft(lead,service or service_for(lead)); n=now(); oid=insert_id('INSERT INTO outreach(org_id,lead_id,channel,subject,body,status,created_at) VALUES(:o,:l,\'email\',:s,:b,\'draft\',:n)',{'o':u['org_id'],'l':lead_id,'s':m['subject'],'b':m['body'],'n':n}); audit(u,'draft','outreach',oid,'Human approval required before sending');return RedirectResponse(f'/leads/{lead_id}',303)
@app.post('/outreach/{oid}/approve')
def approve(request:Request,oid:int,csrf:str=Form(...)):
    u=require_user(request);require_csrf(request,csrf); out=q('SELECT * FROM outreach WHERE id=:i AND org_id=:o',{'i':oid,'o':u['org_id']})
    if not out:raise HTTPException(404)
    execsql("UPDATE outreach SET status='approved' WHERE id=:i AND org_id=:o",{'i':oid,'o':u['org_id']});audit(u,'approve','outreach',oid);return RedirectResponse(f"/leads/{out['lead_id']}",303)
@app.post('/outreach/{oid}/send')
def send(request:Request,oid:int,csrf:str=Form(...)):
    u=require_user(request);require_csrf(request,csrf);out=q('SELECT o.*,l.email FROM outreach o JOIN leads l ON l.id=o.lead_id WHERE o.id=:i AND o.org_id=:o AND l.org_id=:o',{'i':oid,'o':u['org_id']})
    if not out:raise HTTPException(404)
    if out['status']!='approved':raise HTTPException(409,'Approve before sending')
    if not out['email']:raise HTTPException(409,'Lead has no email')
    if q('SELECT id FROM suppression WHERE org_id=:o AND lower(email)=lower(:e)',{'o':u['org_id'],'e':out['email']}):raise HTTPException(409,'Suppressed contact')
    ok,msg=send_email(out['email'],out['subject'],out['body'])
    if not ok:return HTMLResponse(msg,503)
    execsql("UPDATE outreach SET status='sent',sent_at=:n WHERE id=:i AND org_id=:o",{'n':now(),'i':oid,'o':u['org_id']});audit(u,'send','outreach',oid,'SMTP send succeeded');return RedirectResponse(f"/leads/{out['lead_id']}",303)
@app.post('/leads/{lead_id}/status')
def update_status(request:Request,lead_id:int,status:str=Form(...),csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf)
    allowed={'new','contacted','replied','qualified','won','lost','nurture'}
    if status not in allowed: raise HTTPException(400,'Invalid status')
    lead=q('SELECT id FROM leads WHERE id=:l AND org_id=:o',{'l':lead_id,'o':u['org_id']})
    if not lead: raise HTTPException(404,'Lead not found')
    execsql('UPDATE leads SET status=:s,updated_at=:n WHERE id=:l AND org_id=:o',{'s':status,'n':now(),'l':lead_id,'o':u['org_id']}); audit(u,'status','lead',lead_id,status); return RedirectResponse(f'/leads/{lead_id}',303)

@app.post('/outreach/{oid}/reject')
def reject(request:Request,oid:int,csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf); out=q('SELECT * FROM outreach WHERE id=:i AND org_id=:o',{'i':oid,'o':u['org_id']})
    if not out: raise HTTPException(404)
    execsql("UPDATE outreach SET status='rejected' WHERE id=:i AND org_id=:o",{'i':oid,'o':u['org_id']}); audit(u,'reject','outreach',oid); return RedirectResponse(f"/leads/{out['lead_id']}",303)

@app.post('/leads/{lead_id}/followup')
def followup(request:Request,lead_id:int,days:int=Form(3),note:str=Form('Follow up with useful context'),csrf:str=Form(...)):
    u=require_user(request);require_csrf(request,csrf);lead=q('SELECT id FROM leads WHERE id=:l AND org_id=:o',{'l':lead_id,'o':u['org_id']})
    if not lead:raise HTTPException(404)
    due=(datetime.now(timezone.utc)+timedelta(days=max(1,min(days,60)))).isoformat();fid=insert_id('INSERT INTO followups(org_id,lead_id,due_at,note,created_at) VALUES(:o,:l,:d,:n,:n)',{'o':u['org_id'],'l':lead_id,'d':due,'n':note});audit(u,'schedule','followup',fid,due);return RedirectResponse(f'/leads/{lead_id}',303)
@app.post('/leads/{lead_id}/suppress')
def suppress(request:Request,lead_id:int,reason:str=Form('opt-out'),csrf:str=Form(...)):
    u=require_user(request);require_csrf(request,csrf);lead=q('SELECT * FROM leads WHERE id=:l AND org_id=:o',{'l':lead_id,'o':u['org_id']})
    if not lead:raise HTTPException(404)
    if lead['email']:execsql('INSERT INTO suppression(org_id,email,reason,created_at) VALUES(:o,:e,:r,:n) ON CONFLICT(org_id,email) DO NOTHING',{'o':u['org_id'],'e':lead['email'],'r':reason,'n':now()})
    audit(u,'suppress','lead',lead_id,reason);return RedirectResponse(f'/leads/{lead_id}',303)

@app.get('/campaigns',response_class=HTMLResponse)
def campaigns(request:Request):
    u=require_user(request);return render(request,'saas_campaigns',campaigns=qall('SELECT * FROM campaigns WHERE org_id=:o ORDER BY id DESC',{'o':u['org_id']}))
@app.post('/campaigns')
def campaign(request:Request,name:str=Form(...),industry:str=Form(''),country:str=Form(''),service:str=Form(''),min_score:int=Form(70),csrf:str=Form(...)):
    u=require_user(request);require_csrf(request,csrf);cid=insert_id('INSERT INTO campaigns(org_id,name,industry,country,service,min_score,created_at) VALUES(:o,:n,:i,:c,:s,:m,:t)',{'o':u['org_id'],'n':name,'i':industry,'c':country,'s':service,'m':max(0,min(100,min_score)),'t':now()});audit(u,'create','campaign',cid);return RedirectResponse('/campaigns',303)
@app.post('/campaigns/{cid}/run')
def run_campaign(request:Request,cid:int,csrf:str=Form(...)):
    u=require_user(request);require_csrf(request,csrf);c=q('SELECT * FROM campaigns WHERE id=:i AND org_id=:o',{'i':cid,'o':u['org_id']})
    if not c:raise HTTPException(404)
    p={'o':u['org_id'],'m':c['min_score']};sql='SELECT * FROM leads WHERE org_id=:o AND lead_score>=:m';
    if c['industry']:sql+=' AND lower(industry)=lower(:i)';p['i']=c['industry']
    if c['country']:sql+=' AND lower(country)=lower(:co)';p['co']=c['country']
    leads=qall(sql,p);created=0
    for lead in leads:
        if not lead['email']:continue
        if q('SELECT id FROM suppression WHERE org_id=:o AND lower(email)=lower(:e)',{'o':u['org_id'],'e':lead['email']}):continue
        m=draft(lead,c['service'] or service_for(lead));insert_id('INSERT INTO outreach(org_id,lead_id,channel,subject,body,status,created_at) VALUES(:o,:l,\'email\',:s,:b,\'draft\',:n)',{'o':u['org_id'],'l':lead['id'],'s':m['subject'],'b':m['body'],'n':now()});created+=1
    audit(u,'run','campaign',cid,f'generated {created} drafts from {len(leads)} matched leads');return RedirectResponse('/campaigns',303)

@app.post('/agents/run')
def agents(request:Request,csrf:str=Form(...)):
    u=require_user(request);require_csrf(request,csrf);leads=qall('SELECT * FROM leads WHERE org_id=:o',{'o':u['org_id']});changed=0
    for l in leads:
        need,sc,op=score(l);execsql('UPDATE leads SET need_score=:n,lead_score=:s,opportunity=:op,updated_at=:t WHERE id=:i AND org_id=:o',{'n':need,'s':sc,'op':op,'t':now(),'i':l['id'],'o':u['org_id']});changed+=1
    aid=insert_id('INSERT INTO agent_runs(org_id,agent,status,input_count,output_count,message,created_at) VALUES(:o,\'orchestrator\',\'completed\',:i,:out,:m,:n)',{'o':u['org_id'],'i':len(leads),'out':changed,'m':'Scout → Research → Scoring → Opportunity → Personalization pipeline refreshed.','n':now()});audit(u,'run','agent',aid,f'processed {changed} leads');return RedirectResponse('/',303)

@app.get('/analytics',response_class=HTMLResponse)
def analytics(request:Request):
    u=require_user(request);d=q('SELECT COUNT(*) total,SUM(CASE WHEN lead_score>=75 THEN 1 ELSE 0 END) qualified,SUM(CASE WHEN status=\'contacted\' THEN 1 ELSE 0 END) contacted,SUM(CASE WHEN status=\'replied\' THEN 1 ELSE 0 END) replied,SUM(CASE WHEN status=\'won\' THEN 1 ELSE 0 END) won FROM leads WHERE org_id=:o',{'o':u['org_id']}) or {};return render(request,'saas_analytics',data=d)

@app.get('/team',response_class=HTMLResponse)
def team(request:Request):
    u=require_user(request); members=qall('SELECT id,email,full_name,role,active,created_at FROM users WHERE org_id=:o ORDER BY id',{'o':u['org_id']}); invites=qall('SELECT id,email,role,expires_at,accepted_at,created_at FROM invites WHERE org_id=:o ORDER BY id DESC',{'o':u['org_id']}); return render(request,'saas_team',members=members,invites=invites)

@app.post('/team/invite')
def invite(request:Request,email:str=Form(...),role:str=Form('member'),csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf); require_role(u,{'owner','admin'}); enforce_limit(u['org_id'],'users')
    email=email.lower().strip(); role=role if role in {'admin','member'} else 'member'
    if q('SELECT id FROM users WHERE org_id=:o AND lower(email)=lower(:e)',{'o':u['org_id'],'e':email}): raise HTTPException(409,'User already exists')
    raw=secrets.token_urlsafe(32); token_hash=hashlib.sha256(raw.encode()).hexdigest(); expires=(datetime.now(timezone.utc)+timedelta(days=3)).isoformat(); iid=insert_id('INSERT INTO invites(org_id,email,role,token_hash,expires_at,created_at) VALUES(:o,:e,:r,:h,:x,:n)',{'o':u['org_id'],'e':email,'r':role,'h':token_hash,'x':expires,'n':now()}); audit(u,'invite','user',iid,email); return PlainTextResponse('Invite created. Share this one-time token securely:\n'+raw,200)

@app.post('/team/accept')
def accept_invite(request:Request,email:str=Form(...),password:str=Form(...),full_name:str=Form(...),token:str=Form(...),csrf:str=Form(...)):
    require_csrf(request,csrf)
    if not password_ok(password): raise HTTPException(400,'Password policy not met')
    h=hashlib.sha256(token.encode()).hexdigest(); inv=q('SELECT * FROM invites WHERE token_hash=:h AND lower(email)=lower(:e) AND accepted_at IS NULL',{'h':h,'e':email})
    if not inv or inv['expires_at']<=now(): raise HTTPException(400,'Invalid or expired invitation')
    if q('SELECT id FROM users WHERE org_id=:o AND lower(email)=lower(:e)',{'o':inv['org_id'],'e':email}): raise HTTPException(409,'User already exists')
    uid=insert_id('INSERT INTO users(org_id,email,password_hash,full_name,role,email_verified,created_at) VALUES(:o,:e,:p,:f,:r,1,:n)',{'o':inv['org_id'],'e':email.lower().strip(),'p':pbkdf(password),'f':full_name.strip(),'r':inv['role'],'n':now()})
    execsql('UPDATE invites SET accepted_at=:n WHERE id=:i',{'n':now(),'i':inv['id']}); request.session.clear();request.session['user_id']=uid;csrf_for(request); return RedirectResponse('/',303)

@app.get('/settings',response_class=HTMLResponse)
def settings(request:Request):
    u=require_user(request);org=q('SELECT * FROM organizations WHERE id=:o',{'o':u['org_id']});keys=qall('SELECT id,name,key_prefix,created_at,last_used_at FROM api_keys WHERE org_id=:o AND active=1 ORDER BY id DESC',{'o':u['org_id']});sub=q('SELECT * FROM subscriptions WHERE org_id=:o',{'o':u['org_id']});return render(request,'saas_settings',org=org,keys=keys,sub=sub)
@app.post('/settings/api-key')
def api_key(request:Request,name:str=Form('API Key'),csrf:str=Form(...)):
    u=require_user(request);require_csrf(request,csrf);require_role(u,{'owner','admin'}); enforce_limit(u['org_id'],'api_keys'); raw='cha_'+secrets.token_urlsafe(32); h=hashlib.sha256(raw.encode()).hexdigest();pref=raw[:10];execsql('INSERT INTO api_keys(org_id,name,key_hash,key_prefix,created_at) VALUES(:o,:n,:h,:p,:t)',{'o':u['org_id'],'n':name,'h':h,'p':pref,'t':now()});audit(u,'create','api_key',pref);return PlainTextResponse(f'Created once. Save this key securely:\n{raw}',200)
@app.post('/settings/api-key/{kid}/revoke')
def revoke_key(request:Request,kid:int,csrf:str=Form(...)):
    u=require_user(request);require_csrf(request,csrf);require_role(u,{'owner','admin'});execsql('UPDATE api_keys SET active=0 WHERE id=:i AND org_id=:o',{'i':kid,'o':u['org_id']});audit(u,'revoke','api_key',kid);return RedirectResponse('/settings',303)

@app.post('/api/v1/leads')
def api_create_lead(payload:dict, request:Request):
    org=api_org(request)
    if not org:raise HTTPException(401,'Invalid API key')
    enforce_limit(org['id'],'leads')
    need,sc,op=score(payload);n=now();company=payload.get('company_name','Unnamed company');website=payload.get('website','')
    idem=request.headers.get('Idempotency-Key','').strip()
    if idem:
        if len(idem)>128: raise HTTPException(400,'Invalid Idempotency-Key')
        cached=q('SELECT response_json FROM idempotency_keys WHERE org_id=:o AND idem_key=:k AND route=:r',{'o':org['id'],'k':idem,'r':'POST /api/v1/leads'})
        if cached: return JSONResponse(json.loads(cached['response_json']),201)
    try:
        lid=insert_id('INSERT INTO leads(org_id,company_name,website,country,city,industry,contact_name,email,phone,source,website_score,need_score,service_match,contact_score,lead_score,opportunity,evidence,notes,created_at,updated_at) VALUES(:o,:c,:w,:co,:ci,:i,:cn,:e,:p,:src,:ws,:ns,:sm,:cs,:s,:op,:ev,:no,:n,:n)',{'o':org['id'],'c':company,'w':website,'co':payload.get('country',''),'ci':payload.get('city',''),'i':payload.get('industry',''),'cn':payload.get('contact_name',''),'e':payload.get('email',''),'p':payload.get('phone',''),'src':payload.get('source','api'),'ws':payload.get('website_score',50),'ns':need,'sm':payload.get('service_match',50),'cs':payload.get('contact_score',50),'s':sc,'op':op,'ev':payload.get('evidence',''),'no':payload.get('notes',''),'n':n})
    except Exception:raise HTTPException(409,'Duplicate lead')
    response={'id':lid,'lead_score':sc,'tier':op}
    if idem:
        try: execsql('INSERT INTO idempotency_keys(org_id,idem_key,route,response_json,created_at) VALUES(:o,:k,:r,:j,:n)',{'o':org['id'],'k':idem,'r':'POST /api/v1/leads','j':json.dumps(response,separators=(',',':')),'n':n})
        except Exception: pass
    return JSONResponse(response,201)
@app.get('/api/v1/leads')
def api_list_leads(request:Request):
    org=api_org(request)
    if not org:raise HTTPException(401,'Invalid API key')
    return qall('SELECT * FROM leads WHERE org_id=:o ORDER BY lead_score DESC,id DESC',{'o':org['id']})
@app.post('/api/v1/import/csv')
async def api_csv(request:Request,file:UploadFile=File(...)):
    org=api_org(request)
    if not org:raise HTTPException(401,'Invalid API key')
    raw=(await file.read()).decode('utf-8-sig'); reader=csv.DictReader(io.StringIO(raw));count=0
    for r in reader:
        if not r.get('company_name'):continue
        need,sc,op=score(r)
        try:
            insert_id('INSERT INTO leads(org_id,company_name,website,country,city,industry,contact_name,email,phone,source,need_score,lead_score,opportunity,evidence,notes,created_at,updated_at) VALUES(:o,:c,:w,:co,:ci,:i,:cn,:e,:p,\'csv\',:ns,:s,:op,:ev,:no,:n,:n)',{'o':org['id'],'c':r['company_name'],'w':r.get('website',''),'co':r.get('country',''),'ci':r.get('city',''),'i':r.get('industry',''),'cn':r.get('contact_name',''),'e':r.get('email',''),'p':r.get('phone',''),'ns':need,'s':sc,'op':op,'ev':r.get('evidence',''),'no':r.get('notes',''),'n':now()});count+=1
        except Exception:pass
    return {'imported':count}

@app.get('/export/leads.csv')
def export(request:Request):
    u=require_user(request);data=qall('SELECT * FROM leads WHERE org_id=:o ORDER BY lead_score DESC,id DESC',{'o':u['org_id']});out=io.StringIO()
    if data:w=csv.DictWriter(out,fieldnames=data[0].keys());w.writeheader();w.writerows(data)
    return StreamingResponse(iter([out.getvalue()]),media_type='text/csv',headers={'Content-Disposition':'attachment; filename=clienthunt_leads.csv'})

@app.get('/api/v1/replies/classify')
def classify_reply(request:Request,text_in:str=''):
    org=api_org(request)
    if not org:raise HTTPException(401,'Invalid API key')
    x=text_in.lower(); label='unsubscribe' if any(k in x for k in ['unsubscribe','remove me','stop emailing']) else 'not_interested' if any(k in x for k in ['not interested','no thanks']) else 'price_request' if any(k in x for k in ['price','cost','budget','quote']) else 'interested' if any(k in x for k in ['interested','let\'s talk','book','meeting','call']) else 'question' if '?' in x else 'later'
    return {'classification':label}

@app.get('/api/v1/calendar.ics')
def calendar(request:Request,followup_id:int,title:str='ClientHunt follow-up'):
    u=require_user(request);f=q('SELECT f.*,l.company_name FROM followups f JOIN leads l ON l.id=f.lead_id WHERE f.id=:i AND f.org_id=:o AND l.org_id=:o',{'i':followup_id,'o':u['org_id']})
    if not f:raise HTTPException(404)
    dt=f['due_at'].replace('-','').replace(':','').replace('+00:00','Z').replace('.000000','')
    uid=str(uuid.uuid4())
    def ics_escape(v):
        return str(v).replace('\\','\\\\').replace(';','\\;').replace(',','\\,').replace('\n','\\n').replace('\r','')
    ics=f"BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//CLIENTHUNT AI//EN\r\nBEGIN:VEVENT\r\nUID:{uid}\r\nDTSTAMP:{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}\r\nDTSTART:{dt}\r\nSUMMARY:{ics_escape(title)} - {ics_escape(f['company_name'])}\r\nDESCRIPTION:{ics_escape(f['note'])}\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n";return PlainTextResponse(ics,media_type='text/calendar')

def stripe_post(path, form):
    key=os.getenv('STRIPE_SECRET_KEY','')
    if not key: raise HTTPException(503,'Stripe billing is not configured')
    import urllib.request
    req=urllib.request.Request('https://api.stripe.com/v1/'+path,data=urlencode(form).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/x-www-form-urlencoded'},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=20) as r: return json.loads(r.read().decode())
    except Exception as e: raise HTTPException(502,f'Billing provider error: {type(e).__name__}')

@app.post('/billing/checkout')
def billing_checkout(request:Request,plan:str=Form('pro'),csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf); require_role(u,{'owner','admin'})
    price=os.getenv('STRIPE_PRICE_PRO','') if plan=='pro' else os.getenv('STRIPE_PRICE_STARTER','')
    if not price: raise HTTPException(503,'Selected paid plan is not configured')
    org=q('SELECT * FROM organizations WHERE id=:o',{'o':u['org_id']})
    customer=q('SELECT customer_id FROM subscriptions WHERE org_id=:o',{'o':u['org_id']})
    form={'mode':'subscription','line_items[0][price]':price,'line_items[0][quantity]':'1','success_url':APP_URL+'/settings?billing=success','cancel_url':APP_URL+'/settings?billing=cancel','client_reference_id':str(u['org_id']),'metadata[org_id]':str(u['org_id']),'metadata[plan]':plan}
    if customer and customer.get('customer_id'): form['customer']=customer['customer_id']
    else: form['customer_email']=u['email']
    data=stripe_post('checkout/sessions',form); return RedirectResponse(data.get('url','/settings'),303)

@app.post('/billing/portal')
def billing_portal(request:Request,csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf); require_role(u,{'owner','admin'}); sub=q('SELECT customer_id FROM subscriptions WHERE org_id=:o',{'o':u['org_id']})
    if not sub or not sub.get('customer_id'): raise HTTPException(409,'No billing customer exists yet')
    data=stripe_post('billing_portal/sessions',{'customer':sub['customer_id'],'return_url':APP_URL+'/settings'}); return RedirectResponse(data.get('url','/settings'),303)

@app.post('/api/webhooks/stripe')
async def stripe_webhook(request:Request):
    payload=await request.body(); header=request.headers.get('stripe-signature',''); secret=os.getenv('STRIPE_WEBHOOK_SECRET','')
    if not secret: return JSONResponse({'error':'Stripe webhook not configured'},503)
    # Stripe signature: t=timestamp,v1=HMAC_SHA256(timestamp+'.'+raw_body).
    parts=dict(item.split('=',1) for item in header.split(',') if '=' in item)
    try: ts=int(parts.get('t','0')); sig=parts.get('v1','')
    except Exception: ts=0; sig=''
    tolerance=int(os.getenv('STRIPE_WEBHOOK_TOLERANCE','300'))
    expected=hmac.new(secret.encode(),f'{ts}.'.encode()+payload,hashlib.sha256).hexdigest() if ts else ''
    if not sig or not hmac.compare_digest(expected,sig) or abs(int(datetime.now(timezone.utc).timestamp())-ts)>tolerance:
        return JSONResponse({'error':'invalid signature'},400)
    try:data=json.loads(payload)
    except Exception:return JSONResponse({'error':'invalid json'},400)
    event_id=str(data.get('id') or hashlib.sha256(payload).hexdigest())
    if q('SELECT id FROM webhook_events WHERE event_id=:e',{'e':event_id}):return {'ok':True,'duplicate':True}
    execsql("INSERT INTO webhook_events(provider,event_id,payload,received_at) VALUES('stripe',:e,:p,:n)",{'e':event_id,'p':payload.decode('utf-8','ignore'),'n':now()})
    # Billing state updates are intentionally conservative; map only known subscription events.
    obj=(data.get('data') or {}).get('object') or {}
    if data.get('type')=='checkout.session.completed':
        org_id=(obj.get('client_reference_id') or (obj.get('metadata') or {}).get('org_id'))
        if org_id and str(org_id).isdigit():
            execsql("UPDATE subscriptions SET customer_id=:c,subscription_id=:s,plan=:p,status='active',updated_at=:n WHERE org_id=:o",{'c':obj.get('customer'),'s':obj.get('subscription'),'p':(obj.get('metadata') or {}).get('plan','pro'),'n':now(),'o':int(org_id)})
            execsql('UPDATE organizations SET plan=:p WHERE id=:o',{'p':(obj.get('metadata') or {}).get('plan','pro'),'o':int(org_id)})
    sub_id=obj.get('id') if data.get('type','').startswith('customer.subscription.') else None
    if sub_id:
        status=obj.get('status','unknown'); period_end=obj.get('current_period_end'); customer_id=obj.get('customer'); metadata=obj.get('metadata') or {}; org_id=metadata.get('org_id')
        target=q('SELECT org_id FROM subscriptions WHERE subscription_id=:sid',{'sid':sub_id}) or (q('SELECT org_id FROM subscriptions WHERE customer_id=:cid',{'cid':customer_id}) if customer_id else None) or (q('SELECT id AS org_id FROM organizations WHERE id=:id',{'id':org_id}) if org_id and str(org_id).isdigit() else None)
        if target:
            execsql('UPDATE subscriptions SET status=:s,subscription_id=:sid,customer_id=:cid,plan=:p,current_period_end=:pe,updated_at=:n WHERE org_id=:o',{'s':status,'sid':sub_id,'cid':customer_id,'p':metadata.get('plan','pro'),'pe':datetime.fromtimestamp(period_end,timezone.utc).isoformat() if period_end else None,'n':now(),'o':target['org_id']})
            execsql('UPDATE organizations SET plan=:p WHERE id=:o',{'p':metadata.get('plan','pro') if status in {'active','trialing','past_due'} else 'free','o':target['org_id']})
    return {'ok':True,'duplicate':False}



def classify_text(text_in):
    x=(text_in or '').lower()
    rules=[
        ('unsubscribe',['unsubscribe','remove me','stop emailing','do not contact','do not email'],98),
        ('not_interested',['not interested','no thanks','not a fit','pass for now'],96),
        ('price_request',['price','cost','budget','quote','pricing'],92),
        ('meeting_request',['meeting','book a call','schedule a call','calendar','demo'],95),
        ('interested',['interested','sounds good','tell me more','let us talk','let’s talk'],90),
        ('question',['?','how does','what do you','can you'],78),
    ]
    for label,keys,conf in rules:
        if any(k in x for k in keys): return label,conf
    return 'later',55

def safe_public_url(url):
    u=urlparse((url or '').strip())
    if u.scheme not in {'http','https'} or not u.hostname: return False
    try:
        infos=socket.getaddrinfo(u.hostname,None)
        for info in infos:
            ip=ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast: return False
    except Exception: return False
    return True

def research_public_site(url):
    if not safe_public_url(url): raise HTTPException(400,'Only public http/https websites are allowed for research')
    started=datetime.now(timezone.utc)
    req=urllib.request.Request(url,headers={'User-Agent':'CLIENTHUNT-AI-Research/5.0'})
    try:
        with urllib.request.urlopen(req,timeout=8) as r:
            raw=r.read(300_000)
            status=getattr(r,'status',200); final=r.geturl()
        text_body=raw.decode('utf-8','ignore')
        title=''
        m=re.search(r'<title[^>]*>(.*?)</title>',text_body,re.I|re.S)
        if m:title=re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]+>',' ',m.group(1)))).strip()[:300]
        visible=re.sub(r'<script.*?</script>|<style.*?</style>|<[^>]+>',' ',text_body,flags=re.I|re.S)
        visible=re.sub(r'\s+',' ',html.unescape(visible)).strip()
        signals=['booking','appointment','outdated','old website','mobile','chatbot','crm','online ordering','automation','manual','excel','paper','portal','slow']
        hits=[x for x in signals if x in visible.lower()]
        evidence='Public-site research: '+(', '.join(hits) if hits else 'no explicit opportunity signal detected')
        ms=int((datetime.now(timezone.utc)-started).total_seconds()*1000)
        return {'status':'ok','http_status':status,'title':title,'evidence':evidence,'latency_ms':ms,'final_url':final}
    except Exception as e:
        ms=int((datetime.now(timezone.utc)-started).total_seconds()*1000)
        return {'status':'error','http_status':0,'title':'','evidence':f'Research error: {type(e).__name__}','latency_ms':ms,'final_url':url}

def record_learning(user, lead_id, event_type, value=''):
    execsql('INSERT INTO learning_events(org_id,lead_id,event_type,value,created_at) VALUES(:o,:l,:e,:v,:n)',{'o':user['org_id'],'l':lead_id,'e':event_type,'v':str(value)[:2000],'n':now()})

def render_advanced(request,page,**ctx):
    u=require_user(request); ctx.update(user=u,csrf=csrf_for(request)); return templates.TemplateResponse(request,f'{page}.html',ctx)

@app.get('/discovery',response_class=HTMLResponse)
def discovery(request:Request):
    u=require_user(request)
    runs=qall('SELECT r.*,l.company_name FROM research_runs r JOIN leads l ON l.id=r.lead_id WHERE r.org_id=:o ORDER BY r.id DESC LIMIT 20',{'o':u['org_id']})
    return render_advanced(request,'saas_discovery',runs=runs)

@app.post('/discovery/research/{lead_id}')
def discovery_research(request:Request,lead_id:int,csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf)
    lead=q('SELECT * FROM leads WHERE id=:l AND org_id=:o',{'l':lead_id,'o':u['org_id']})
    if not lead or not lead.get('website'): raise HTTPException(400,'Lead must have a public website')
    result=research_public_site(lead['website'])
    execsql('INSERT INTO research_runs(org_id,lead_id,url,status,http_status,title,evidence,latency_ms,created_at) VALUES(:o,:l,:u,:s,:h,:t,:e,:ms,:n)',{'o':u['org_id'],'l':lead_id,'u':lead['website'],'s':result['status'],'h':result['http_status'],'t':result['title'],'e':result['evidence'],'ms':result['latency_ms'],'n':now()})
    if result['status']=='ok':
        combined=(lead.get('evidence') or '')+' | '+result['evidence']; need,sc,op=score({**lead,'evidence':combined})
        execsql('UPDATE leads SET evidence=:e,need_score=:ns,lead_score=:s,opportunity=:op,updated_at=:n WHERE id=:l AND org_id=:o',{'e':combined[:4000],'ns':need,'s':sc,'op':op,'n':now(),'l':lead_id,'o':u['org_id']})
        record_learning(u,lead_id,'research_completed',result['evidence'])
    audit(u,'research','lead',lead_id,result['status']); return RedirectResponse(f'/leads/{lead_id}',303)

@app.get('/replies',response_class=HTMLResponse)
def replies(request:Request):
    u=require_user(request); rows=qall('SELECT r.*,l.company_name FROM reply_events r JOIN leads l ON l.id=r.lead_id WHERE r.org_id=:o ORDER BY r.id DESC LIMIT 100',{'o':u['org_id']})
    return render_advanced(request,'saas_replies',replies=rows)

@app.post('/replies/new')
def reply_new(request:Request,lead_id:int=Form(...),body:str=Form(...),sender:str=Form(''),csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf)
    lead=q('SELECT id FROM leads WHERE id=:l AND org_id=:o',{'l':lead_id,'o':u['org_id']})
    if not lead: raise HTTPException(404)
    label,conf=classify_text(body)
    execsql('INSERT INTO reply_events(org_id,lead_id,channel,sender,body,classification,confidence,created_at) VALUES(:o,:l,\'email\',:s,:b,:c,:f,:n)',{'o':u['org_id'],'l':lead_id,'s':sender,'b':body[:10000],'c':label,'f':conf,'n':now()})
    if label=='unsubscribe':
        lead_email=q('SELECT email FROM leads WHERE id=:l AND org_id=:o',{'l':lead_id,'o':u['org_id']})
        if lead_email and lead_email.get('email'):
            try: execsql('INSERT INTO suppression(org_id,email,reason,created_at) VALUES(:o,:e,\'reply unsubscribe\',:n)',{'o':u['org_id'],'e':lead_email['email'].lower(),'n':now()})
            except Exception: pass
    new_status='replied' if label in {'interested','meeting_request','question','price_request'} else ('lost' if label=='not_interested' else 'contacted')
    execsql('UPDATE leads SET status=:s,updated_at=:n WHERE id=:l AND org_id=:o',{'s':new_status,'n':now(),'l':lead_id,'o':u['org_id']})
    record_learning(u,lead_id,'reply_classified',label); audit(u,'reply','lead',lead_id,label); return RedirectResponse('/replies',303)

@app.get('/proposals',response_class=HTMLResponse)
def proposals(request:Request):
    u=require_user(request); rows=qall('SELECT p.*,l.company_name FROM proposals p JOIN leads l ON l.id=p.lead_id WHERE p.org_id=:o ORDER BY p.id DESC',{'o':u['org_id']})
    leads=qall('SELECT id,company_name FROM leads WHERE org_id=:o ORDER BY company_name',{'o':u['org_id']})
    return render_advanced(request,'saas_proposals',proposals=rows,leads=leads)

@app.post('/proposals')
def proposal_create(request:Request,lead_id:int=Form(...),title:str=Form(...),summary:str=Form(''),amount:str=Form(''),currency:str=Form('PKR'),csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf)
    if not q('SELECT id FROM leads WHERE id=:l AND org_id=:o',{'l':lead_id,'o':u['org_id']}): raise HTTPException(404)
    pid=insert_id('INSERT INTO proposals(org_id,lead_id,title,summary,amount,currency,status,valid_until,created_at,updated_at) VALUES(:o,:l,:t,:s,:a,:c,\'draft\',:v,:n,:n)',{'o':u['org_id'],'l':lead_id,'t':title[:200],'s':summary[:8000],'a':amount[:80],'c':currency[:10],'v':(datetime.now(timezone.utc)+timedelta(days=14)).isoformat(),'n':now()})
    record_learning(u,lead_id,'proposal_created',pid); audit(u,'create','proposal',pid); return RedirectResponse('/proposals',303)

@app.post('/proposals/{pid}/status')
def proposal_status(request:Request,pid:int,status:str=Form(...),csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf)
    allowed={'draft','sent','viewed','accepted','declined','expired'}
    if status not in allowed: raise HTTPException(400,'Invalid proposal status')
    p=q('SELECT * FROM proposals WHERE id=:i AND org_id=:o',{'i':pid,'o':u['org_id']})
    if not p: raise HTTPException(404)
    execsql('UPDATE proposals SET status=:s,updated_at=:n WHERE id=:i AND org_id=:o',{'s':status,'n':now(),'i':pid,'o':u['org_id']})
    record_learning(u,p['lead_id'],'proposal_status',status); audit(u,'status','proposal',pid,status); return RedirectResponse('/proposals',303)

@app.get('/meetings',response_class=HTMLResponse)
def meetings(request:Request):
    u=require_user(request); rows=qall('SELECT m.*,l.company_name FROM meetings m JOIN leads l ON l.id=m.lead_id WHERE m.org_id=:o ORDER BY m.starts_at',{'o':u['org_id']}); leads=qall('SELECT id,company_name FROM leads WHERE org_id=:o ORDER BY company_name',{'o':u['org_id']})
    return render_advanced(request,'saas_meetings',meetings=rows,leads=leads)

@app.post('/meetings')
def meeting_create(request:Request,lead_id:int=Form(...),title:str=Form(...),starts_at:str=Form(...),duration_minutes:int=Form(30),csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf)
    if not q('SELECT id FROM leads WHERE id=:l AND org_id=:o',{'l':lead_id,'o':u['org_id']}): raise HTTPException(404)
    insert_id('INSERT INTO meetings(org_id,lead_id,title,starts_at,duration_minutes,status,created_at) VALUES(:o,:l,:t,:s,:d,\'scheduled\',:n)',{'o':u['org_id'],'l':lead_id,'t':title[:200],'s':starts_at,'d':max(5,min(480,duration_minutes)),'n':now()})
    record_learning(u,lead_id,'meeting_scheduled',starts_at); audit(u,'create','meeting',lead_id); return RedirectResponse('/meetings',303)

@app.get('/learning',response_class=HTMLResponse)
def learning(request:Request):
    u=require_user(request)
    summary=qall('SELECT event_type,COUNT(*) count FROM learning_events WHERE org_id=:o GROUP BY event_type ORDER BY count DESC',{'o':u['org_id']})
    outcomes=qall('SELECT status,COUNT(*) count FROM leads WHERE org_id=:o GROUP BY status ORDER BY count DESC',{'o':u['org_id']})
    return render_advanced(request,'saas_learning',summary=summary,outcomes=outcomes)

@app.get('/diagnostics',response_class=HTMLResponse)
def diagnostics(request:Request):
    require_user(request)
    checks=[]
    for name,fn in [('database',lambda:q('SELECT 1')),('templates',lambda:[p.name for p in (BASE/'templates').glob('*.html')]),('static',lambda:True if (BASE/'static'/'saas.css').exists() else (_ for _ in ()).throw(RuntimeError('missing static asset'))),('secret',lambda:len(SECRET)>=32),('production_https',lambda:((ENVIRONMENT!='production') or COOKIE_SECURE) or (_ for _ in ()).throw(RuntimeError('HTTPS cookie mode disabled'))),('stripe',lambda:bool(os.getenv('STRIPE_SECRET_KEY'))),('smtp',lambda:bool(os.getenv('SMTP_HOST') and os.getenv('SMTP_USER') and os.getenv('SMTP_PASSWORD'))),('ollama',lambda:bool(os.getenv('OLLAMA_URL')) )]:
        try: fn(); checks.append((name,True))
        except Exception: checks.append((name,False))
    return render_advanced(request,'saas_diagnostics',checks=checks)

@app.post('/settings/export.json')
def export_workspace_json(request:Request,csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf)
    data={}
    for table in ['organizations','users','leads','campaigns','outreach','followups','suppression','audit_log','api_keys','subscriptions','agent_runs','contacts','research_runs','proposals','meetings','reply_events','learning_events']:
        if table=='organizations': rows=qall('SELECT * FROM organizations WHERE id=:o',{'o':u['org_id']})
        elif table=='users': rows=qall('SELECT id,org_id,email,full_name,role,active,email_verified,created_at FROM users WHERE org_id=:o',{'o':u['org_id']})
        else: rows=qall(f'SELECT * FROM {table} WHERE org_id=:o',{'o':u['org_id']})
        data[table]=rows
    payload=json.dumps(data,ensure_ascii=False,indent=2).encode()
    return StreamingResponse(iter([payload]),media_type='application/json',headers={'Content-Disposition':'attachment; filename=clienthunt_workspace_export.json'})

@app.post('/settings/delete-workspace')
def delete_workspace(request:Request,confirmation:str=Form(...),csrf:str=Form(...)):
    u=require_user(request); require_csrf(request,csrf); require_role(u,{'owner'})
    org=q('SELECT name FROM organizations WHERE id=:o',{'o':u['org_id']})
    if not org or confirmation.strip()!=org['name']: raise HTTPException(400,'Workspace name confirmation does not match')
    oid=u['org_id']; execsql('DELETE FROM organizations WHERE id=:o',{'o':oid}); request.session.clear(); return RedirectResponse('/register',303)

@app.post('/internal/worker/run')
def worker_run(request:Request):
    if not INTERNAL_KEY or not hmac.compare_digest(request.headers.get('x-internal-key',''),INTERNAL_KEY): raise HTTPException(403)
    due=qall("SELECT * FROM followups WHERE status='pending' AND due_at<=:n ORDER BY due_at LIMIT 500",{'n':now()})
    for f in due: execsql("UPDATE followups SET status='ready' WHERE id=:i",{'i':f['id']})
    return {'processed_followups':len(due),'timestamp':now()}


@app.get('/api/ready')
def ready():
    try:
        q('SELECT 1')
        return {'status':'ready','database':True,'version':'5.0.0'}
    except Exception as e:
        return JSONResponse({'status':'not_ready','database':False,'error':type(e).__name__},503)

@app.get('/api/metrics')
def metrics(request:Request):
    u=require_user(request)
    o=u['org_id']
    lead=q('SELECT COUNT(*) count FROM leads WHERE org_id=:o',{'o':o})['count']
    won=q("SELECT COUNT(*) count FROM leads WHERE org_id=:o AND status='won'",{'o':o})['count']
    replies=q('SELECT COUNT(*) count FROM reply_events WHERE org_id=:o',{'o':o})['count']
    meetings=q('SELECT COUNT(*) count FROM meetings WHERE org_id=:o',{'o':o})['count']
    proposals=q('SELECT COUNT(*) count FROM proposals WHERE org_id=:o',{'o':o})['count']
    return {'organization_id':o,'leads':lead,'won':won,'replies':replies,'meetings':meetings,'proposals':proposals,'win_rate_percent':round((won/lead)*100,2) if lead else 0}

@app.get('/api/health')
def health():
    try:q('SELECT 1 ok');db=True
    except Exception:db=False
    ollama=False
    try:
        import urllib.request
        urllib.request.urlopen(os.getenv('OLLAMA_URL','http://127.0.0.1:11434/api/tags'),timeout=1).read(64); ollama=True
    except Exception: pass
    return {'status':'ok' if db else 'degraded','app':'CLIENTHUNT AI SaaS','version':'5.0.0','database':db,'ollama':ollama,'environment':os.getenv('ENVIRONMENT','development')}

@app.post('/internal/followups/run')
def run_due(request:Request):
    if not INTERNAL_KEY or not hmac.compare_digest(request.headers.get('x-internal-key',''),INTERNAL_KEY):raise HTTPException(403)
    due=qall("SELECT * FROM followups WHERE status='pending' AND due_at<=:n",{'n':now()});
    for f in due:execsql("UPDATE followups SET status='ready' WHERE id=:i",{'i':f['id']})
    return {'ready':len(due)}
