$ErrorActionPreference = 'Stop'
$py = '.\.venv\Scripts\python.exe'
if (-not (Test-Path $py)) { throw '.venv is missing. Run .\setup-windows.ps1 first.' }
$env:ENVIRONMENT='development'
$env:APP_SECRET='local-development-secret-change-before-production'
& $py -m uvicorn app.saas_main:app --host 127.0.0.1 --port 8000 --reload
