## Windows quick start

Open PowerShell in the folder that contains `requirements.txt`. You do **not** need to activate the virtual environment; the included scripts call `.venv\Scripts\python.exe` directly.

```powershell
.\setup-windows.ps1
.\run-tests.ps1
.\run-dev.ps1
```

If PowerShell blocks `.ps1` scripts, use the direct commands below instead:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pytest -q tests/test_commercial.py
.\.venv\Scripts\python.exe -m uvicorn app.saas_main:app --host 127.0.0.1 --port 8000 --reload
```

Then open `http://127.0.0.1:8000/register`.

# CLIENTHUNT AI — Ultimate Commercial SaaS v5.0

CLIENTHUNT AI is a multi-tenant client-acquisition operating system for agencies, software houses and B2B teams. This release combines CRM, compliant public-site research, scoring, opportunity intelligence, campaigns, AI personalization, human approval, reply intelligence, meetings, proposals, learning, API access, subscriptions and production operations in one application.

## Feature-complete application scope
- Multi-tenant organizations and strict org-scoped business queries
- Owner/admin/member roles and team invitations
- Secure signed sessions, CSRF, password hashing, lockout and password reset
- Email verification token flow (local mode returns token so testing costs zero)
- Lead CRM, duplicate protection, scoring, opportunity detection and service matching
- CSV import/export
- Public website research with SSRF protections and evidence capture
- Campaign engine and human approval gate
- SMTP outreach adapter with suppression/opt-out enforcement
- Follow-up queue and internal worker endpoint
- Reply classification and automatic pipeline updates
- Meetings and iCalendar support
- Proposal pipeline
- Learning/outcome event store
- Workspace JSON export and owner-controlled irreversible deletion
- API keys, idempotency and REST/OpenAPI
- Stripe Checkout, Billing Portal, signed webhook verification and webhook idempotency
- Health/readiness/metrics endpoints
- Audit trail, security headers and rate limiting
- SQLite zero-cost local mode and PostgreSQL production configuration
- Docker Compose baseline and reverse-proxy deployment documentation

## Zero-cost local test
Requirements: Windows, VS Code, Python 3.12+, Chrome/Edge. Ollama, SMTP and Stripe are optional.

```powershell
cd CLIENTHUNT_AI_COMMERCIAL
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:ENVIRONMENT="development"
$env:APP_SECRET="local-test-secret-change-before-production"
$env:RATE_LIMIT_ENABLED="0"
$env:PYTHONPATH="."
python -m pytest -q tests/test_commercial.py
python -m uvicorn app.saas_main:app --host 127.0.0.1 --port 8000 --reload
```

Open `http://127.0.0.1:8000/register`. API docs: `http://127.0.0.1:8000/docs`.

## One-click Windows test
Run `start.bat`, then open the register page.

## Automated verification
The release test suite covers registration/authentication, CSRF, tenant isolation, lead pipeline, outreach approval, suppression, follow-ups, calendar generation, API keys/idempotency, team invitations, Stripe signature/idempotency, public research safety, replies, proposals, meetings, learning, data export, password reset, email verification and owner workspace deletion.

## Production truth
The application can be complete at the software level, but no source ZIP can eliminate infrastructure responsibilities. Before accepting real customers you still must supply a real domain/HTTPS, PostgreSQL, secrets, backups and restore drills, email authentication, monitoring and your legal/compliance process. Those are deployment resources, not missing application features.

## Commercial lead discovery
Only use public business information, approved APIs, user-owned datasets and sources whose terms permit your use. Do not bypass CAPTCHAs, private accounts, access controls or platform restrictions.
