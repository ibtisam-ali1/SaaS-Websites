<?php
declare(strict_types=1);
session_start();

const APP_NAME = 'PostPilot';
const DB_HOST = '127.0.0.1';
const DB_NAME = 'social_media_planner';
const DB_USER = 'root';
const DB_PASS = '';

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $pdo = new PDO(
        'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
    return $pdo;
}
function e(?string $v): string { return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }
function csrf(): string {
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['_csrf'];
}
function verify_csrf(): void {
    if (!hash_equals($_SESSION['_csrf'] ?? '', $_POST['_csrf'] ?? '')) {
        http_response_code(419); exit('Invalid CSRF token.');
    }
}
function flash(string $type, string $msg): void { $_SESSION['_flash'] = [$type, $msg]; }
function get_flash(): ?array { $x = $_SESSION['_flash'] ?? null; unset($_SESSION['_flash']); return $x; }
function redirect(string $url): never { header('Location: '.$url); exit; }
function logged_in(): bool { return isset($_SESSION['user_id']); }
function require_login(): void { if (!logged_in()) redirect('login.php'); }
function current_user(): ?array {
    if (!logged_in()) return null;
    static $u = false;
    if ($u !== false) return $u;
    $s = db()->prepare("SELECT * FROM users WHERE id=?"); $s->execute([$_SESSION['user_id']]);
    return $u = ($s->fetch() ?: null);
}
function setting(string $key, string $default=''): string {
    $s = db()->prepare("SELECT value FROM settings WHERE `key`=? LIMIT 1"); $s->execute([$key]);
    return (string)($s->fetchColumn() ?? $default);
}
function save_setting(string $key, string $value): void {
    db()->prepare("INSERT INTO settings(`key`,`value`) VALUES(?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)")->execute([$key,$value]);
}
function base_url(): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir = rtrim(str_replace('\\','/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return $scheme.'://'.$host.$dir;
}
?>
