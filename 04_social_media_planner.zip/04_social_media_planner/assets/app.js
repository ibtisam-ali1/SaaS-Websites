(() => {
  const root=document.documentElement, saved=localStorage.getItem('theme');
  if(saved) root.dataset.theme=saved;
  const btn=document.querySelector('[data-theme-toggle]');
  if(btn) btn.addEventListener('click',()=>{const n=root.dataset.theme==='dark'?'light':'dark';root.dataset.theme=n;localStorage.setItem('theme',n);});
  document.querySelectorAll('[data-confirm]').forEach(x=>x.addEventListener('click',e=>{if(!confirm(x.dataset.confirm))e.preventDefault()}));
})();
