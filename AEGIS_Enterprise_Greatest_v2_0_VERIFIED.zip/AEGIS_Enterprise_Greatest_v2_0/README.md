# AEGIS Enterprise v2.0 — Greatest Edition

**Autonomous AI Business Operating & Security System**

A local-first, zero-Python-dependency enterprise foundation combining business operations, AI agents, automation, knowledge, security, governance, audit/provenance, analytics and a digital business twin.

## Included
- Command Center dashboard
- Authentication and session tokens
- 9 specialized AI agents
- Agent execution/risk evaluation and approval gates
- AI Copilot with optional local Ollama
- Knowledge ingestion and search
- Tasks and status updates
- CRM-lite: leads and customers
- Projects, invoices, employees and support tickets
- Workflow registry
- Security event center
- AI governance policies
- Human approval queue
- Hash-chained audit/provenance with integrity verification
- Digital Business Twin snapshots and what-if simulation
- Operational analytics
- Notifications API
- Responsive enterprise UI
- SQLite persistence
- Python standard library only
- Automated package and API integration verification

## Windows quick start
```powershell
cd E:\AEGIS_Enterprise_Greatest_v2_0
python --version
python .\scripts\verify.py
python .\tests\test_api.py
python .\run.py
```
Open **http://127.0.0.1:8000**.

Demo credentials: `admin@aegis.local` / `ChangeMe123!`. Change these before any real deployment.

## Optional local AI
Install Ollama separately and make the configured model available. AEGIS falls back safely when Ollama is unavailable.

## Verification
The package must report:
- `PYTHON_COMPILE: PASS`
- `DATABASE_SCHEMA: PASS`
- `SEED_DATA: PASS`
- `AUDIT_CHAIN: PASS`
- `AEGIS_PACKAGE_VERIFICATION: PASS`
- `API_INTEGRATION: PASS`

## Production boundary
No generated software should be treated as penetration-tested, compliant, highly available or production-secure without independent testing. For deployment add TLS, MFA/SSO, secrets management, rate limiting, CSRF protections where applicable, backups, monitoring, isolation, load testing, threat modeling and security review.
