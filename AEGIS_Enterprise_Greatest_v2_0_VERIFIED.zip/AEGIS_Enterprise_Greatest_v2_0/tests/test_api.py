import json,os,subprocess,sys,time,urllib.request,urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
port=18765
p=subprocess.Popen([sys.executable,str(ROOT/'run.py')],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,'AEGIS_PORT':str(port)},text=True)
try:
    for _ in range(30):
        try: urllib.request.urlopen(f'http://127.0.0.1:{port}/api/health',timeout=.2); break
        except Exception: time.sleep(.1)
    def req(path,method='GET',data=None,token=None):
        b=json.dumps(data).encode() if data is not None else None; h={'Content-Type':'application/json'}
        if token:h['Authorization']='Bearer '+token
        r=urllib.request.urlopen(urllib.request.Request(f'http://127.0.0.1:{port}'+path,b,h,method)); return json.loads(r.read())
    h=req('/api/health'); assert h['status']=='ok' and h['audit_chain_valid'] is True
    l=req('/api/auth/login','POST',{'email':'admin@aegis.local','password':'ChangeMe123!'})
    t=l['access_token']; d=req('/api/dashboard',token=t); assert d['agents']==9
    assert len(req('/api/agents',token=t)['items'])==9
    req('/api/tasks','POST',{'title':'Verification task'},t)
    req('/api/documents','POST',{'title':'Policy','content':'AEGIS security policy','tags':'security'},t)
    assert len(req('/api/documents/search?q=security',token=t)['items'])>=1
    req('/api/agents/run','POST',{'agent':'Security','action':'delete production account'},t)
    assert len(req('/api/approvals',token=t)['items'])>=1
    req('/api/twin/simulate','POST',{'revenue_growth':10,'expense_growth':5},t)
    print('API_INTEGRATION: PASS')
finally:
    p.terminate(); p.wait(timeout=5)
