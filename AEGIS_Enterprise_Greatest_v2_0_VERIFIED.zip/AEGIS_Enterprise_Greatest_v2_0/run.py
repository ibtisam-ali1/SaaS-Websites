from aegis.app import main
main()
