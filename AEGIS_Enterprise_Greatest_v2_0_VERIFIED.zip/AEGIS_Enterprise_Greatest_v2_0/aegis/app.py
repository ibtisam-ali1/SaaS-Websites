#!/usr/bin/env python3
import base64, hashlib, hmac, json, os, secrets, sqlite3, time, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
DB=ROOT/'data'/'aegis.db'; STATIC=ROOT/'static'
HOST=os.getenv('AEGIS_HOST','127.0.0.1'); PORT=int(os.getenv('AEGIS_PORT','8000'))
ADMIN_EMAIL=os.getenv('AEGIS_ADMIN_EMAIL','admin@aegis.local'); ADMIN_PASSWORD=os.getenv('AEGIS_ADMIN_PASSWORD','ChangeMe123!')
OLLAMA_URL=os.getenv('OLLAMA_URL','http://127.0.0.1:11434/api/generate'); OLLAMA_MODEL=os.getenv('OLLAMA_MODEL','qwen2.5-coder:1.5b')
VERSION='2.0.0-greatest'
AGENTS=[('CEO','strategy',3),('Sales','revenue',2),('Finance','finance',2),('Customer','support',2),('Project','delivery',2),('HR','people',2),('Security','security',3),('Knowledge','knowledge',3),('Compliance','governance',2)]
SESS={}

def now(): return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def hashpw(p): return hashlib.sha256(p.encode()).hexdigest()
def db():
    DB.parent.mkdir(parents=True,exist_ok=True); c=sqlite3.connect(DB,timeout=10); c.row_factory=sqlite3.Row; return c
def q(sql,args=(),one=False):
    with db() as c:
        cur=c.execute(sql,args); rows=cur.fetchone() if one else cur.fetchall(); c.commit()
        return dict(rows) if one and rows else ([dict(x) for x in rows] if not one else None)
def init():
    with db() as c:
        c.executescript('''
        PRAGMA foreign_keys=ON;
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL,active INTEGER DEFAULT 1,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS agents(id INTEGER PRIMARY KEY,name TEXT UNIQUE NOT NULL,specialty TEXT,autonomy INTEGER,permissions TEXT,active INTEGER DEFAULT 1,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS agent_runs(id INTEGER PRIMARY KEY,agent_id INTEGER,action TEXT,status TEXT,risk TEXT,risk_score INTEGER,result TEXT,created_at TEXT,FOREIGN KEY(agent_id) REFERENCES agents(id));
        CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY,title TEXT NOT NULL,content TEXT NOT NULL,tags TEXT DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY,title TEXT NOT NULL,description TEXT DEFAULT '',priority TEXT DEFAULT 'medium',status TEXT DEFAULT 'open',assignee TEXT DEFAULT '',due_date TEXT DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS workflows(id INTEGER PRIMARY KEY,name TEXT UNIQUE NOT NULL,trigger_name TEXT NOT NULL,condition_json TEXT DEFAULT '{}',action_json TEXT DEFAULT '{}',enabled INTEGER DEFAULT 1,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS security_events(id INTEGER PRIMARY KEY,severity TEXT NOT NULL,category TEXT NOT NULL,message TEXT NOT NULL,resolved INTEGER DEFAULT 0,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS policies(id INTEGER PRIMARY KEY,name TEXT UNIQUE NOT NULL,rule TEXT NOT NULL,enabled INTEGER DEFAULT 1,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS approvals(id INTEGER PRIMARY KEY,agent TEXT NOT NULL,action TEXT NOT NULL,risk TEXT NOT NULL,risk_score INTEGER NOT NULL,status TEXT DEFAULT 'pending',decision_by TEXT DEFAULT '',created_at TEXT NOT NULL,decided_at TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor TEXT,event TEXT,details TEXT,prev_hash TEXT,entry_hash TEXT UNIQUE,created_at TEXT);
        CREATE TABLE IF NOT EXISTS snapshots(id INTEGER PRIMARY KEY,revenue REAL,expenses REAL,customers INTEGER,employees INTEGER,backlog INTEGER,created_at TEXT);
        CREATE TABLE IF NOT EXISTS leads(id INTEGER PRIMARY KEY,name TEXT NOT NULL,company TEXT DEFAULT '',email TEXT DEFAULT '',stage TEXT DEFAULT 'new',value REAL DEFAULT 0,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT DEFAULT '',status TEXT DEFAULT 'active',created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY,name TEXT NOT NULL,status TEXT DEFAULT 'planned',progress INTEGER DEFAULT 0,budget REAL DEFAULT 0,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY,customer TEXT NOT NULL,amount REAL NOT NULL,status TEXT DEFAULT 'unpaid',due_date TEXT DEFAULT '',created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY,name TEXT NOT NULL,department TEXT DEFAULT '',role TEXT DEFAULT '',active INTEGER DEFAULT 1,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY,customer TEXT NOT NULL,subject TEXT NOT NULL,priority TEXT DEFAULT 'medium',status TEXT DEFAULT 'open',created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY,user_email TEXT,message TEXT,kind TEXT DEFAULT 'info',read INTEGER DEFAULT 0,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
        ''')
        if not q('SELECT id FROM users WHERE email=?',(ADMIN_EMAIL,),True): c.execute('INSERT INTO users(email,password_hash,role,created_at) VALUES(?,?,?,?)',(ADMIN_EMAIL,hashpw(ADMIN_PASSWORD),'admin',now()))
        for n,s,a in AGENTS:
            if not q('SELECT id FROM agents WHERE name=?',(n,),True): c.execute('INSERT INTO agents(name,specialty,autonomy,permissions,active,created_at) VALUES(?,?,?,?,?,?)',(n,s,a,json.dumps({'read':True,'write':a>=2,'financial':n=='Finance','destructive':False}),1,now()))
        for name,rule in [('Require approval for financial actions','pay|refund|transfer|invoice'),('Block destructive agent actions','delete|disable|destroy'),('Require approval for publishing','publish|release')]:
            if not q('SELECT id FROM policies WHERE name=?',(name,),True): c.execute('INSERT INTO policies(name,rule,created_at) VALUES(?,?,?)',(name,rule,now()))
        if not q('SELECT id FROM snapshots LIMIT 1'): c.execute('INSERT INTO snapshots(revenue,expenses,customers,employees,backlog,created_at) VALUES(?,?,?,?,?,?)',(100000,60000,120,15,8,now()))
        c.commit()

def audit(actor,event,details):
    prev=q('SELECT entry_hash FROM audit ORDER BY id DESC LIMIT 1',one=True); prev=prev['entry_hash'] if prev else 'GENESIS'; ts=now(); raw=f'{prev}|{actor}|{event}|{details}|{ts}'; h=hashlib.sha256(raw.encode()).hexdigest(); q('INSERT INTO audit(actor,event,details,prev_hash,entry_hash,created_at) VALUES(?,?,?,?,?,?)',(actor,event,str(details)[:2000],prev,h,ts))
def audit_verify():
    rows=q('SELECT * FROM audit ORDER BY id'); prev='GENESIS'
    for r in rows:
        raw=f"{prev}|{r['actor']}|{r['event']}|{r['details']}|{r['created_at']}"; expected=hashlib.sha256(raw.encode()).hexdigest()
        if expected!=r['entry_hash'] or r['prev_hash']!=prev: return False
        prev=r['entry_hash']
    return True

def token(email): return base64.urlsafe_b64encode(f'{email}:{secrets.token_urlsafe(32)}'.encode()).decode()
def auth(h):
    t=h.headers.get('Authorization','').replace('Bearer ','',1); return SESS.get(t)
def risk(action,autonomy=2):
    a=action.lower(); destructive=any(x in a for x in ('delete','destroy','disable','erase')); financial=any(x in a for x in ('pay','refund','invoice','transfer','charge')); publish=any(x in a for x in ('publish','release'))
    score=15+autonomy*10+(55 if destructive else 0)+(35 if financial else 0)+(25 if publish else 0); score=min(score,100)
    return ('critical' if score>=90 else 'high' if score>=70 else 'medium' if score>=40 else 'low'),score

def copilot(prompt):
    system='You are AEGIS, an enterprise business operations copilot. Give concise, actionable, safe recommendations. Never claim an action was executed unless the API confirms it.'
    payload=json.dumps({'model':OLLAMA_MODEL,'prompt':system+'\n\nUser: '+prompt,'stream':False}).encode()
    try:
        req=urllib.request.Request(OLLAMA_URL,payload,{'Content-Type':'application/json'}); data=json.loads(urllib.request.urlopen(req,timeout=10).read()); return data.get('response','').strip() or 'No model response.'
    except Exception:
        return 'Local AEGIS fallback: Ollama is unavailable. I can still use AEGIS business records, policies and deterministic analytics.'

def twin(s,g):
    rev=s['revenue']*(1+float(g.get('revenue_growth',0))/100); exp=s['expenses']*(1+float(g.get('expense_growth',0))/100); cust=round(s['customers']*(1+float(g.get('customer_growth',0))/100)); emp=s['employees']+int(g.get('employee_change',0)); profit=rev-exp
    return {'revenue':round(rev,2),'expenses':round(exp,2),'profit':round(profit,2),'customers':cust,'employees':emp,'margin_pct':round(profit/rev*100,2) if rev else 0}

def jsonout(h,obj,status=200):
    b=json.dumps(obj,ensure_ascii=False).encode(); h.send_response(status); h.send_header('Content-Type','application/json; charset=utf-8'); h.send_header('Cache-Control','no-store'); h.send_header('Content-Length',str(len(b))); h.end_headers(); h.wfile.write(b)
def body(h):
    try: n=int(h.headers.get('Content-Length','0')); return json.loads(h.rfile.read(n) or b'{}')
    except Exception: return {}
def rows_count(table,where='1=1'): return q(f'SELECT COUNT(*) n FROM {table} WHERE {where}',one=True)['n']

class H(BaseHTTPRequestHandler):
    server_version='AEGIS/2.0'
    def log_message(self,*a): pass
    def send_file(self,name):
        safe=(STATIC/name).resolve()
        if STATIC not in safe.parents: return jsonout(self,{'error':'invalid path'},400)
        if not safe.exists(): return jsonout(self,{'error':'not found'},404)
        ext=safe.suffix; ct={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.json':'application/json'} .get(ext,'application/octet-stream'); b=safe.read_bytes(); self.send_response(200); self.send_header('Content-Type',ct); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def get(self,path,qs,u):
        if path=='/api/health': return jsonout(self,{'status':'ok','version':VERSION,'time':now(),'audit_chain_valid':audit_verify()})
        if not u: return jsonout(self,{'error':'authentication required'},401)
        if path=='/api/dashboard':
            alerts=rows_count('security_events','resolved=0'); s=q('SELECT * FROM snapshots ORDER BY id DESC LIMIT 1',one=True); agents=q('SELECT * FROM agents WHERE active=1'); tasks=rows_count('tasks'); leads=rows_count('leads'); tickets=rows_count('tickets','status != "closed"');
            return jsonout(self,{'health':max(0,100-alerts*8),'agents':len(agents),'tasks':tasks,'documents':rows_count('documents'),'security_alerts':alerts,'leads':leads,'open_tickets':tickets,'snapshot':s,'timestamp':now()})
        routes={
            '/api/agents':('SELECT * FROM agents ORDER BY name',), '/api/agent-runs':('SELECT * FROM agent_runs ORDER BY id DESC LIMIT 100',),
            '/api/documents':('SELECT id,title,tags,created_at,updated_at FROM documents ORDER BY id DESC',), '/api/tasks':('SELECT * FROM tasks ORDER BY id DESC',),
            '/api/workflows':('SELECT * FROM workflows ORDER BY id DESC',), '/api/security/events':('SELECT * FROM security_events ORDER BY id DESC LIMIT 200',),
            '/api/policies':('SELECT * FROM policies ORDER BY id',), '/api/approvals':('SELECT * FROM approvals ORDER BY id DESC',), '/api/audit':('SELECT * FROM audit ORDER BY id DESC LIMIT 500',),
            '/api/leads':('SELECT * FROM leads ORDER BY id DESC',), '/api/customers':('SELECT * FROM customers ORDER BY id DESC',), '/api/projects':('SELECT * FROM projects ORDER BY id DESC',),
            '/api/invoices':('SELECT * FROM invoices ORDER BY id DESC',), '/api/employees':('SELECT * FROM employees ORDER BY id DESC',), '/api/tickets':('SELECT * FROM tickets ORDER BY id DESC',),
            '/api/notifications':('SELECT * FROM notifications WHERE user_email=? ORDER BY id DESC LIMIT 100',),
        }
        if path in routes:
            sql=routes[path][0]; args=(u,) if path=='/api/notifications' else (); return jsonout(self,{'items':q(sql,args)})
        if path=='/api/documents/search':
            term=parse_qs(qs).get('q',[''])[0].strip().lower(); return jsonout(self,{'items':[x for x in q('SELECT * FROM documents ORDER BY id DESC') if term in (x['title']+' '+x['content']+' '+x['tags']).lower()]})
        if path=='/api/twin/snapshot': return jsonout(self,{'items':q('SELECT * FROM snapshots ORDER BY id DESC')})
        if path=='/api/analytics':
            return jsonout(self,{'sales_pipeline':q('SELECT COALESCE(SUM(value),0) value,stage FROM leads GROUP BY stage'),'invoice_status':q('SELECT COALESCE(SUM(amount),0) amount,status FROM invoices GROUP BY status'),'task_status':q('SELECT COUNT(*) count,status FROM tasks GROUP BY status'),'ticket_status':q('SELECT COUNT(*) count,status FROM tickets GROUP BY status')})
        return jsonout(self,{'error':'not found'},404)
    def do_GET(self):
        p=urlparse(self.path); path=p.path
        if path=='/': return self.send_file('index.html')
        if path.startswith('/static/'): return self.send_file(path[8:])
        return self.get(path,p.query,auth(self))
    def post(self,path,d,u):
        if path=='/api/auth/login':
            if hmac.compare_digest(str(d.get('email','')),ADMIN_EMAIL) and hmac.compare_digest(str(d.get('password','')),ADMIN_PASSWORD):
                t=token(ADMIN_EMAIL); SESS[t]=ADMIN_EMAIL; audit(ADMIN_EMAIL,'auth.login','successful'); return jsonout(self,{'access_token':t,'user':{'email':ADMIN_EMAIL,'role':'admin'}})
            return jsonout(self,{'error':'invalid credentials'},401)
        if not u:return jsonout(self,{'error':'authentication required'},401)
        if path=='/api/copilot':
            p=str(d.get('prompt','')).strip()
            if not p:return jsonout(self,{'error':'prompt required'},400)
            answer=copilot(p); audit(u,'copilot.query',p[:500]); return jsonout(self,{'answer':answer,'model':OLLAMA_MODEL,'local':answer.startswith('Local AEGIS')})
        simple={
            '/api/documents':('documents',['title','content','tags']), '/api/tasks':('tasks',['title','description','priority','status','assignee','due_date']),
            '/api/leads':('leads',['name','company','email','stage','value']), '/api/customers':('customers',['name','email','status']),
            '/api/projects':('projects',['name','status','progress','budget']), '/api/invoices':('invoices',['customer','amount','status','due_date']),
            '/api/employees':('employees',['name','department','role']), '/api/tickets':('tickets',['customer','subject','priority','status']),
        }
        if path in simple:
            table,fields=simple[path]; vals=[d.get(k,'') for k in fields]; cols=','.join(fields); marks=','.join('?' for _ in fields); ts=now(); extra=[]
            if table in ('documents','tasks'): cols+=',created_at,updated_at'; marks+=',?,?'; vals += [ts,ts]
            else: cols+=',created_at'; marks+=',?'; vals += [ts]
            q(f'INSERT INTO {table}({cols}) VALUES({marks})',vals); audit(u,table+'.create',json.dumps(d)); return jsonout(self,{'status':'created'})
        if path=='/api/workflows':
            q('INSERT INTO workflows(name,trigger_name,condition_json,action_json,created_at) VALUES(?,?,?,?,?)',(d.get('name','Workflow'),d.get('trigger_name','manual'),json.dumps(d.get('condition',{})),json.dumps(d.get('action',{})),now())); audit(u,'workflow.create',d.get('name','Workflow')); return jsonout(self,{'status':'created'})
        if path=='/api/security/events':
            q('INSERT INTO security_events(severity,category,message,created_at) VALUES(?,?,?,?)',(d.get('severity','medium'),d.get('category','anomaly'),d.get('message',''),now())); audit(u,'security.event',d.get('message','')); return jsonout(self,{'status':'created'})
        if path=='/api/agents/evaluate':
            a=q('SELECT * FROM agents WHERE name=?',(d.get('agent','CEO'),),one=True); r=risk(d.get('action','read'),a['autonomy'] if a else 2); return jsonout(self,{'risk':r[0],'score':r[1],'requires_approval':r[1]>=70})
        if path=='/api/agents/run':
            a=q('SELECT * FROM agents WHERE name=?',(d.get('agent','CEO'),),one=True)
            if not a:return jsonout(self,{'error':'agent not found'},404)
            action=d.get('action','analyze business'); r=risk(action,a['autonomy']); status='approval_required' if r[1]>=70 else 'completed'; result='Action evaluated by AEGIS policy engine.'
            q('INSERT INTO agent_runs(agent_id,action,status,risk,risk_score,result,created_at) VALUES(?,?,?,?,?,?,?)',(a['id'],action,status,r[0],r[1],result,now()));
            if status=='approval_required': q('INSERT INTO approvals(agent,action,risk,risk_score,created_at) VALUES(?,?,?,?,?)',(a['name'],action,r[0],r[1],now()))
            audit(u,'agent.run',f'{a["name"]}: {action}'); return jsonout(self,{'status':status,'risk':r[0],'score':r[1],'result':result})
        if path=='/api/approvals':
            r=risk(d.get('action',''),2); q('INSERT INTO approvals(agent,action,risk,risk_score,created_at) VALUES(?,?,?,?,?)',(d.get('agent','Unknown'),d.get('action',''),r[0],r[1],now())); audit(u,'approval.request',d.get('action','')); return jsonout(self,{'status':'pending','risk':r[0],'score':r[1]})
        if path=='/api/twin/snapshot':
            q('INSERT INTO snapshots(revenue,expenses,customers,employees,backlog,created_at) VALUES(?,?,?,?,?,?)',(float(d.get('revenue',0)),float(d.get('expenses',0)),int(d.get('customers',0)),int(d.get('employees',0)),int(d.get('backlog',0)),now())); audit(u,'twin.snapshot','created'); return jsonout(self,{'status':'created'})
        if path=='/api/twin/simulate':
            s=q('SELECT * FROM snapshots ORDER BY id DESC LIMIT 1',one=True)
            if not s:return jsonout(self,{'error':'create snapshot first'},400)
            return jsonout(self,{'result':twin(s,d)})
        if path=='/api/notifications':
            q('INSERT INTO notifications(user_email,message,kind,created_at) VALUES(?,?,?,?)',(u,d.get('message',''),d.get('kind','info'),now())); return jsonout(self,{'status':'created'})
        return jsonout(self,{'error':'not found'},404)
    def do_POST(self): return self.post(urlparse(self.path).path,body(self),auth(self))
    def do_PATCH(self):
        p=urlparse(self.path); u=auth(self)
        if not u:return jsonout(self,{'error':'authentication required'},401)
        d=body(self)
        if p.path.startswith('/api/tasks/'):
            tid=p.path.rsplit('/',1)[-1]; allowed={k:d[k] for k in ('status','priority','assignee','due_date') if k in d}
            if not allowed:return jsonout(self,{'error':'no supported fields'},400)
            sets=','.join(k+'=?' for k in allowed); q(f'UPDATE tasks SET {sets},updated_at=? WHERE id=?',list(allowed.values())+[now(),tid]); audit(u,'task.update',tid); return jsonout(self,{'status':'updated'})
        return jsonout(self,{'error':'not found'},404)

def main():
    init(); print(f'AEGIS Enterprise {VERSION} running at http://{HOST}:{PORT}'); ThreadingHTTPServer((HOST,PORT),H).serve_forever()
if __name__=='__main__': main()
