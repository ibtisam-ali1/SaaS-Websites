import ast,sqlite3,sys,tempfile,os,zipfile,urllib.request,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def ok(name,cond):
    print(f'{name}: '+('PASS' if cond else 'FAIL'))
    if not cond: raise SystemExit(1)

for p in ROOT.rglob('*.py'): ast.parse(p.read_text(encoding='utf-8'))
ok('PYTHON_COMPILE',True)
# isolated schema test by importing with temp DB
import importlib.util
spec=importlib.util.spec_from_file_location('aegis_app',ROOT/'aegis'/'app.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
old=m.DB
with tempfile.TemporaryDirectory() as td:
    m.DB=Path(td)/'test.db'; m.init()
    with sqlite3.connect(m.DB) as c:
        tables={r[0] for r in c.execute("select name from sqlite_master where type='table'")}
    expected={'users','agents','agent_runs','documents','tasks','workflows','security_events','policies','approvals','audit','snapshots','leads','customers','projects','invoices','employees','tickets','notifications','settings'}
    ok('DATABASE_SCHEMA',expected.issubset(tables))
    ok('SEED_DATA',len(m.q('select * from agents'))==9 and len(m.q('select * from policies'))>=3)
    m.audit('verify','test','chain'); ok('AUDIT_CHAIN',m.audit_verify())
for f in ['static/index.html','static/app.css','static/app.js','README.md']:
    ok('ASSET_'+f.replace('/','_'),(ROOT/f).exists() and (ROOT/f).stat().st_size>100)
print('AEGIS_PACKAGE_VERIFICATION: PASS')
