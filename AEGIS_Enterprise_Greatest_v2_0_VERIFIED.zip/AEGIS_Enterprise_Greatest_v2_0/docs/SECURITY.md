# Security Boundary

The project includes authentication, constant-time credential comparison, scoped agent metadata, policy/risk evaluation, approval gates, audit hash chaining and security-event intake.

Before internet exposure: change credentials, use TLS behind a hardened reverse proxy, move secrets out of environment files, add MFA/SSO, CSRF protection where browser cookies are used, rate limiting, secure session storage, backups, OS hardening, dependency scanning, penetration testing, threat modeling and independent review.

This package is a serious development baseline, not a certification of production security.
