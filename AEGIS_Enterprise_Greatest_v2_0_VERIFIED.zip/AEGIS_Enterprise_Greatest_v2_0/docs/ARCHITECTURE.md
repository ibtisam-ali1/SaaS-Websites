# AEGIS Enterprise v2.0 — Architecture

AEGIS is a local-first business control plane. The core uses Python's standard library and SQLite, with an optional Ollama adapter for local AI.

## Layers
- Presentation: responsive single-page dashboard in `static/`.
- API: HTTP JSON endpoints in `aegis/app.py`.
- Domain controls: agent registry, risk scoring, policy gates, approvals and workflows.
- Persistence: SQLite with explicit tables for business, AI, security and governance records.
- AI adapter: Ollama over localhost with deterministic fallback.
- Evidence: hash-chained audit records and verification routine.

## Enterprise evolution path
The interfaces are intentionally modular so PostgreSQL, external identity, vector databases, queues, observability, SSO/MFA, secrets managers and container isolation can be introduced without changing the product model.
