# 02 Freelancer Invoicing

## Stack
PHP 8.2+ · MySQL/MariaDB · Apache/XAMPP · Vanilla JavaScript · CSS

## XAMPP setup
1. Copy this folder to `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** in XAMPP.
3. Open phpMyAdmin and import `database.sql`.
4. Open the app at `http://localhost/02_freelancer_invoicing/`.
5. Register a local account.

## Security baseline
- PDO prepared statements
- Password hashing with `password_hash`
- CSRF protection for authenticated forms
- Session regeneration after login
- Output escaping with `htmlspecialchars`
- Server-side ownership checks
- API input validation
- No frontend secrets for AI calls

## Performance
The UI uses plain CSS/JS, no framework, no external CDN, and no runtime dependency manager. Animations are GPU-friendly and lightweight.

## Production hardening
Before public deployment, enable HTTPS, set secure session cookies, move secrets to environment variables outside the web root, disable PHP error display, add rate limiting/WAF, configure backups, email verification and monitoring.
