import { Service, StaffMember, Appointment, Conversation, Lead, BusinessConfig } from '../types';

export const initialBusinessConfig: BusinessConfig = {
  name: 'Apex Health & Wellness Clinic',
  industry: 'Medical & Healthcare',
  phone: '+1 (555) 234-8900',
  email: 'care@apexhealthclinic.com',
  address: '742 Evergreen Terrace, Suite 300, San Francisco, CA',
  timezone: 'America/Los_Angeles (PST)',
  aiName: 'Aria (ReceptionAI)',
  aiTone: 'Empathetic & Warm',
  aiVoice: 'Aria (Warm American Female)',
  welcomeMessage: 'Hello and welcome to Apex Health Clinic! I am Aria, your 24/7 AI virtual receptionist. How may I assist you with scheduling, service inquiries, or clinical questions today?',
  bufferMinutes: 15,
  noticeHours: 2,
  autoConfirm: true,
  smsNotifications: true,
  emailNotifications: true,
  escalationPhone: '+1 (555) 899-4422',
  escalationThreshold: 'immediate',
  systemPrompt: 'You are Aria, an empathetic, highly knowledgeable medical front desk virtual receptionist for Apex Health Clinic. Greet callers warmly, explain clinic procedures accurately, pre-screen symptoms safely without giving unprescribed medical diagnoses, and schedule appointments with attending physicians.',
  bookingBufferMinutes: 15,
  maxAdvanceBookingDays: 30,
  smsNotificationsEnabled: true,
  emailNotificationsEnabled: true,
  workingHours: [
    { day: 'Monday', isOpen: true, openTime: '08:00 AM', closeTime: '06:00 PM' },
    { day: 'Tuesday', isOpen: true, openTime: '08:00 AM', closeTime: '06:00 PM' },
    { day: 'Wednesday', isOpen: true, openTime: '08:00 AM', closeTime: '06:00 PM' },
    { day: 'Thursday', isOpen: true, openTime: '08:00 AM', closeTime: '06:00 PM' },
    { day: 'Friday', isOpen: true, openTime: '08:00 AM', closeTime: '05:00 PM' },
    { day: 'Saturday', isOpen: true, openTime: '09:00 AM', closeTime: '02:00 PM' },
    { day: 'Sunday', isOpen: false, openTime: 'Closed', closeTime: 'Closed' }
  ],
  customKnowledge: [
    {
      id: 'k-1',
      question: 'Do you offer student or senior discounts?',
      answer: 'Yes! Apex Health Clinic provides a 10% courtesy discount for full-time enrolled students (with valid student ID) and seniors aged 65+ on all self-pay outpatient consultations and preventive wellness packages.',
      category: 'Pricing & Discounts'
    },
    {
      id: 'k-2',
      question: 'What is your parking policy?',
      answer: 'We provide 2 hours of complimentary validated parking at the Sutter Square Garage located directly behind our building (entrance on Pine St). Simply bring your garage ticket to our front desk for physical or digital validation.',
      category: 'Location & Parking'
    },
    {
      id: 'k-3',
      question: 'Can I bring my service animal or pet?',
      answer: 'Certified service animals trained to perform tasks for individuals with disabilities under the ADA are warmly welcomed throughout our medical clinic. Emotional support pets are asked to remain in the designated lobby waiting lounge.',
      category: 'Clinic Policies'
    },
    {
      id: 'k-4',
      question: 'Do your doctors speak Spanish or other languages?',
      answer: 'Yes, Dr. Elena Rostova is fluent in Spanish, and Dr. David Kim is fluent in Korean. We also offer on-demand certified medical interpretation in 40+ languages via our HIPAA-compliant video translation service.',
      category: 'Language Support'
    }
  ]
};

export const mockServices: Service[] = [
  {
    id: 'srv-1',
    name: 'Comprehensive Health Consultation',
    category: 'General Care',
    durationMinutes: 45,
    price: 180,
    description: 'Thorough wellness evaluation, vitals check, medical history review, and personalized care plan.',
    popular: true,
  },
  {
    id: 'srv-2',
    name: 'Teeth Whitening & Oral Exam',
    category: 'Dental',
    durationMinutes: 60,
    price: 240,
    description: 'Advanced LED in-office whitening treatment with comprehensive plaque analysis and digital scan.',
    popular: true,
  },
  {
    id: 'srv-3',
    name: 'Physiotherapy & Rehab Assessment',
    category: 'Physical Therapy',
    durationMinutes: 50,
    price: 160,
    description: 'Targeted mobility screening, musculoskeletal diagnostic test, and recovery exercises.',
  },
  {
    id: 'srv-4',
    name: 'Executive Bloodwork & Lab Screening',
    category: 'Diagnostic',
    durationMinutes: 30,
    price: 210,
    description: 'Fast fasting lipid panel, comprehensive metabolic profile, vitamin levels, and hormone assay.',
  },
  {
    id: 'srv-5',
    name: 'Virtual Telehealth Follow-up',
    category: 'Telehealth',
    durationMinutes: 25,
    price: 95,
    description: 'HD video consultation with your attending physician for prescription reviews and lab results.',
    popular: true,
  },
  {
    id: 'srv-6',
    name: 'Acupuncture & Pain Relief Session',
    category: 'Holistic',
    durationMinutes: 60,
    price: 145,
    description: 'Therapeutic meridian needle stimulation for chronic joint pain, migraines, and stress release.',
  }
];

export const mockStaff: StaffMember[] = [
  {
    id: 'st-1',
    name: 'Dr. Sarah Lin, MD',
    role: 'Lead Primary Physician',
    avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300',
    specialties: ['Preventative Medicine', 'Cardiology', 'Wellness'],
    rating: 4.96,
    availableDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
  },
  {
    id: 'st-2',
    name: 'Dr. Marcus Vance, DDS',
    role: 'Cosmetic Dental Specialist',
    avatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=300',
    specialties: ['Cosmetic Dentistry', 'Whitening', 'Aligners'],
    rating: 4.92,
    availableDays: ['Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
  },
  {
    id: 'st-3',
    name: 'Elena Rostova, DPT',
    role: 'Senior Physiotherapist',
    avatar: 'https://images.unsplash.com/photo-1594824813515-77636e053f3e?auto=format&fit=crop&q=80&w=300',
    specialties: ['Sports Rehab', 'Spinal Alignment', 'Post-Op Recovery'],
    rating: 4.98,
    availableDays: ['Monday', 'Wednesday', 'Thursday', 'Saturday'],
  },
  {
    id: 'st-4',
    name: 'Dr. James Chen, MD',
    role: 'Diagnostic & Internal Medicine',
    avatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=300',
    specialties: ['Lab Diagnostics', 'Endocrinology', 'Chronic Care'],
    rating: 4.89,
    availableDays: ['Monday', 'Tuesday', 'Wednesday', 'Friday'],
  }
];

export const mockAppointments: Appointment[] = [
  {
    id: 'apt-101',
    serviceId: 'srv-1',
    serviceName: 'Comprehensive Health Consultation',
    staffId: 'st-1',
    staffName: 'Dr. Sarah Lin, MD',
    customerName: 'Victoria Sterling',
    customerEmail: 'v.sterling@vanguardtech.io',
    customerPhone: '+1 (415) 555-0192',
    notes: 'Annual executive physical, requested lipid panel follow-up.',
    date: '2026-09-18',
    time: '10:00 AM',
    status: 'confirmed',
    price: 180,
    createdAt: '2026-09-16'
  },
  {
    id: 'apt-102',
    serviceId: 'srv-2',
    serviceName: 'Teeth Whitening & Oral Exam',
    staffId: 'st-2',
    staffName: 'Dr. Marcus Vance, DDS',
    customerName: 'Ethan Reynolds',
    customerEmail: 'reynolds.e@summitcapital.com',
    customerPhone: '+1 (415) 555-8831',
    notes: 'Pre-wedding whitening session, sensitive enamel.',
    date: '2026-09-18',
    time: '02:30 PM',
    status: 'confirmed',
    price: 240,
    createdAt: '2026-09-15'
  },
  {
    id: 'apt-103',
    serviceId: 'srv-3',
    serviceName: 'Physiotherapy & Rehab Assessment',
    staffId: 'st-3',
    staffName: 'Elena Rostova, DPT',
    customerName: 'Chloe Henderson',
    customerEmail: 'chloe.h@designforge.co',
    customerPhone: '+1 (510) 555-4419',
    notes: 'Runner with acute left knee inflammation after marathon.',
    date: '2026-09-19',
    time: '11:15 AM',
    status: 'pending',
    price: 160,
    createdAt: '2026-09-17'
  },
  {
    id: 'apt-104',
    serviceId: 'srv-5',
    serviceName: 'Virtual Telehealth Follow-up',
    staffId: 'st-1',
    staffName: 'Dr. Sarah Lin, MD',
    customerName: 'Arthur Pendelton',
    customerEmail: 'arthur.p@meridian.org',
    customerPhone: '+1 (408) 555-7720',
    notes: 'Review bloodwork from Aug 29th and refill allergy medication.',
    date: '2026-09-20',
    time: '09:30 AM',
    status: 'confirmed',
    price: 95,
    createdAt: '2026-09-14'
  },
  {
    id: 'apt-105',
    serviceId: 'srv-4',
    serviceName: 'Executive Bloodwork & Lab Screening',
    staffId: 'st-4',
    staffName: 'Dr. James Chen, MD',
    customerName: 'Danielle Brooks',
    customerEmail: 'dbrooks@acceleratepartners.com',
    customerPhone: '+1 (650) 555-3211',
    notes: 'Requires 12h fasting beforehand; sent instructions via SMS.',
    date: '2026-09-21',
    time: '08:15 AM',
    status: 'confirmed',
    price: 210,
    createdAt: '2026-09-16'
  }
];

export const mockConversations: Conversation[] = [
  {
    id: 'conv-1',
    customerName: 'Rachel Green',
    customerPhone: '+1 (415) 890-2341',
    customerEmail: 'rachel.green@fashionhouse.com',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    channel: 'web',
    status: 'appointment_booked',
    isAiHandled: true,
    lastMessage: 'Your appointment is booked for Friday, Sept 18 at 10:00 AM. A confirmation text was sent!',
    lastMessageTime: '12m ago',
    unread: false,
    tags: ['New Patient', 'Consultation', 'High Intent'],
    internalNotes: ['Patient requested Dr. Sarah Lin specifically.', 'Insurance: BlueShield PPO verified.'],
    leadScore: 96,
    estimatedValue: 180,
    messages: [
      {
        id: 'm1',
        sender: 'ai',
        text: 'Hello and welcome to Apex Health Clinic! I am Aria, your 24/7 AI virtual receptionist. How may I assist you today?',
        timestamp: '10:24 AM'
      },
      {
        id: 'm2',
        sender: 'user',
        text: 'Hi! Do you have any open slots this Friday morning for a general health checkup with Dr. Lin?',
        timestamp: '10:25 AM'
      },
      {
        id: 'm3',
        sender: 'ai',
        text: 'Yes! Dr. Sarah Lin has availability this Friday at 10:00 AM and 11:30 AM. Would you like me to reserve the 10:00 AM slot for you?',
        timestamp: '10:25 AM'
      },
      {
        id: 'm4',
        sender: 'user',
        text: '10:00 AM works great. Can you book that for Rachel Green?',
        timestamp: '10:26 AM'
      },
      {
        id: 'm5',
        sender: 'ai',
        text: 'Your appointment is booked for Friday, Sept 18 at 10:00 AM with Dr. Sarah Lin. A confirmation text and calendar invite were sent to your mobile phone (+1 415-890-2341)!',
        timestamp: '10:27 AM',
        type: 'confirmation_card'
      }
    ]
  },
  {
    id: 'conv-2',
    customerName: 'Marcus Cole',
    customerPhone: '+1 (510) 412-9901',
    customerEmail: 'mcole@greentech.org',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    channel: 'phone',
    status: 'escalated',
    isAiHandled: false,
    lastMessage: 'Customer requested human billing department regarding prior authorization claim.',
    lastMessageTime: '34m ago',
    unread: true,
    tags: ['Billing Inquiry', 'Prior Auth', 'Human Needed'],
    internalNotes: ['Transferred call from Voice AI receptionist to front desk billing desk.', 'Claim #8921-AZ pending.'],
    leadScore: 68,
    estimatedValue: 420,
    messages: [
      {
        id: 'm201',
        sender: 'ai',
        text: 'Thank you for calling Apex Health. I can assist with appointments, clinic hours, or triage your request. What can I do for you?',
        timestamp: '9:45 AM'
      },
      {
        id: 'm202',
        sender: 'user',
        text: 'I received an explanation of benefits letter from Aetna stating prior authorization was needed for my MRI last Tuesday.',
        timestamp: '9:46 AM'
      },
      {
        id: 'm203',
        sender: 'ai',
        text: 'I understand how frustrating prior authorization delays can be. Our clinical billing team handles Aetna claims directly. Would you like me to connect you to our billing coordinator, Jessica?',
        timestamp: '9:46 AM'
      },
      {
        id: 'm204',
        sender: 'user',
        text: 'Yes please, transfer me to someone who can verify the auth code.',
        timestamp: '9:47 AM'
      },
      {
        id: 'm205',
        sender: 'system',
        text: 'Call transferred to Internal Queue: Front Desk Billing (Jessica R.). AI Warm Handoff completed.',
        timestamp: '9:48 AM'
      }
    ]
  },
  {
    id: 'conv-3',
    customerName: 'Sophia Montgomery',
    customerPhone: '+1 (650) 843-1200',
    customerEmail: 'sophia.m@montgomerylaw.com',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200',
    channel: 'sms',
    status: 'active',
    isAiHandled: true,
    lastMessage: 'Are teeth whitening treatments covered under HSA or FSA debit cards?',
    lastMessageTime: '1h ago',
    unread: false,
    tags: ['Dental Inquiry', 'FSA / HSA', 'Price Check'],
    internalNotes: ['Provided standard IRS publication 502 answer: Cosmetic treatments usually excluded unless medically necessary.'],
    leadScore: 84,
    estimatedValue: 240,
    messages: [
      {
        id: 'm301',
        sender: 'user',
        text: 'Hi, does your clinic accept HSA cards for cosmetic teeth whitening?',
        timestamp: '8:50 AM'
      },
      {
        id: 'm302',
        sender: 'ai',
        text: 'Hi Sophia! While cosmetic teeth whitening is generally excluded by IRS guidelines for HSA/FSA funds, our oral exam and plaque analysis components ($95 value) often qualify with itemized receipts. We accept all major cards and can provide an itemized superbill for your administrator.',
        timestamp: '8:51 AM'
      },
      {
        id: 'm303',
        sender: 'user',
        text: 'That is super helpful! How long does the in-office treatment take?',
        timestamp: '8:52 AM'
      },
      {
        id: 'm304',
        sender: 'ai',
        text: 'The full whitening and exam takes approximately 60 minutes with Dr. Marcus Vance. Would you like to view his available times for next week?',
        timestamp: '8:53 AM'
      }
    ]
  },
  {
    id: 'conv-4',
    customerName: 'David K. Liu',
    customerPhone: '+1 (415) 332-9011',
    customerEmail: 'dliu@bayinvest.com',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
    channel: 'whatsapp',
    status: 'resolved',
    isAiHandled: true,
    lastMessage: 'Sent clinic parking directions and garage validation code #774.',
    lastMessageTime: '3h ago',
    unread: false,
    tags: ['Directions', 'Parking', 'Completed'],
    internalNotes: ['Validated 2h visitor pass for Sutter Garage.'],
    leadScore: 72,
    estimatedValue: 160,
    messages: [
      {
        id: 'm401',
        sender: 'user',
        text: 'Hi, where should I park for my 2pm rehab session today?',
        timestamp: '6:30 AM'
      },
      {
        id: 'm402',
        sender: 'ai',
        text: 'Good morning David! We offer complimentary 2-hour validated parking at the Sutter Square Garage located directly behind our building at 742 Evergreen Terrace. Just show code #774 to the parking attendant upon exit!',
        timestamp: '6:31 AM'
      },
      {
        id: 'm403',
        sender: 'user',
        text: 'Awesome, see you at 2pm!',
        timestamp: '6:32 AM'
      }
    ]
  }
];

export const mockLeads: Lead[] = [
  {
    id: 'ld-1',
    name: 'Victoria Sterling',
    company: 'Vanguard Tech Partners',
    email: 'v.sterling@vanguardtech.io',
    phone: '+1 (415) 555-0192',
    source: 'AI Web Chat',
    status: 'Meeting Scheduled',
    date: '2026-09-17',
    estimatedValue: 1250,
    intent: 'High',
    interestService: 'Corporate Wellness & Executive Health',
    notes: 'Inquiring for corporate wellness packages for 45 employees.',
    conversationsCount: 4
  },
  {
    id: 'ld-2',
    name: 'Ethan Reynolds',
    company: 'Summit Capital Partners',
    email: 'reynolds.e@summitcapital.com',
    phone: '+1 (415) 555-8831',
    source: 'AI Phone Call',
    status: 'Qualified',
    date: '2026-09-16',
    estimatedValue: 480,
    intent: 'High',
    interestService: 'Cosmetic Dentistry & Alignment',
    notes: 'Ready to book follow-up series; needs invoice sent to corporate card.',
    conversationsCount: 2
  },
  {
    id: 'ld-3',
    name: 'Chloe Henderson',
    company: 'Design Forge Studio',
    email: 'chloe.h@designforge.co',
    phone: '+1 (510) 555-4419',
    source: 'Inbound SMS',
    status: 'Meeting Scheduled',
    date: '2026-09-16',
    estimatedValue: 320,
    intent: 'High',
    interestService: 'Physical Therapy & Sports Recovery',
    notes: 'Referred by Dr. Lin; needs ongoing twice-weekly rehab sessions.',
    conversationsCount: 3
  },
  {
    id: 'ld-4',
    name: 'Samuel Vance, Esq.',
    company: 'Vance Legal Advisory',
    email: 'svance@vancelaw.com',
    phone: '+1 (415) 771-4490',
    source: 'AI Web Chat',
    status: 'New',
    date: '2026-09-17',
    estimatedValue: 2400,
    intent: 'High',
    interestService: 'Expert Medical Witness Consultation',
    notes: 'Needs certified physician review for pending personal injury deposition.',
    conversationsCount: 1
  },
  {
    id: 'ld-5',
    name: 'Mariana Gomez',
    company: 'Pacific Heights Properties',
    email: 'mgomez@pacifichomes.com',
    phone: '+1 (415) 902-8812',
    source: 'WhatsApp',
    status: 'Follow Up',
    date: '2026-09-15',
    estimatedValue: 650,
    intent: 'Medium',
    interestService: 'Allergy & Environmental Screening',
    notes: 'Requested brochure on air quality and mold sensitivity testing.',
    conversationsCount: 2
  },
  {
    id: 'ld-6',
    name: 'Julian Thorne',
    company: 'Apex Bio Labs',
    email: 'jthorne@apexbiolabs.com',
    phone: '+1 (650) 338-9901',
    source: 'AI Phone Call',
    status: 'Won',
    date: '2026-09-14',
    estimatedValue: 1800,
    intent: 'High',
    interestService: 'Annual Executive Health Screening',
    notes: 'Completed contract sign-up and scheduled initial 5 team members.',
    conversationsCount: 5
  }
];

export const mockIndustrySolutions = [
  {
    id: 'clinics',
    name: 'Clinics & Healthcare',
    badge: 'HIPAA-Ready Virtual Reception',
    headline: 'Zero Missed Patients. 24/7 Triage & Doctor Appointments.',
    description: 'Provide instant compassionate answers, pre-screen symptoms, check insurance eligibility, and schedule clinic or telehealth appointments directly into your EHR/calendar.',
    sampleQuery: '"Can I book a pediatric wellness check with Dr. Lin this Thursday?"',
    sampleResponse: '"Dr. Lin has Thursday at 10:30 AM open! Would you like me to book that slot and text you the intake form?"',
    metrics: { bookings: '+42%', responseTime: '<1.2s', savedHours: '32h/wk' },
    tags: ['Doctor Scheduling', 'Symptom Triage', 'Insurance Check', 'Reminder SMS']
  },
  {
    id: 'salons',
    name: 'Salons & Luxury Spas',
    badge: 'High-Touch Concierge',
    headline: 'Turn After-Hours Inquiries into Fully Paid Salon Bookings.',
    description: 'Clients book beauty appointments late at night. ReceptionAI answers service questions, matches clients to their favorite stylists, and collects deposits automatically.',
    sampleQuery: '"Do you have any balayage appointments with Sarah on Saturday?"',
    sampleResponse: '"Sarah has Saturday at 2:00 PM open for a Full Balayage & Blowout. Shall I lock in this time for you?"',
    metrics: { bookings: '+58%', responseTime: '<0.9s', savedHours: '25h/wk' },
    tags: ['Stylist Selection', 'Add-on Upsells', 'Deposit Collection', 'VIP Reminders']
  },
  {
    id: 'legal',
    name: 'Law Firms & Attorneys',
    badge: 'Client Intake Specialist',
    headline: 'Capture High-Value Retainers Before Competitors Pick Up.',
    description: 'Screen potential clients with custom intake questionnaires, qualify practice area fit, check conflict waivers, and book initial paid or free legal consultations instantly.',
    sampleQuery: '"I need an attorney for a commercial lease dispute in SF."',
    sampleResponse: '"Our lead commercial litigator conducts initial case evaluations on Tuesdays. Can I ask 3 brief qualifying questions to book you?"',
    metrics: { bookings: '+35%', responseTime: '<1.5s', savedHours: '40h/wk' },
    tags: ['Case Triage', 'Conflict Check', 'Retainer Booking', 'Confidential Handling']
  },
  {
    id: 'realestate',
    name: 'Real Estate Agencies',
    badge: 'Listing & Showing Assistant',
    headline: 'Instant Property Tours & Buyer Qualification Around the Clock.',
    description: 'When home buyers inquire about a listing, ReceptionAI provides neighborhood details, pricing, HOA fees, and automatically schedules private walkthroughs.',
    sampleQuery: '"Is 428 Crestview still available for a private walkthrough this Sunday?"',
    sampleResponse: '"Yes, 428 Crestview is active! Sunday at 1:00 PM and 3:30 PM are open with our listing agent. Which fits your schedule?"',
    metrics: { bookings: '+49%', responseTime: '<0.8s', savedHours: '28h/wk' },
    tags: ['Showing Sync', 'Buyer Qualification', 'Listing FAQ', 'Agent Routing']
  },
  {
    id: 'homeservices',
    name: 'Home Services & HVAC',
    badge: 'Dispatch & Emergency Triage',
    headline: 'Never Lose an Emergency Pipe Burst or AC Breakdown Call.',
    description: 'Dispatch technicians, quote standard service call fees, assess emergency severity, and book repair windows 24 hours a day, 365 days a year.',
    sampleQuery: '"My water heater is leaking all over the basement right now!"',
    sampleResponse: '"Shut off your main valve immediately! We have an emergency plumber 20 mins away. Shall I dispatch them to your address?"',
    metrics: { bookings: '+64%', responseTime: '<0.6s', savedHours: '45h/wk' },
    tags: ['Emergency Triage', 'Dispatch Sync', 'Quote Estimates', 'Address Lookup']
  }
];

export const mockTestimonials = [
  {
    quote: "ReceptionAI answered over 480 inquiries during our off-hours last month alone. We captured $38,000 in new clinical patient bookings that previously would have gone to voicemail and dropped off.",
    author: "Dr. Amanda Chen",
    role: "Medical Director",
    company: "Bay Area Premier Health",
    avatar: "https://images.unsplash.com/photo-1573496799652-408c2ac9fe98?auto=format&fit=crop&q=80&w=200",
    rating: 5,
    stat: "$38k New Revenue / mo"
  },
  {
    quote: "Our front desk staff used to be constantly glued to ringing phones while clients stood waiting at the counter. Now ReceptionAI handles 85% of bookings, freeing our team to deliver white-glove service.",
    author: "David Sterling, Esq.",
    role: "Managing Partner",
    company: "Sterling & Ross Legal Group",
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=200",
    rating: 5,
    stat: "85% Calls Automated"
  },
  {
    quote: "Clients love that they can text or call at 11 PM on Sunday and get their salon appointment booked in under 60 seconds. Our weekend no-show rate dropped from 14% to under 2%.",
    author: "Genevieve Dubois",
    role: "Founder & Creative Director",
    company: "Luxe & Mane Salons",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200",
    rating: 5,
    stat: "No-shows dropped to 1.8%"
  }
];

export const mockFaqs = [
  {
    question: "How does ReceptionAI sound and behave to callers?",
    answer: "ReceptionAI speaks with natural, empathetic human-grade voice inflection with under 800ms latency. Callers experience zero awkward pauses. It understands colloquial phrases, accents, interruptions, and can smoothly hand off complex cases to human staff with a full summary."
  },
  {
    question: "Can ReceptionAI integrate with my existing calendar and booking software?",
    answer: "Yes! ReceptionAI connects directly to Google Calendar, Outlook, Calendly, Acuity, Mindbody, Jane App, Clio, ServiceTitan, and custom webhooks. It checks live availability in real time so double-booking is mathematically impossible."
  },
  {
    question: "What happens when a customer asks a question the AI doesn't know?",
    answer: "You customize your business knowledge base, FAQs, and escalation protocols. If a question falls outside approved guidelines, ReceptionAI gracefully captures their contact details and immediately notifies your on-duty team via SMS, Slack, or warm phone transfer."
  },
  {
    question: "Is ReceptionAI compliant with patient privacy and HIPAA?",
    answer: "Yes, ReceptionAI provides end-to-end encrypted voice & chat pipelines, strict zero-data retention options, signed BAAs (Business Associate Agreements) for healthcare practices, and role-based access control."
  },
  {
    question: "How long does it take to set up and train the AI receptionist?",
    answer: "Most businesses go live in under 15 minutes. Simply input your website URL or upload your services menu and business hours. ReceptionAI auto-generates your custom knowledge base and assigns a dedicated phone number or website widget code."
  },
  {
    question: "Can I customize the personality, tone, and greeting of the AI?",
    answer: "Completely. You can select between Professional & Empathetic, Warm & Friendly, Concise & Direct, or Luxury Concierge tones, define custom greetings, set service buffer times, and adjust whether appointments are auto-confirmed or sent for manual approval."
  }
];

export const mockPricingPlans = [
  {
    id: 'starter',
    name: 'Starter Practice',
    description: 'Perfect for solo practitioners and boutique studios getting started with automated scheduling.',
    monthlyPrice: 99,
    annualPrice: 79,
    features: [
      'Up to 300 AI conversations / month',
      '24/7 Web Chat & SMS Receptionist',
      'Google & Outlook Calendar sync',
      'Automated appointment confirmations',
      'Standard business hours knowledge base',
      'Email & SMS lead notifications'
    ],
    highlight: false,
    cta: 'Start 14-Day Free Trial'
  },
  {
    id: 'growth',
    name: 'Professional Clinic',
    description: 'Engineered for growing clinics, salons, and law firms needing full voice & chat automation.',
    monthlyPrice: 249,
    annualPrice: 199,
    features: [
      'Up to 1,500 AI conversations & calls / mo',
      'Dedicated local phone number with Voice AI',
      'Multi-staff & multi-room calendar routing',
      'Warm human handoff & emergency escalation',
      'Lead qualification & custom intake questionnaires',
      'CRM integration (HubSpot, Salesforce, Clio)',
      'Analytics dashboard & AI insights',
      'HIPAA & GDPR compliance package'
    ],
    highlight: true,
    badge: 'Most Popular',
    cta: 'Get Started with Growth'
  },
  {
    id: 'enterprise',
    name: 'Multi-Location Enterprise',
    description: 'For medical groups, multi-location franchises, and high-volume corporate organizations.',
    monthlyPrice: 599,
    annualPrice: 480,
    features: [
      'Unlimited AI conversations & voice minutes',
      'Multiple location phone routing',
      'Custom LLM fine-tuning on your proprietary data',
      'Full EHR / Practice Management deep sync',
      'Dedicated Account Manager & 99.99% SLA',
      'Custom webhook events & REST API access',
      'Bespoke voice cloning & accent localization',
      'Quarterly performance audit'
    ],
    highlight: false,
    cta: 'Talk to Enterprise Sales'
  }
];

export const mockAnalyticsData = {
  summary: {
    totalConversations: 1842,
    conversationsGrowth: '+19.4%',
    appointmentsBooked: 412,
    appointmentsGrowth: '+26.8%',
    leadsCaptured: 628,
    leadsGrowth: '+21.5%',
    conversionRate: 22.4,
    conversionGrowth: '+3.2%',
    revenueOpportunity: '$86,400',
    revenueGrowth: '+$14.2k',
    avgResponseTime: '780ms',
    resolutionRate: '94.2%',
    humanEscalationRate: '5.8%',
    csatScore: '4.92 / 5.0'
  },
  weeklyPerformance: [
    { day: 'Mon', conversations: 240, appointments: 56, leads: 82 },
    { day: 'Tue', conversations: 295, appointments: 68, leads: 94 },
    { day: 'Wed', conversations: 310, appointments: 72, leads: 105 },
    { day: 'Thu', conversations: 280, appointments: 64, leads: 88 },
    { day: 'Fri', conversations: 330, appointments: 84, leads: 118 },
    { day: 'Sat', conversations: 215, appointments: 42, leads: 76 },
    { day: 'Sun', conversations: 172, appointments: 26, leads: 65 }
  ],
  hourlyHeatmap: [
    { hour: '8 AM', value: 38 },
    { hour: '9 AM', value: 65 },
    { hour: '10 AM', value: 92 },
    { hour: '11 AM', value: 110 },
    { hour: '12 PM', value: 85 },
    { hour: '1 PM', value: 94 },
    { hour: '2 PM', value: 105 },
    { hour: '3 PM', value: 88 },
    { hour: '4 PM', value: 72 },
    { hour: '5 PM', value: 60 },
    { hour: '6 PM', value: 45 },
    { hour: '7 PM', value: 35 },
    { hour: '8 PM - 7 AM (After Hours)', value: 120 }
  ],
  aiInsights: [
    {
      id: 'ins-1',
      type: 'growth',
      title: 'Appointment requests increased 18% this week',
      description: 'Demand spiked heavily between 6:00 PM and 10:00 PM when human front desks are traditionally closed. ReceptionAI successfully converted 48 after-hours appointments without manual intervention.',
      metric: '+18% booking volume',
      tag: 'High Impact'
    },
    {
      id: 'ins-2',
      type: 'optimization',
      title: 'Popular inquiry: "Do you take Delta Dental PPO?"',
      description: 'The AI answered 34 inquiries regarding Delta Dental PPO. 88% of patients booked once confirmed in-network. Recommendation: Keep insurance FAQs prominently updated.',
      metric: '34 Inquiries • 88% Conversion',
      tag: 'Knowledge Base'
    },
    {
      id: 'ins-3',
      type: 'efficiency',
      title: 'Average AI response time dropped to 780ms',
      description: 'Instant response speeds reduced chat drop-off by 14.3% compared to previous industry benchmark standards of 5+ minutes for live receptionist queues.',
      metric: '780ms average latency',
      tag: 'Performance'
    },
    {
      id: 'ins-4',
      type: 'channel',
      title: 'SMS & WhatsApp appointment reminders eliminated 91% of no-shows',
      description: 'Automated 24h & 2h reminders with one-tap confirmation resulted in only 3 no-shows out of 142 scheduled visits this week.',
      metric: '1.8% no-show rate',
      tag: 'Retention'
    }
  ]
};
