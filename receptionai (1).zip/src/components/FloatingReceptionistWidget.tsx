import React, { useState, useRef, useEffect } from 'react';
import { Bot, X, Send, Mic, MicOff, Volume2, VolumeX, Sparkles, Calendar, MessageSquare, PhoneCall } from 'lucide-react';
import { processUserQuery, AIContextState } from '../services/aiReceptionistEngine';
import { voiceService } from '../services/voiceService';
import { BusinessConfig, ChatMessage, AppView } from '../types';
import { mockServices } from '../data/mockData';

interface FloatingReceptionistWidgetProps {
  businessConfig: BusinessConfig;
  onNavigate: (view: AppView) => void;
  onLaunchBooking: (serviceId?: string) => void;
}

export const FloatingReceptionistWidget: React.FC<FloatingReceptionistWidgetProps> = ({
  businessConfig,
  onNavigate,
  onLaunchBooking
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [inputVal, setInputVal] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [ttsEnabled, setTtsEnabled] = useState(true);

  const [aiContext, setAiContext] = useState<AIContextState>({
    currentIndustry: 'medical',
    selectedService: null,
    selectedDate: null,
    selectedTime: null,
    selectedDoctor: null,
    patientName: null,
    patientPhone: null,
    bookingStep: 'idle',
    conversationHistory: []
  });

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'w-1',
      sender: 'ai',
      text: `Hi there! 👋 I am ${businessConfig.aiName || 'Aria'}, your virtual receptionist. Need to book a doctor appointment, check pricing, or ask a question?`,
      timestamp: 'Just now',
      type: 'text',
      aiAnalysis: {
        intent: 'greeting',
        confidence: 0.99,
        sentiment: 'positive',
        suggestedFollowUps: ['Book an appointment', 'Services & Prices', 'Operating Hours', 'Do you take insurance?']
      }
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isTyping]);

  const handleSendMessage = (text: string) => {
    if (!text.trim() || isTyping) return;

    voiceService.playSound('message_sent');

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputVal('');
    setIsTyping(true);

    setTimeout(() => {
      const response = processUserQuery(text, aiContext, businessConfig, mockServices);
      setAiContext(response.updatedContext);

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: response.replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: response.type,
        data: response.data,
        aiAnalysis: response.aiAnalysis
      };

      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
      voiceService.playSound('message_incoming');

      if (ttsEnabled) {
        voiceService.speak(response.replyText);
      }
    }, 380);
  };

  const toggleMic = () => {
    if (isListening) {
      voiceService.stopListening();
      setIsListening(false);
    } else {
      if (!voiceService.isSpeechSupported()) return;
      voiceService.stopSpeaking();
      setIsListening(true);
      voiceService.startListening({
        onStart: () => setIsListening(true),
        onTranscript: (txt, isFinal) => {
          if (isFinal && txt.trim()) {
            setIsListening(false);
            handleSendMessage(txt);
          }
        },
        onError: () => setIsListening(false),
        onEnd: () => setIsListening(false)
      });
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 font-sans">
      {/* Expanded Modal Window */}
      {isOpen && (
        <div className="mb-3 w-[360px] sm:w-[410px] h-[520px] max-h-[85vh] bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          
          {/* Header */}
          <div className="bg-slate-950/90 border-b border-slate-800 p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-600 flex items-center justify-center text-white shadow-md">
                  <Bot className="w-5 h-5" />
                </div>
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-slate-950 rounded-full"></span>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="text-xs font-bold text-white leading-tight">
                    {businessConfig.aiName || 'Aria'} • Front Desk AI
                  </h3>
                  <span className="text-[9px] font-bold uppercase bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded">
                    Online
                  </span>
                </div>
                <p className="text-[10px] text-slate-400">Zero-API Local Reasoning • 24/7</p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setTtsEnabled(!ttsEnabled)}
                className={`p-1.5 rounded-lg text-slate-400 hover:text-white transition-colors ${ttsEnabled ? 'text-indigo-400' : ''}`}
                title={ttsEnabled ? 'Voice output on' : 'Voice output muted'}
              >
                {ttsEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>

              <button
                onClick={() => {
                  setIsOpen(false);
                  onNavigate('receptionist');
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white transition-colors"
                title="Open Fullscreen Receptionist Experience"
              >
                <PhoneCall className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white transition-colors"
                title="Close Widget"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-3.5 overflow-y-auto space-y-3 bg-slate-950/50 text-xs">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex gap-2 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {m.sender === 'ai' && (
                  <div className="w-6 h-6 rounded-lg bg-indigo-600 flex items-center justify-center text-white shrink-0 mt-0.5">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                )}
                <div
                  className={`p-3 rounded-2xl max-w-[85%] leading-relaxed ${
                    m.sender === 'user'
                      ? 'bg-indigo-600 text-white rounded-br-xs'
                      : 'bg-slate-800 text-slate-200 border border-slate-700/70 rounded-bl-xs'
                  }`}
                >
                  <p className="whitespace-pre-line">{m.text}</p>

                  {/* Embedded suggested quick follow-up chips */}
                  {m.aiAnalysis?.suggestedFollowUps && (
                    <div className="mt-2.5 pt-2 border-t border-slate-700/60 flex flex-wrap gap-1">
                      {m.aiAnalysis.suggestedFollowUps.slice(0, 3).map((chip, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSendMessage(chip)}
                          className="text-[10px] px-2 py-0.5 rounded-full bg-slate-700/60 hover:bg-indigo-600 text-slate-300 hover:text-white transition-all border border-slate-600/40"
                        >
                          {chip}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center gap-2 text-slate-400 text-xs">
                <div className="w-6 h-6 rounded-lg bg-indigo-600 flex items-center justify-center text-white shrink-0">
                  <Bot className="w-3.5 h-3.5" />
                </div>
                <div className="bg-slate-800 border border-slate-700 rounded-xl p-2.5 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce [animation-delay:-0.15s]"></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-bounce [animation-delay:-0.3s]"></span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Actions Row */}
          <div className="px-3 py-2 bg-slate-950 border-t border-slate-800 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            <button
              onClick={() => {
                setIsOpen(false);
                onLaunchBooking();
              }}
              className="text-[11px] font-semibold text-indigo-300 bg-indigo-950/60 hover:bg-indigo-900/80 px-2.5 py-1 rounded-lg border border-indigo-800/60 flex items-center gap-1 shrink-0"
            >
              <Calendar className="w-3 h-3" />
              Book Appointment
            </button>
            <button
              onClick={() => handleSendMessage('Show all services and prices')}
              className="text-[11px] font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg shrink-0"
            >
              Services & Pricing
            </button>
            <button
              onClick={() => handleSendMessage('What are your hours and address?')}
              className="text-[11px] font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg shrink-0"
            >
              Hours & Location
            </button>
          </div>

          {/* Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(inputVal);
            }}
            className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2"
          >
            <button
              type="button"
              onClick={toggleMic}
              className={`p-2 rounded-xl border transition-all ${
                isListening
                  ? 'bg-emerald-500 text-white border-emerald-400 animate-pulse'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
              title="Voice Input"
            >
              {isListening ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            </button>

            <input
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="Ask anything..."
              className="flex-1 text-xs bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />

            <button
              type="submit"
              disabled={!inputVal.trim() || isTyping}
              className="p-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-xl transition-all shadow-md"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>
      )}

      {/* Floating Trigger Button */}
      <button
        onClick={() => {
          setIsOpen(!isOpen);
          voiceService.playSound('button_tap');
        }}
        className="group flex items-center gap-2.5 px-4 py-3 bg-gradient-to-r from-indigo-600 via-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-full shadow-2xl shadow-indigo-600/40 hover:scale-105 transition-all duration-200 border border-indigo-400/30"
        aria-label="Talk with Virtual Receptionist"
      >
        <div className="relative">
          <Bot className="w-5 h-5 text-white" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full border border-slate-900 animate-ping"></span>
        </div>
        <span className="text-xs font-bold tracking-tight pr-1">
          {isOpen ? 'Close Assistant' : 'Talk to AI Receptionist'}
        </span>
      </button>
    </div>
  );
};
