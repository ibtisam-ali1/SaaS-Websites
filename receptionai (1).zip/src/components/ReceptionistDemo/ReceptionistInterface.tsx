import React, { useState, useEffect, useRef } from 'react';
import { AppView, Service, ChatMessage, Lead, BusinessConfig, Appointment } from '../../types';
import { mockServices } from '../../data/mockData';
import { processUserQuery, AIContextState, INDUSTRY_DATA } from '../../services/aiReceptionistEngine';
import { voiceService } from '../../services/voiceService';
import { 
  Bot, 
  Send, 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  MapPin, 
  CheckCircle2, 
  Volume2, 
  VolumeX, 
  Mic, 
  MicOff,
  RotateCcw, 
  ArrowLeft, 
  Sparkles,
  PhoneCall,
  PhoneOff,
  UserCheck,
  Building2,
  ChevronRight,
  ShieldCheck,
  Headphones,
  Smartphone,
  MessageSquare,
  Share2,
  Download,
  AlertTriangle,
  Play,
  Pause,
  Info,
  Maximize2,
  HeartPulse,
  Radio,
  ExternalLink
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useToast } from '../Toast';

interface ReceptionistInterfaceProps {
  onNavigate: (view: AppView) => void;
  onLaunchBooking?: (serviceId?: string) => void;
  onBookService?: (serviceId?: string) => void;
  onLeadCaptured?: (lead: Lead) => void;
  onAppointmentCreated?: (appointment: Appointment) => void;
  businessConfig?: BusinessConfig;
}

type OmnichannelMode = 'chat' | 'phone' | 'sms' | 'whatsapp' | 'kiosk';

export const ReceptionistInterface: React.FC<ReceptionistInterfaceProps> = ({
  onNavigate,
  onLaunchBooking,
  onBookService,
  onLeadCaptured,
  onAppointmentCreated,
  businessConfig: propConfig
}) => {
  const { showToast } = useToast();

  // Active industry persona
  const [activePersona, setActivePersona] = useState<'medical' | 'salon' | 'legal' | 'realestate' | 'hvac'>('medical');
  
  // Omnichannel simulator mode
  const [omniMode, setOmniMode] = useState<OmnichannelMode>('chat');

  // Business config with fallback
  const config = propConfig || {
    name: 'Apex Health Clinic',
    industry: 'Medical & Healthcare',
    phone: '+1 (555) 234-8900',
    email: 'care@apexhealthclinic.com',
    address: '742 Evergreen Terrace, Suite 300, San Francisco, CA',
    timezone: 'America/Los_Angeles (PST)',
    aiName: 'Aria',
    aiTone: 'Empathetic & Professional',
    welcomeMessage: 'Hello! I am Aria, your 24/7 AI receptionist at Apex Health Clinic. How can I assist you with doctor scheduling, services, or clinic information today?',
    bufferMinutes: 15,
    noticeHours: 2,
    autoConfirm: true,
    smsNotifications: true,
    emailNotifications: true,
    escalationPhone: '+1 (555) 899-4422'
  };

  // Voice & Speech synthesis states
  const [isVoiceSpeaking, setIsVoiceSpeaking] = useState(false);
  const [isListeningMic, setIsListeningMic] = useState(false);
  const [voiceAudioEnabled, setVoiceAudioEnabled] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isOnHold, setIsOnHold] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [interimSpeechText, setInterimSpeechText] = useState('');

  // Conversational context state
  const [aiContext, setAiContext] = useState<AIContextState>({
    currentIndustry: 'medical',
    selectedService: null,
    selectedDate: null,
    selectedTime: null,
    selectedDoctor: null,
    patientName: null,
    patientPhone: null,
    bookingStep: 'idle',
    conversationHistory: []
  });

  // Chat message history
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'ai',
      text: 'Good day! I am Aria, your 24/7 AI virtual receptionist at Apex Health Clinic. I can schedule doctor appointments, verify insurance, answer symptom questions, or connect you with our clinical team. How may I assist you today?',
      timestamp: 'Just now',
      type: 'text',
      aiAnalysis: {
        intent: 'greeting',
        confidence: 0.99,
        sentiment: 'positive',
        suggestedFollowUps: [
          'Book an appointment',
          'What are your services and prices?',
          'What insurance plans do you accept?',
          'Where is your clinic located?'
        ]
      }
    }
  ]);

  const [inputVal, setInputVal] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [latestAnalysis, setLatestAnalysis] = useState<{
    intent: string;
    confidence: number;
    sentiment: string;
    latencyMs: number;
  }>({
    intent: 'greeting',
    confidence: 0.99,
    sentiment: 'positive',
    latencyMs: 38
  });

  // Inline lead form state
  const [leadFormName, setLeadFormName] = useState('');
  const [leadFormPhone, setLeadFormPhone] = useState('');
  const [leadFormEmail, setLeadFormEmail] = useState('');
  const [leadSubmitted, setLeadSubmitted] = useState(false);

  // In-chat booking confirmed state
  const [lastBookedRef, setLastBookedRef] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping, interimSpeechText]);

  // Telephony call duration timer
  useEffect(() => {
    let timer: any;
    if (omniMode === 'phone') {
      timer = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(timer);
  }, [omniMode]);

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Switch persona handler
  const handlePersonaChange = (persona: 'medical' | 'salon' | 'legal' | 'realestate' | 'hvac') => {
    setActivePersona(persona);
    const indData = INDUSTRY_DATA[persona];
    let greeting = '';
    let followUps: string[] = [];

    switch (persona) {
      case 'medical':
        greeting = 'Good day! I am Aria, virtual receptionist for Apex Health Clinic. I can schedule consultations with our board-certified physicians, explain insurance coverage, or answer pre-visit questions. How can I assist you?';
        followUps = ['Book an appointment', 'Comprehensive Physical ($195)', 'What insurance do you accept?', 'Where do I park?'];
        break;
      case 'salon':
        greeting = 'Welcome to Luxe & Mane Salon & Day Spa! I am Chloe, your concierge. Looking to book a master balayage, precision cut, hydrafacial, or deep tissue massage today?';
        followUps = ['Book Balayage & Glaze ($240)', 'Precision Cut ($95)', 'What are your hours?', 'Who are your master stylists?'];
        break;
      case 'legal':
        greeting = 'Welcome to Vanguard Legal Advisory. I am Justin, your confidential intake assistant. I can schedule an initial case evaluation or route urgent litigation matters to an attorney.';
        followUps = ['Schedule Initial Case Evaluation ($150)', 'Contract Review', 'Who are your attorneys?', 'Is consultation confidential?'];
        break;
      case 'realestate':
        greeting = 'Hello! I am Maya with Crestview Luxury Realty. Inquiring about private property viewings, home valuation, or current Beverly Hills estate listings?';
        followUps = ['Schedule Private Property Tour', 'Request Home Valuation', 'Speak with Maya Lin', 'View active listings'];
        break;
      case 'hvac':
        greeting = 'Apex Emergency Home & HVAC Services. Need urgent AC repair, pipe burst leak detection, or annual furnace maintenance dispatched to your location?';
        followUps = ['Emergency Dispatch (Under 45m)', 'AC Repair Service ($149)', 'Water Heater Leak', 'Operating Hours'];
        break;
    }

    setAiContext(prev => ({
      ...prev,
      currentIndustry: persona,
      selectedService: null,
      bookingStep: 'idle'
    }));

    setMessages([
      {
        id: Date.now().toString(),
        sender: 'ai',
        text: greeting,
        timestamp: 'Just now',
        type: 'text',
        aiAnalysis: {
          intent: 'persona_greeting',
          confidence: 0.99,
          sentiment: 'positive',
          suggestedFollowUps: followUps
        }
      }
    ]);

    voiceService.playSound('call_connect');
    showToast({
      type: 'info',
      title: `${indData.businessName} Loaded`,
      message: `AI Receptionist configured with ${persona.toUpperCase()} knowledge base.`
    });
  };

  // Main Zero-API Message Processor
  const handleUserSubmit = (text: string) => {
    if (!text.trim() || isTyping) return;

    // Play user sent audio chime
    voiceService.playSound('message_sent');

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputVal('');
    setInterimSpeechText('');
    setIsTyping(true);

    const startTime = performance.now();

    // Natural reception response latency simulation (300-500ms)
    setTimeout(() => {
      const response = processUserQuery(text, aiContext, config, mockServices);
      const latency = Math.round(performance.now() - startTime);

      setAiContext(response.updatedContext);
      setLatestAnalysis({
        intent: response.aiAnalysis.intent,
        confidence: response.aiAnalysis.confidence,
        sentiment: response.aiAnalysis.sentiment,
        latencyMs: latency
      });

      const aiMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: response.replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: response.type,
        data: response.data,
        aiAnalysis: response.aiAnalysis
      };

      setMessages((prev) => [...prev, aiMessage]);
      setIsTyping(false);

      // Play soft incoming message chime
      voiceService.playSound('message_incoming');

      // If voice is enabled or in phone call mode, synthesize speech aloud
      if ((omniMode === 'phone' || voiceAudioEnabled) && !isMuted && !isOnHold) {
        setIsVoiceSpeaking(true);
        voiceService.speak(response.replyText, {
          rate: 1.04,
          pitch: 1.0,
          onStart: () => setIsVoiceSpeaking(true),
          onEnd: () => setIsVoiceSpeaking(false)
        });
      }
    }, 420);
  };

  // Voice Recognition Toggle
  const toggleSpeechRecognition = () => {
    if (isListeningMic) {
      voiceService.stopListening();
      setIsListeningMic(false);
      setInterimSpeechText('');
    } else {
      if (!voiceService.isSpeechSupported()) {
        showToast({
          type: 'warning',
          title: 'Speech Recognition Unavailable',
          message: 'Your browser does not support Web Speech Recognition. You can still type questions freely!'
        });
        return;
      }

      voiceService.stopSpeaking();
      setIsVoiceSpeaking(false);
      setIsListeningMic(true);

      voiceService.startListening({
        onStart: () => {
          setIsListeningMic(true);
          showToast({
            type: 'info',
            title: 'Listening...',
            message: 'Speak naturally into your microphone.'
          });
        },
        onTranscript: (transcript, isFinal) => {
          if (isFinal && transcript.trim()) {
            setIsListeningMic(false);
            setInterimSpeechText('');
            handleUserSubmit(transcript);
          } else {
            setInterimSpeechText(transcript);
          }
        },
        onError: (err) => {
          setIsListeningMic(false);
          setInterimSpeechText('');
          console.warn('Speech recognition error:', err);
        },
        onEnd: () => {
          setIsListeningMic(false);
          setInterimSpeechText('');
        }
      });
    }
  };

  // Instant In-Chat Slot Booking Handler
  const handleConfirmInChatSlot = (slot: { day: string; time: string; doctor: string }, service: Service) => {
    const refCode = `APX-${Math.floor(1000 + Math.random() * 9000)}`;
    setLastBookedRef(refCode);

    // Create formal appointment object
    const newAppointment: Appointment = {
      id: `apt-${Date.now()}`,
      serviceId: service.id,
      serviceName: service.name,
      staffId: 'staff-1',
      staffName: slot.doctor,
      customerName: 'Verified Patient',
      customerEmail: 'patient@example.com',
      customerPhone: '+1 (555) 789-0123',
      date: new Date().toISOString().split('T')[0],
      time: slot.time,
      status: 'confirmed',
      price: service.price,
      createdAt: new Date().toISOString()
    };

    if (onAppointmentCreated) {
      onAppointmentCreated(newAppointment);
    }

    // Trigger celebratory confetti
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.7 }
    });

    voiceService.playSound('call_connect');

    showToast({
      type: 'success',
      title: 'Appointment Confirmed!',
      message: `Reserved ${service.name} with ${slot.doctor} on ${slot.day} at ${slot.time}. Booking Ref: #${refCode}`
    });

    setMessages((prev) => [
      ...prev,
      {
        id: `sys-${Date.now()}`,
        sender: 'system',
        text: `Appointment Confirmed! Reference Code: #${refCode}`,
        timestamp: 'Just now',
        type: 'confirmation_card',
        data: {
          serviceName: service.name,
          doctor: slot.doctor,
          day: slot.day,
          time: slot.time,
          price: service.price,
          refCode: refCode
        }
      }
    ]);
  };

  // Lead capture handler
  const handleLeadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!leadFormName || !leadFormPhone) {
      showToast({
        type: 'warning',
        title: 'Information required',
        message: 'Please provide both your name and phone number.'
      });
      return;
    }

    const newLead: Lead = {
      id: `ld-${Date.now()}`,
      name: leadFormName,
      company: 'Website Inquirer',
      email: leadFormEmail || `${leadFormName.toLowerCase().replace(/\s+/g, '.')}@example.com`,
      phone: leadFormPhone,
      source: omniMode === 'phone' ? 'AI Phone Call' : 'AI Web Chat',
      status: 'New',
      date: new Date().toISOString().split('T')[0],
      estimatedValue: 240,
      intent: 'High',
      interestService: 'General Practice Consultation',
      notes: 'Requested warm receptionist callback.',
      conversationsCount: 1
    };

    if (onLeadCaptured) {
      onLeadCaptured(newLead);
    }

    setLeadSubmitted(true);
    showToast({
      type: 'success',
      title: 'Callback Scheduled',
      message: 'Priority staff notification dispatched. We will call you shortly!'
    });

    setMessages((prev) => [
      ...prev,
      {
        id: `sys-${Date.now()}`,
        sender: 'system',
        text: `Callback confirmed for ${leadFormName} (${leadFormPhone}). Priority front desk notification dispatched.`,
        timestamp: 'Just now'
      }
    ]);
  };

  // Download .ics calendar file
  const handleDownloadCalendar = (appointmentData: any) => {
    const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//ReceptionAI//Clinic Appointment//EN
BEGIN:VEVENT
SUMMARY:${appointmentData.serviceName} - Apex Health Clinic
DESCRIPTION:Doctor: ${appointmentData.doctor}\\nBooking Ref: #${appointmentData.refCode}\\nAddress: 742 Evergreen Terrace, Suite 300, San Francisco
LOCATION:742 Evergreen Terrace, Suite 300, San Francisco, CA
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR`;

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `appointment-${appointmentData.refCode || 'confirmed'}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showToast({
      type: 'info',
      title: 'Calendar File Saved',
      message: 'Saved .ics event. Open with Google Calendar or Apple iCal.'
    });
  };

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col bg-slate-900 text-slate-100 overflow-hidden font-sans">
      
      {/* Top Header Bar */}
      <header className="bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 sm:px-6 py-2.5 flex items-center justify-between shadow-md z-20 shrink-0">
        
        {/* Left: Back & Avatar */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('landing')}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Return to Landing Page"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="relative">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 via-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/30">
              <Bot className="w-5 h-5" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 border-2 border-slate-900 rounded-full animate-pulse"></span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm sm:text-base font-bold text-white leading-tight">
                {config.aiName || 'Aria'} • ReceptionAI
              </h1>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                Zero-API Ready
              </span>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-2">
              <span className="flex items-center gap-1 text-emerald-400 font-medium">
                <Clock className="w-3 h-3" />
                {latestAnalysis.latencyMs}ms Latency
              </span>
              <span>•</span>
              <span>100% Contextual Reasoning</span>
            </p>
          </div>
        </div>

        {/* Center: Omnichannel Mode Switcher */}
        <div className="hidden md:flex items-center gap-1 bg-slate-800/80 p-1 rounded-2xl border border-slate-700/80 text-xs">
          {[
            { id: 'chat', label: 'Web Chat', icon: <MessageSquare className="w-3.5 h-3.5" /> },
            { id: 'phone', label: 'Phone Call', icon: <PhoneCall className="w-3.5 h-3.5" /> },
            { id: 'sms', label: 'SMS Two-Way', icon: <Smartphone className="w-3.5 h-3.5" /> },
            { id: 'whatsapp', label: 'WhatsApp', icon: <Share2 className="w-3.5 h-3.5" /> },
            { id: 'kiosk', label: 'Front Kiosk', icon: <Maximize2 className="w-3.5 h-3.5" /> }
          ].map((m) => (
            <button
              key={m.id}
              onClick={() => {
                setOmniMode(m.id as OmnichannelMode);
                voiceService.playSound('button_tap');
                if (m.id === 'phone') {
                  voiceService.playSound('call_connect');
                }
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold transition-all ${
                omniMode === m.id
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/40'
              }`}
            >
              {m.icon}
              <span>{m.label}</span>
            </button>
          ))}
        </div>

        {/* Right: Audio Toggle & Actions */}
        <div className="flex items-center gap-2">
          {/* TTS Speech Synthesis Audio Toggle */}
          <button
            onClick={() => {
              setVoiceAudioEnabled(!voiceAudioEnabled);
              if (voiceAudioEnabled) {
                voiceService.stopSpeaking();
                setIsVoiceSpeaking(false);
              }
              showToast({
                type: 'info',
                title: voiceAudioEnabled ? 'Voice Muted' : 'Voice Synthesis Active',
                message: voiceAudioEnabled ? 'AI will respond silently.' : 'AI will speak responses aloud.'
              });
            }}
            className={`p-2 rounded-xl border text-xs font-semibold transition-all ${
              voiceAudioEnabled
                ? 'bg-indigo-600/20 text-indigo-400 border-indigo-500/30'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
            title={voiceAudioEnabled ? 'Mute AI Voice Output' : 'Enable AI Voice Output'}
          >
            {voiceAudioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Direct Booking Modal Button */}
          <button
            onClick={() => {
              if (onLaunchBooking) onLaunchBooking();
              else if (onBookService) onBookService();
              else onNavigate('booking');
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white shadow-md shadow-indigo-600/25 transition-all"
          >
            <Calendar className="w-4 h-4" />
            <span className="hidden sm:inline">Book Service</span>
          </button>

          {/* Reset Chat */}
          <button
            onClick={() => {
              voiceService.stopSpeaking();
              setMessages([
                {
                  id: Date.now().toString(),
                  sender: 'ai',
                  text: 'Conversation reset. How can I assist you with scheduling or clinic inquiries today?',
                  timestamp: 'Just now',
                  type: 'text'
                }
              ]);
              showToast({
                type: 'info',
                title: 'Chat Reset',
                message: 'Fresh session started.'
              });
            }}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
            title="Reset Chat Session"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

      </header>

      {/* Sub-bar: Industry Persona Selector */}
      <div className="bg-slate-900/60 border-b border-slate-800/80 px-4 sm:px-6 py-2 flex items-center justify-between text-xs overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-slate-400 font-semibold text-[11px] uppercase tracking-wider">Practice Profile:</span>
          {(['medical', 'salon', 'legal', 'realestate', 'hvac'] as const).map((p) => (
            <button
              key={p}
              onClick={() => handlePersonaChange(p)}
              className={`px-3 py-1 rounded-xl font-semibold capitalize transition-all shrink-0 ${
                activePersona === p
                  ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {p}
            </button>
          ))}
        </div>

        {/* Live Intent Radar Indicator */}
        <div className="hidden lg:flex items-center gap-3 shrink-0 text-[11px] font-mono">
          <span className="text-slate-400">Live Intent:</span>
          <span className="text-indigo-300 font-semibold px-2 py-0.5 rounded bg-indigo-950/60 border border-indigo-800/60">
            {latestAnalysis.intent} ({Math.round(latestAnalysis.confidence * 100)}%)
          </span>
          <span className="text-slate-400">Sentiment:</span>
          <span className={`capitalize font-semibold px-2 py-0.5 rounded border ${
            latestAnalysis.sentiment === 'positive'
              ? 'text-emerald-300 bg-emerald-950/60 border-emerald-800/60'
              : latestAnalysis.sentiment === 'urgent'
              ? 'text-rose-300 bg-rose-950/60 border-rose-800/60'
              : 'text-slate-300 bg-slate-800 border-slate-700'
          }`}>
            {latestAnalysis.sentiment}
          </span>
        </div>
      </div>

      {/* Main Experience Layout */}
      <div className="flex-1 flex overflow-hidden max-w-7xl w-full mx-auto p-2 sm:p-4 gap-4">
        
        {/* ================= CONTAINER FOR CHOSEN OMNICHANNEL EXPERIENCE ================= */}
        <div className="flex-1 bg-slate-950 rounded-3xl border border-slate-800 shadow-2xl flex flex-col overflow-hidden relative">
          
          {/* ================= MODE: PHONE CALL SIMULATION ================= */}
          {omniMode === 'phone' ? (
            <div className="flex-1 flex flex-col items-center justify-between p-6 sm:p-8 bg-gradient-to-b from-slate-950 via-slate-900 to-indigo-950/40 text-white relative">
              
              {/* Top Call Info */}
              <div className="text-center space-y-2 mt-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
                  <Radio className="w-3.5 h-3.5 animate-pulse" />
                  <span>Telephony Call Active • {formatDuration(callDuration)}</span>
                </div>

                <div className="relative mx-auto mt-4 w-24 h-24 sm:w-28 sm:h-28 rounded-full p-1 bg-gradient-to-tr from-indigo-500 to-violet-500 shadow-xl shadow-indigo-500/20">
                  <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center overflow-hidden">
                    <Bot className="w-12 h-12 text-indigo-400" />
                  </div>
                  {isVoiceSpeaking && (
                    <div className="absolute inset-0 rounded-full border-4 border-indigo-400 animate-ping"></div>
                  )}
                </div>

                <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight pt-2">
                  {config.aiName || 'Aria'} • Front Desk Virtual Receptionist
                </h2>
                <p className="text-xs sm:text-sm text-slate-400">
                  {config.name} • {config.phone}
                </p>
              </div>

              {/* Animated Soundwave Visualizer */}
              <div className="w-full max-w-md my-4 p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col items-center gap-3">
                <div className="flex items-center justify-center gap-1.5 h-12 w-full">
                  {[24, 40, 68, 85, 45, 95, 60, 80, 50, 70, 90, 40, 60, 30, 80, 50].map((h, i) => (
                    <div
                      key={i}
                      style={{
                        height: isVoiceSpeaking || isListeningMic ? `${Math.max(12, h * (isVoiceSpeaking ? 1 : 0.6))}%` : '8px'
                      }}
                      className={`w-1.5 rounded-full transition-all duration-150 ${
                        isVoiceSpeaking
                          ? 'bg-gradient-to-t from-indigo-500 to-violet-400'
                          : isListeningMic
                          ? 'bg-gradient-to-t from-emerald-500 to-emerald-300'
                          : 'bg-slate-700'
                      }`}
                    ></div>
                  ))}
                </div>

                <div className="text-xs text-center font-medium text-slate-300">
                  {isVoiceSpeaking ? (
                    <span className="text-indigo-300 animate-pulse">🔊 Aria is speaking to caller...</span>
                  ) : isListeningMic ? (
                    <span className="text-emerald-400 animate-pulse">🎙️ Listening to caller speech...</span>
                  ) : isOnHold ? (
                    <span className="text-amber-400">⏸️ Caller on hold (pleasant chime playing)</span>
                  ) : (
                    <span className="text-slate-400">Press microphone below or speak to converse in real time</span>
                  )}
                </div>
              </div>

              {/* Live Transcript Drawer */}
              <div className="w-full max-w-lg bg-slate-900/60 rounded-2xl border border-slate-800 p-3.5 max-h-40 overflow-y-auto space-y-2 text-xs">
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                  <span>Live Telephony Transcript</span>
                  <span className="text-emerald-400">Real-time STT/TTS</span>
                </div>
                {messages.slice(-3).map((m) => (
                  <div key={m.id} className="text-xs leading-relaxed">
                    <strong className={m.sender === 'user' ? 'text-indigo-400' : 'text-emerald-400'}>
                      {m.sender === 'user' ? 'Caller: ' : `${config.aiName || 'Aria'}: `}
                    </strong>
                    <span className="text-slate-200">{m.text}</span>
                  </div>
                ))}
              </div>

              {/* In-Call Telephony Controls */}
              <div className="flex items-center gap-4 mt-6">
                {/* Mute Button */}
                <button
                  onClick={() => {
                    setIsMuted(!isMuted);
                    voiceService.playSound('button_tap');
                    showToast({
                      type: 'info',
                      title: isMuted ? 'Unmuted' : 'Muted',
                      message: isMuted ? 'Microphone audio active.' : 'Microphone muted.'
                    });
                  }}
                  className={`p-4 rounded-full border transition-all ${
                    isMuted
                      ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                      : 'bg-slate-800 hover:bg-slate-700 text-white border-slate-700'
                  }`}
                  title={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>

                {/* Hold Music Toggle */}
                <button
                  onClick={() => {
                    setIsOnHold(!isOnHold);
                    voiceService.playSound(isOnHold ? 'call_connect' : 'button_tap');
                    showToast({
                      type: 'info',
                      title: isOnHold ? 'Resumed Call' : 'Call Placed On Hold',
                      message: isOnHold ? 'Aria back on line.' : 'Playing gentle clinic hold chime.'
                    });
                  }}
                  className={`p-4 rounded-full border transition-all ${
                    isOnHold
                      ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                      : 'bg-slate-800 hover:bg-slate-700 text-white border-slate-700'
                  }`}
                  title={isOnHold ? 'Resume Call' : 'Place on Hold'}
                >
                  {isOnHold ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
                </button>

                {/* Hang Up Button */}
                <button
                  onClick={() => {
                    voiceService.playSound('call_disconnect');
                    voiceService.stopSpeaking();
                    setOmniMode('chat');
                    showToast({
                      type: 'info',
                      title: 'Call Ended',
                      message: 'Returned to Web Chat simulator mode.'
                    });
                  }}
                  className="p-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/30 transition-transform hover:scale-105"
                  title="End Call"
                >
                  <PhoneOff className="w-6 h-6" />
                </button>

                {/* Speak via Mic Button */}
                <button
                  onClick={toggleSpeechRecognition}
                  className={`p-4 rounded-full border transition-all ${
                    isListeningMic
                      ? 'bg-emerald-500 text-white border-emerald-400 animate-pulse'
                      : 'bg-slate-800 hover:bg-slate-700 text-emerald-400 border-slate-700'
                  }`}
                  title={isListeningMic ? 'Stop Listening' : 'Speak into Microphone'}
                >
                  <Headphones className="w-5 h-5" />
                </button>
              </div>

            </div>
          ) : (
            /* ================= MODE: WEB CHAT / SMS / WHATSAPP / KIOSK ================= */
            <div className="flex-1 flex flex-col overflow-hidden bg-slate-900/50">
              
              {/* WhatsApp / SMS Mode Custom Header Banner */}
              {omniMode === 'whatsapp' && (
                <div className="bg-emerald-950/80 border-b border-emerald-800/60 px-4 py-2 flex items-center justify-between text-xs text-emerald-200">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    <span className="font-bold">WhatsApp Business Verified Account</span>
                  </div>
                  <span className="text-[11px] text-emerald-300">Official Clinic Concierge</span>
                </div>
              )}

              {omniMode === 'kiosk' && (
                <div className="bg-indigo-950/80 border-b border-indigo-800/60 px-4 py-2 flex items-center justify-between text-xs text-indigo-200">
                  <div className="flex items-center gap-2">
                    <Maximize2 className="w-3.5 h-3.5 text-indigo-400" />
                    <span className="font-bold">Lobby Tablet Kiosk Mode</span>
                  </div>
                  <span className="text-[11px] text-indigo-300">Touch to interact • Apex Health Check-In</span>
                </div>
              )}

              {/* Messages Scroll Area */}
              <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    {msg.sender === 'ai' && (
                      <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-600 flex items-center justify-center text-white shrink-0 shadow-md mt-0.5">
                        <Bot className="w-4 h-4" />
                      </div>
                    )}

                    {msg.sender === 'human_agent' && (
                      <div className="w-8 h-8 rounded-xl bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-md mt-0.5">
                        <UserCheck className="w-4 h-4" />
                      </div>
                    )}

                    <div className="space-y-2 max-w-[88%] sm:max-w-[78%]">
                      
                      {/* Message Bubble */}
                      <div
                        className={`p-4 text-xs sm:text-sm leading-relaxed rounded-2xl ${
                          msg.sender === 'user'
                            ? 'bg-indigo-600 text-white rounded-br-xs shadow-md ml-auto'
                            : msg.sender === 'system'
                            ? 'bg-amber-950/60 text-amber-200 border border-amber-800/80 mx-auto text-center'
                            : 'bg-slate-800/90 text-slate-100 border border-slate-700/80 rounded-bl-xs shadow-lg'
                        }`}
                      >
                        {/* Text Content */}
                        <div className="whitespace-pre-line">{msg.text}</div>

                        {/* Rich Embed: Interactive Date/Time Slot Picker */}
                        {msg.type === 'interactive_slots' && msg.data && (
                          <div className="mt-4 pt-3 border-t border-slate-700 space-y-2.5">
                            <div className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                              <Calendar className="w-3.5 h-3.5" />
                              Select an Open Slot to Confirm Instantly:
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {msg.data.slots.map((s: any) => (
                                <button
                                  key={s.id}
                                  onClick={() => handleConfirmInChatSlot(s, msg.data.service)}
                                  className="p-3 bg-slate-900/90 hover:bg-indigo-900/60 border border-slate-700 hover:border-indigo-500 rounded-xl text-left transition-all group"
                                >
                                  <div className="flex items-center justify-between">
                                    <span className="font-bold text-xs text-white group-hover:text-indigo-300">{s.day}</span>
                                    <span className="text-[11px] font-mono text-emerald-400 font-semibold">{s.time}</span>
                                  </div>
                                  <div className="text-[11px] text-slate-400 mt-1">{s.doctor}</div>
                                  <div className="mt-2 text-[10px] text-indigo-400 font-semibold group-hover:translate-x-1 transition-transform flex items-center gap-1">
                                    <span>One-Click Confirm</span>
                                    <ChevronRight className="w-3 h-3" />
                                  </div>
                                </button>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Rich Embed: Services Catalog List */}
                        {msg.type === 'service_list' && (
                          <div className="mt-4 pt-3 border-t border-slate-700 space-y-2">
                            {mockServices.slice(0, 4).map((srv) => (
                              <div
                                key={srv.id}
                                className="bg-slate-900/80 hover:bg-slate-900 border border-slate-700/80 p-3 rounded-xl flex items-center justify-between gap-3 transition-colors"
                              >
                                <div>
                                  <div className="font-bold text-white text-xs">{srv.name}</div>
                                  <div className="text-[11px] text-slate-400">
                                    {srv.durationMinutes} mins • <strong className="text-emerald-400 font-semibold">${srv.price}</strong>
                                  </div>
                                </div>
                                <button
                                  onClick={() => {
                                    handleUserSubmit(`I want to book the ${srv.name}`);
                                  }}
                                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shrink-0 shadow-xs transition-colors"
                                >
                                  Book Slot
                                </button>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Rich Embed: Booking Confirmation Card with Calendar Download */}
                        {msg.type === 'confirmation_card' && msg.data && (
                          <div className="mt-4 p-4 bg-emerald-950/80 border border-emerald-700/80 rounded-2xl space-y-3 text-emerald-100">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 font-bold text-sm text-emerald-300">
                                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                                Confirmed Appointment Ref #{msg.data.refCode}
                              </div>
                              <span className="text-[11px] font-mono bg-emerald-900/90 text-emerald-300 px-2 py-0.5 rounded border border-emerald-700">
                                Live In Clinic Calendar
                              </span>
                            </div>

                            <div className="grid grid-cols-2 gap-2 text-xs bg-emerald-900/40 p-3 rounded-xl border border-emerald-800/60">
                              <div>
                                <span className="text-slate-400 text-[10px] uppercase">Service</span>
                                <div className="font-bold text-white">{msg.data.serviceName}</div>
                              </div>
                              <div>
                                <span className="text-slate-400 text-[10px] uppercase">Attending Specialist</span>
                                <div className="font-bold text-white">{msg.data.doctor}</div>
                              </div>
                              <div>
                                <span className="text-slate-400 text-[10px] uppercase">Day & Time</span>
                                <div className="font-bold text-emerald-300">{msg.data.day} • {msg.data.time}</div>
                              </div>
                              <div>
                                <span className="text-slate-400 text-[10px] uppercase">Pricing</span>
                                <div className="font-bold text-white">${msg.data.price} (or insurance copay)</div>
                              </div>
                            </div>

                            <div className="flex gap-2 pt-1">
                              <button
                                onClick={() => handleDownloadCalendar(msg.data)}
                                className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                              >
                                <Download className="w-3.5 h-3.5" />
                                Add to Google / Apple Calendar (.ics)
                              </button>
                            </div>
                          </div>
                        )}

                        {/* Rich Embed: Operating Hours & Directions Card */}
                        {msg.type === 'hours_card' && (
                          <div className="mt-4 p-4 bg-slate-900/90 rounded-2xl border border-slate-700/80 space-y-2.5 text-xs">
                            <div className="flex items-center justify-between font-semibold pb-1.5 border-b border-slate-800">
                              <span className="text-slate-300">Mon – Thu</span>
                              <span className="text-white font-bold">8:00 AM – 6:00 PM</span>
                            </div>
                            <div className="flex items-center justify-between font-semibold pb-1.5 border-b border-slate-800">
                              <span className="text-slate-300">Friday</span>
                              <span className="text-white font-bold">8:00 AM – 5:00 PM</span>
                            </div>
                            <div className="flex items-center justify-between font-semibold pb-1.5 border-b border-slate-800">
                              <span className="text-slate-300">Saturday</span>
                              <span className="text-emerald-400 font-bold">9:00 AM – 2:00 PM (Walk-ins Welcome)</span>
                            </div>
                            <div className="flex items-center justify-between font-semibold">
                              <span className="text-slate-300">Sunday</span>
                              <span className="text-rose-400 font-semibold">Closed (24/7 AI On-Duty)</span>
                            </div>
                            <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-1.5">
                              <MapPin className="w-3.5 h-3.5 text-indigo-400" />
                              <span>{config.address} • 2hr Free Parking</span>
                            </div>
                          </div>
                        )}

                        {/* Rich Embed: Insurance Verification Card */}
                        {msg.type === 'insurance_card' && msg.data && (
                          <div className="mt-4 p-4 bg-slate-900/90 rounded-2xl border border-slate-700/80 space-y-3 text-xs">
                            <div className="font-bold text-white flex items-center gap-1.5 text-xs">
                              <ShieldCheck className="w-4 h-4 text-emerald-400" />
                              In-Network Insurances Accepted:
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                              {msg.data.acceptedCarriers.map((carrier: string, i: number) => (
                                <div key={i} className="p-2 bg-slate-800/80 rounded-lg text-slate-200 text-[11px] flex items-center gap-1.5 border border-slate-700/50">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                                  <span>{carrier}</span>
                                </div>
                              ))}
                            </div>
                            <div className="p-2 bg-indigo-950/60 rounded-lg border border-indigo-800/50 text-[11px] text-indigo-200">
                              💳 HSA & FSA cards accepted directly at front desk terminal or online.
                            </div>
                          </div>
                        )}

                        {/* Rich Embed: Emergency Banner */}
                        {msg.type === 'emergency_banner' && msg.data && (
                          <div className="mt-4 p-4 bg-rose-950/90 border border-rose-700/80 rounded-2xl space-y-2.5 text-xs text-rose-100">
                            <div className="flex items-center gap-2 font-bold text-rose-300 text-sm">
                              <AlertTriangle className="w-5 h-5 text-rose-400" />
                              {msg.data.title}
                            </div>
                            <p className="text-xs text-rose-200">{msg.data.urgentInstruction}</p>
                            <a
                              href={`tel:${msg.data.phone}`}
                              className="inline-flex items-center justify-center gap-2 w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl transition-colors shadow-md"
                            >
                              <PhoneCall className="w-4 h-4" />
                              1-Tap Emergency Hotline: {msg.data.phone}
                            </a>
                          </div>
                        )}

                        {/* Rich Embed: Reschedule Tool */}
                        {msg.type === 'reschedule_tool' && (
                          <div className="mt-4 p-4 bg-slate-900/90 border border-slate-700/80 rounded-2xl space-y-3 text-xs">
                            <div className="font-bold text-white text-xs">Lookup Booking to Reschedule:</div>
                            <div className="flex gap-2">
                              <input
                                type="text"
                                placeholder="Enter Reference Code (e.g. #APX-4829)"
                                className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white"
                              />
                              <button
                                onClick={() => {
                                  showToast({
                                    type: 'success',
                                    title: 'Booking Located',
                                    message: 'Appointment found. Choose your new preferred time slot below.'
                                  });
                                  handleUserSubmit('Show open slots for next Monday or Tuesday');
                                }}
                                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl text-xs transition-colors"
                              >
                                Find
                              </button>
                            </div>
                          </div>
                        )}

                        {/* Rich Embed: Attending Physicians Roster */}
                        {msg.type === 'provider_card' && msg.data && (
                          <div className="mt-4 pt-3 border-t border-slate-700 space-y-2">
                            {msg.data.map((prov: any, idx: number) => (
                              <div key={idx} className="p-3 bg-slate-900/80 rounded-xl border border-slate-700/80 flex items-center justify-between gap-2">
                                <div>
                                  <div className="font-bold text-xs text-white">{prov.name}</div>
                                  <div className="text-[11px] text-indigo-300">{prov.specialty}</div>
                                  <div className="text-[10px] text-slate-400 mt-0.5">⭐ {prov.rating} • Available: {prov.available}</div>
                                </div>
                                <button
                                  onClick={() => handleUserSubmit(`Book an appointment with ${prov.name}`)}
                                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg shrink-0 transition-colors"
                                >
                                  Schedule
                                </button>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Rich Embed: In-Chat Human Callback Request */}
                        {msg.type === 'lead_form' && (
                          <div className="mt-4 p-4 bg-slate-900/95 border border-indigo-500/50 rounded-2xl space-y-3">
                            <div className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                              <UserCheck className="w-4 h-4 text-indigo-400" />
                              Front Desk Immediate Callback Request
                            </div>
                            {leadSubmitted ? (
                              <div className="text-xs text-emerald-300 font-medium flex items-center gap-2 bg-emerald-950/60 border border-emerald-800 p-3 rounded-xl">
                                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                                <span>Request dispatched to on-duty staff! We will call or text your phone shortly.</span>
                              </div>
                            ) : (
                              <form onSubmit={handleLeadSubmit} className="space-y-2">
                                <input
                                  type="text"
                                  value={leadFormName}
                                  onChange={(e) => setLeadFormName(e.target.value)}
                                  placeholder="Your full name"
                                  className="w-full px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                                />
                                <input
                                  type="tel"
                                  value={leadFormPhone}
                                  onChange={(e) => setLeadFormPhone(e.target.value)}
                                  placeholder="Phone number (+1 555-000-0000)"
                                  className="w-full px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                                />
                                <input
                                  type="email"
                                  value={leadFormEmail}
                                  onChange={(e) => setLeadFormEmail(e.target.value)}
                                  placeholder="Email address (optional)"
                                  className="w-full px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                                />
                                <button
                                  type="submit"
                                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-md transition-colors"
                                >
                                  Dispatch Urgent Callback to Front Desk
                                </button>
                              </form>
                            )}
                          </div>
                        )}

                        {/* Suggested Follow-Up Prompt Chips */}
                        {msg.aiAnalysis?.suggestedFollowUps && msg.aiAnalysis.suggestedFollowUps.length > 0 && (
                          <div className="mt-3 pt-2.5 border-t border-slate-700/60 flex flex-wrap gap-1.5">
                            {msg.aiAnalysis.suggestedFollowUps.map((chip, cIdx) => (
                              <button
                                key={cIdx}
                                onClick={() => handleUserSubmit(chip)}
                                className="text-[11px] px-2.5 py-1 rounded-full bg-slate-700/60 hover:bg-indigo-600 text-slate-300 hover:text-white transition-all border border-slate-600/50"
                              >
                                {chip}
                              </button>
                            ))}
                          </div>
                        )}

                      </div>

                      {/* Timestamp & Feedback status */}
                      <div className={`text-[10px] text-slate-500 px-1 flex items-center gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <span>{msg.timestamp}</span>
                        {msg.sender === 'ai' && (
                          <span className="text-emerald-400 text-[10px] font-mono">
                            • 100% relevant
                          </span>
                        )}
                      </div>

                    </div>
                  </div>
                ))}

                {/* Live Speech Recognition Transcript Indicator */}
                {interimSpeechText && (
                  <div className="flex items-center gap-3 justify-end">
                    <div className="bg-indigo-950/80 border border-indigo-500/50 text-indigo-200 px-4 py-2.5 rounded-2xl text-xs animate-pulse flex items-center gap-2">
                      <Mic className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{interimSpeechText}...</span>
                    </div>
                  </div>
                )}

                {/* Typing Animation */}
                {isTyping && (
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-600 flex items-center justify-center text-white shrink-0 shadow-md">
                      <Bot className="w-4 h-4" />
                    </div>
                    <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl rounded-bl-xs px-4 py-3 shadow-md flex items-center gap-2.5">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></div>
                      </div>
                      <span className="text-xs text-slate-400">{config.aiName || 'Aria'} is verifying schedules & clinical policies...</span>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Quick Prompt Suggestions Bar */}
              <div className="p-2.5 bg-slate-950/80 border-t border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar">
                {[
                  { label: 'Book an Appointment', icon: <Calendar className="w-3.5 h-3.5" /> },
                  { label: 'Check Pricing & Services', icon: <Sparkles className="w-3.5 h-3.5" /> },
                  { label: 'Do you accept my insurance?', icon: <ShieldCheck className="w-3.5 h-3.5" /> },
                  { label: 'Operating Hours & Parking', icon: <MapPin className="w-3.5 h-3.5" /> },
                  { label: 'Talk to Human Front Desk', icon: <UserCheck className="w-3.5 h-3.5" /> }
                ].map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleUserSubmit(item.label)}
                    className="whitespace-nowrap px-3 py-1.5 text-xs font-semibold rounded-xl bg-slate-800/90 hover:bg-indigo-600 text-slate-300 hover:text-white transition-all flex items-center gap-1.5 border border-slate-700/80"
                  >
                    {item.icon}
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>

              {/* Chat & Voice Input Form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleUserSubmit(inputVal);
                }}
                className="p-3 sm:p-4 bg-slate-900 border-t border-slate-800 flex items-center gap-2.5"
              >
                {/* Microphone Speech Recognition Button */}
                <button
                  type="button"
                  onClick={toggleSpeechRecognition}
                  className={`p-3 rounded-xl border transition-all ${
                    isListeningMic
                      ? 'bg-emerald-500 text-white border-emerald-400 shadow-lg shadow-emerald-500/30 animate-pulse'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                  }`}
                  title={isListeningMic ? 'Stop Listening' : 'Speak into Microphone'}
                >
                  {isListeningMic ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
                </button>

                <input
                  type="text"
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  placeholder="Ask anything: doctor openings, prices, insurance, parking, rescheduling..."
                  className="flex-1 text-xs sm:text-sm bg-slate-800/90 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />

                <button
                  type="submit"
                  disabled={!inputVal.trim() || isTyping}
                  className="p-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-xl transition-all shadow-md shadow-indigo-600/30 shrink-0"
                  aria-label="Send message"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>

            </div>
          )}

        </div>

        {/* ================= RIGHT SIDEBAR: INTELLIGENCE & CLINIC DETAILS (DESKTOP) ================= */}
        <div className="hidden lg:flex w-84 flex-col gap-4">
          
          {/* Practice Details Card */}
          <div className="bg-slate-950 rounded-3xl border border-slate-800 p-5 space-y-4 shadow-xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold text-sm">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white leading-tight">{config.name}</h3>
                <p className="text-xs text-slate-400">{config.industry}</p>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-300 pt-2 border-t border-slate-800">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-slate-500" />
                <span>{config.phone}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-slate-500" />
                <span className="truncate">{config.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span>Mon-Fri: 8:00 AM - 6:00 PM</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => {
                  if (onLaunchBooking) onLaunchBooking();
                  else if (onBookService) onBookService();
                  else onNavigate('booking');
                }}
                className="w-full py-2.5 px-3 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Calendar className="w-4 h-4" />
                Open Full Interactive Scheduler
              </button>
            </div>
          </div>

          {/* AI Receptionist Real-Time Diagnostic Radar */}
          <div className="bg-slate-950 rounded-3xl border border-slate-800 p-5 space-y-3.5 shadow-xl">
            <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                Conversational Radar
              </span>
              <span className="text-emerald-400 text-[11px] font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                100% Zero-API Local
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800/80">
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Inference Speed</div>
                <div className="text-sm font-bold text-emerald-400 mt-0.5">{latestAnalysis.latencyMs}ms</div>
              </div>
              <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800/80">
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Intent Confidence</div>
                <div className="text-sm font-bold text-white mt-0.5">
                  {Math.round(latestAnalysis.confidence * 100)}%
                </div>
              </div>
              <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800/80">
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Data Privacy</div>
                <div className="text-sm font-bold text-indigo-300 mt-0.5">HIPAA / Zero-Leak</div>
              </div>
              <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800/80">
                <div className="text-[10px] text-slate-400 uppercase font-semibold">RAG Facts</div>
                <div className="text-sm font-bold text-white mt-0.5">
                  {(config.customKnowledge?.length || 4)} Rules Active
                </div>
              </div>
            </div>

            <div className="text-[11px] text-slate-400 bg-slate-900 p-3 rounded-2xl border border-slate-800/80 leading-relaxed">
              <div className="font-semibold text-slate-200 mb-1 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Warm Human Escalation
              </div>
              Caller inquiries requesting direct staff, emergencies, or billing are automatically routed to on-duty reception without delay.
            </div>
          </div>

          {/* Quick Navigate to Dashboard */}
          <div className="mt-auto">
            <button
              onClick={() => onNavigate('dashboard')}
              className="w-full py-3 px-4 bg-slate-800 hover:bg-slate-700 text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-colors"
            >
              <span>View Executive Dashboard</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
