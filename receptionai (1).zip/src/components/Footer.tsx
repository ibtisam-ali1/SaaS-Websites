import React, { useState } from 'react';
import { AppView } from '../types';
import { Bot, ShieldCheck, CheckCircle2, ArrowRight } from 'lucide-react';
import { useToast } from './Toast';

interface FooterProps {
  onNavigate: (view: AppView) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const { showToast } = useToast();

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      showToast({
        type: 'warning',
        title: 'Valid email required',
        message: 'Please enter a valid business email address.'
      });
      return;
    }
    showToast({
      type: 'success',
      title: 'Subscribed to Product Updates',
      message: `Weekly AI receptionist insights will be sent to ${email}.`
    });
    setEmail('');
  };

  return (
    <footer className="border-t border-slate-200 bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-12">
          
          {/* Brand & Mission */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-indigo-500 flex items-center justify-center text-white shadow-md">
                <Bot className="w-5 h-5" />
              </div>
              <span className="text-xl font-bold tracking-tight text-white">
                Reception<span className="text-indigo-400">AI</span>
              </span>
            </div>
            
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              The intelligent AI receptionist and appointment booking engine trusted by modern clinics, law firms, salons, and service leaders to capture leads and eliminate missed callers 24 hours a day.
            </p>

            {/* Trust and Compliance Badges */}
            <div className="pt-2 flex flex-wrap items-center gap-3 text-xs text-slate-400">
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800/80 border border-slate-700/60">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>HIPAA & SOC 2 Ready</span>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800/80 border border-slate-700/60">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>99.98% Uptime SLA</span>
              </div>
            </div>

            {/* Newsletter */}
            <form onSubmit={handleSubscribe} className="pt-2 space-y-2">
              <label htmlFor="newsletter-email" className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                Get monthly industry benchmarks
              </label>
              <div className="flex max-w-sm gap-2">
                <input
                  id="newsletter-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter business email"
                  className="flex-1 px-3 py-2 text-xs bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <button
                  type="submit"
                  className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium flex items-center gap-1 transition-colors"
                >
                  Join
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </form>
          </div>

          {/* Column 1: Product */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              Platform
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <button onClick={() => onNavigate('receptionist')} className="hover:text-white transition-colors">
                  AI Conversational Agent
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('booking')} className="hover:text-white transition-colors">
                  Smart Appointment Booking
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('dashboard')} className="hover:text-white transition-colors">
                  Business Admin Dashboard
                </button>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer transition-colors">
                  Voice Inbound Routing
                </span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer transition-colors">
                  Calendar & EHR Sync
                </span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer transition-colors">
                  Warm Human Escalation
                </span>
              </li>
            </ul>
          </div>

          {/* Column 2: Solutions */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              Solutions
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <button onClick={() => onNavigate('landing')} className="hover:text-white transition-colors">
                  Clinics & Healthcare
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('landing')} className="hover:text-white transition-colors">
                  Salons & Day Spas
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('landing')} className="hover:text-white transition-colors">
                  Law Firms & Attorneys
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('landing')} className="hover:text-white transition-colors">
                  Real Estate Agencies
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('landing')} className="hover:text-white transition-colors">
                  Home Services & HVAC
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('landing')} className="hover:text-white transition-colors">
                  Consulting Practices
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Trust & Portal */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              Portals
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <button
                  onClick={() => onNavigate('dashboard')}
                  className="inline-flex items-center gap-1.5 text-indigo-400 hover:text-indigo-300 font-medium"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Staff Login Portal
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('receptionist')}
                  className="hover:text-white transition-colors"
                >
                  Test Virtual Receptionist
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('booking')}
                  className="hover:text-white transition-colors"
                >
                  Public Client Booking
                </button>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer transition-colors">
                  Security Whitepaper
                </span>
              </li>
              <li>
                <span className="hover:text-white cursor-pointer transition-colors">
                  Privacy Policy & BAA
                </span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} ReceptionAI Technologies Inc. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span className="hover:text-slate-400 cursor-pointer">Privacy Policy</span>
            <span className="hover:text-slate-400 cursor-pointer">Terms of Service</span>
            <span className="hover:text-slate-400 cursor-pointer">Security Standards</span>
            <span className="hover:text-slate-400 cursor-pointer">HIPAA Notice</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
