import React, { useState } from 'react';
import { AppView } from '../types';
import { 
  Bot, 
  Sparkles, 
  Menu, 
  X, 
  Calendar, 
  LayoutDashboard, 
  ChevronRight,
  ShieldCheck,
  Headphones
} from 'lucide-react';

interface NavbarProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  onScrollToSection?: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate, onScrollToSection }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (sectionId: string) => {
    setMobileMenuOpen(false);
    if (currentView !== 'landing') {
      onNavigate('landing');
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(sectionId);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/90 backdrop-blur-md transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          
          {/* Logo */}
          <div className="flex items-center gap-8">
            <button
              onClick={() => onNavigate('landing')}
              className="flex items-center gap-2.5 text-left group focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-violet-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform duration-200">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-lg sm:text-xl font-bold tracking-tight text-slate-900">
                    Reception<span className="text-indigo-600">AI</span>
                  </span>
                  <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200/60">
                    <Sparkles className="w-2.5 h-2.5" /> 24/7 AI
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 font-medium -mt-1 hidden sm:block">
                  Virtual Receptionist & Booking
                </p>
              </div>
            </button>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center gap-1 text-sm font-medium text-slate-600">
              <button
                onClick={() => handleNavClick('features')}
                className="px-3 py-2 rounded-lg hover:text-slate-900 hover:bg-slate-100/70 transition-colors"
              >
                Features
              </button>
              <button
                onClick={() => handleNavClick('how-it-works')}
                className="px-3 py-2 rounded-lg hover:text-slate-900 hover:bg-slate-100/70 transition-colors"
              >
                How It Works
              </button>
              <button
                onClick={() => handleNavClick('solutions')}
                className="px-3 py-2 rounded-lg hover:text-slate-900 hover:bg-slate-100/70 transition-colors"
              >
                Solutions
              </button>
              <button
                onClick={() => handleNavClick('pricing')}
                className="px-3 py-2 rounded-lg hover:text-slate-900 hover:bg-slate-100/70 transition-colors"
              >
                Pricing
              </button>
              <button
                onClick={() => handleNavClick('faq')}
                className="px-3 py-2 rounded-lg hover:text-slate-900 hover:bg-slate-100/70 transition-colors"
              >
                FAQ
              </button>
            </nav>
          </div>

          {/* Right Action Controls */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Live AI Receptionist Button */}
            <button
              id="nav-try-receptionist-btn"
              onClick={() => onNavigate('receptionist')}
              className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg border transition-all ${
                currentView === 'receptionist'
                  ? 'bg-indigo-50 border-indigo-300 text-indigo-700 ring-2 ring-indigo-500/20'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300'
              }`}
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <Headphones className="w-3.5 h-3.5 text-indigo-600" />
              Try AI Receptionist
            </button>

            {/* Quick Book Appointment */}
            <button
              id="nav-book-appointment-btn"
              onClick={() => onNavigate('booking')}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg border transition-all ${
                currentView === 'booking'
                  ? 'bg-indigo-50 border-indigo-300 text-indigo-700 ring-2 ring-indigo-500/20'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300'
              }`}
            >
              <Calendar className="w-3.5 h-3.5 text-indigo-600" />
              Book Appointment
            </button>

            {/* Business Dashboard Portal Button */}
            <button
              id="nav-business-portal-btn"
              onClick={() => onNavigate('dashboard')}
              className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg shadow-sm text-white transition-all ${
                currentView === 'dashboard'
                  ? 'bg-slate-900 ring-2 ring-indigo-500'
                  : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-600/20'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              Business Dashboard
              <ChevronRight className="w-3.5 h-3.5 -mr-1" />
            </button>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={() => onNavigate('receptionist')}
              className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center gap-1"
            >
              <Headphones className="w-3.5 h-3.5" />
              AI Chat
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 shadow-xl">
          <div className="grid grid-cols-2 gap-2 pb-3 border-b border-slate-100">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate('receptionist');
              }}
              className="flex items-center justify-center gap-2 p-2.5 rounded-lg text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200"
            >
              <Headphones className="w-4 h-4" />
              AI Receptionist
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate('booking');
              }}
              className="flex items-center justify-center gap-2 p-2.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-800"
            >
              <Calendar className="w-4 h-4" />
              Book Slot
            </button>
          </div>

          <div className="flex flex-col space-y-1">
            <button
              onClick={() => handleNavClick('features')}
              className="text-left px-3 py-2 text-sm font-medium text-slate-700 rounded-lg hover:bg-slate-50"
            >
              Features
            </button>
            <button
              onClick={() => handleNavClick('how-it-works')}
              className="text-left px-3 py-2 text-sm font-medium text-slate-700 rounded-lg hover:bg-slate-50"
            >
              How It Works
            </button>
            <button
              onClick={() => handleNavClick('solutions')}
              className="text-left px-3 py-2 text-sm font-medium text-slate-700 rounded-lg hover:bg-slate-50"
            >
              Industry Solutions
            </button>
            <button
              onClick={() => handleNavClick('pricing')}
              className="text-left px-3 py-2 text-sm font-medium text-slate-700 rounded-lg hover:bg-slate-50"
            >
              Pricing
            </button>
            <button
              onClick={() => handleNavClick('faq')}
              className="text-left px-3 py-2 text-sm font-medium text-slate-700 rounded-lg hover:bg-slate-50"
            >
              FAQ
            </button>
          </div>

          <div className="pt-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onNavigate('dashboard');
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-indigo-600 text-white text-sm font-semibold shadow-sm"
            >
              <LayoutDashboard className="w-4 h-4" />
              Open Business Dashboard
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
