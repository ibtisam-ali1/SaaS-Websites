import React, { useState } from 'react';
import { AppView, DashboardSubView, BusinessConfig } from '../../types';
import { 
  LayoutDashboard, 
  MessageSquare, 
  Calendar, 
  Users, 
  BarChart3, 
  Settings, 
  Bot, 
  ExternalLink, 
  Bell, 
  Search, 
  Plus, 
  Menu, 
  X, 
  ChevronRight, 
  Building2,
  Headphones,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { useToast } from '../Toast';

interface DashboardLayoutProps {
  currentSubView: DashboardSubView;
  onSelectSubView: (subView: DashboardSubView) => void;
  onNavigate: (view: AppView) => void;
  businessConfig: BusinessConfig;
  unreadCount?: number;
  children: React.ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  currentSubView,
  onSelectSubView,
  onNavigate,
  businessConfig,
  unreadCount = 2,
  children
}) => {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const { showToast } = useToast();

  const navItems: { id: DashboardSubView; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'overview', label: 'Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
    { 
      id: 'conversations', 
      label: 'Conversations', 
      icon: <MessageSquare className="w-4 h-4" />,
      badge: unreadCount > 0 ? `${unreadCount}` : undefined 
    },
    { id: 'appointments', label: 'Appointments', icon: <Calendar className="w-4 h-4" /> },
    { id: 'leads', label: 'Leads', icon: <Users className="w-4 h-4" />, badge: '6' },
    { id: 'analytics', label: 'Analytics', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> }
  ];

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row">
      
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-slate-900 text-slate-300 border-r border-slate-800 shrink-0">
        
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold shadow-md shadow-indigo-600/30">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-white tracking-tight">Reception<span className="text-indigo-400">AI</span></span>
                <span className="text-[9px] bg-indigo-950 text-indigo-300 px-1 py-0.5 rounded border border-indigo-800">ADMIN</span>
              </div>
              <div className="text-[11px] text-slate-400 truncate max-w-[150px]">
                {businessConfig.name}
              </div>
            </div>
          </div>
        </div>

        {/* Live Receptionist Status Badge */}
        <div className="p-3 m-3 bg-slate-800/80 rounded-xl border border-slate-700/60">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 text-[11px]">AI Receptionist</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1 text-[11px]">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              Live Online
            </span>
          </div>
          <button
            onClick={() => onNavigate('receptionist')}
            className="mt-2 w-full py-1.5 px-2 bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors border border-indigo-500/30"
          >
            <Headphones className="w-3.5 h-3.5" />
            <span>Test Live Chat Agent</span>
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 px-3 py-2 space-y-1">
          {navItems.map((item) => {
            const isActive = currentSubView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectSubView(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  {item.icon}
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      isActive ? 'bg-white text-indigo-700' : 'bg-indigo-950 text-indigo-300 border border-indigo-800'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer Link to Public Site */}
        <div className="p-4 border-t border-slate-800 space-y-2">
          <button
            onClick={() => onNavigate('landing')}
            className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium flex items-center justify-between transition-colors"
          >
            <span className="flex items-center gap-2">
              <Building2 className="w-3.5 h-3.5 text-slate-400" />
              Public Landing Page
            </span>
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
          </button>

          <div className="text-[10px] text-slate-500 text-center">
            ReceptionAI SaaS Suite • v3.2
          </div>
        </div>

      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        
        {/* Top Header Bar */}
        <header className="bg-white border-b border-slate-200 px-4 sm:px-8 py-3 flex items-center justify-between shadow-xs sticky top-0 z-30">
          
          {/* Mobile Menu Trigger & Title */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileNavOpen(!mobileNavOpen)}
              className="p-1.5 text-slate-600 rounded-lg hover:bg-slate-100 md:hidden"
            >
              {mobileNavOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

            <div>
              <h1 className="text-base sm:text-lg font-bold text-slate-900 capitalize leading-tight">
                {currentSubView}
              </h1>
              <p className="text-xs text-slate-400 hidden sm:block">
                Manage your virtual receptionist, appointments, and pipeline.
              </p>
            </div>
          </div>

          {/* Right Top Header Actions */}
          <div className="flex items-center gap-3">
            
            {/* Quick Live Preview Button */}
            <button
              onClick={() => onNavigate('receptionist')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-semibold border border-indigo-200/70 transition-colors"
            >
              <Headphones className="w-3.5 h-3.5" />
              <span>Preview Receptionist</span>
            </button>

            {/* Notification Bell with simulated dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg relative transition-colors"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-indigo-600 rounded-full"></span>
              </button>

              {/* Notification Dropdown */}
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl border border-slate-200 shadow-xl p-3 z-50 space-y-2">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100 text-xs font-bold text-slate-900">
                    <span>Recent Notifications</span>
                    <span className="text-indigo-600 font-normal cursor-pointer" onClick={() => setShowNotifications(false)}>Clear</span>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="p-2 bg-slate-50 rounded-lg border border-slate-100">
                      <div className="font-semibold text-slate-900">New Appointment Booked</div>
                      <div className="text-slate-500 text-[11px]">Rachel Green for Dental Exam (12m ago)</div>
                    </div>
                    <div className="p-2 bg-slate-50 rounded-lg border border-slate-100">
                      <div className="font-semibold text-slate-900">Warm Human Handoff Requested</div>
                      <div className="text-slate-500 text-[11px]">Marcus Cole regarding Aetna prior auth (34m ago)</div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Staff profile icon */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-slate-900 text-white font-bold text-xs flex items-center justify-center">
                DR
              </div>
              <div className="hidden lg:block text-left text-xs">
                <div className="font-bold text-slate-900">Admin Staff</div>
                <div className="text-[10px] text-slate-400">Front Desk Manager</div>
              </div>
            </div>

          </div>

        </header>

        {/* Mobile Navigation Drawer */}
        {mobileNavOpen && (
          <div className="md:hidden bg-slate-900 text-white p-4 space-y-2 border-b border-slate-800">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onSelectSubView(item.id);
                  setMobileNavOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold ${
                  currentSubView === item.id ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {item.icon}
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full">{item.badge}</span>
                )}
              </button>
            ))}
            
            <div className="pt-2 border-t border-slate-800 flex gap-2">
              <button
                onClick={() => {
                  setMobileNavOpen(false);
                  onNavigate('receptionist');
                }}
                className="flex-1 py-2 bg-indigo-600 text-white rounded-lg text-xs font-semibold text-center"
              >
                Open AI Receptionist
              </button>
              <button
                onClick={() => {
                  setMobileNavOpen(false);
                  onNavigate('landing');
                }}
                className="py-2 px-3 bg-slate-800 text-slate-300 rounded-lg text-xs"
              >
                Landing
              </button>
            </div>
          </div>
        )}

        {/* Render View Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {children}
        </main>

      </div>

    </div>
  );
};
