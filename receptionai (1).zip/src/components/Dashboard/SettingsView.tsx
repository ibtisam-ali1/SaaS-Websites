import React, { useState } from 'react';
import { BusinessConfig, Service, WorkingHourDay } from '../../types';
import { mockServices } from '../../data/mockData';
import { 
  Building2, 
  Bot, 
  Clock, 
  Sparkles, 
  Bell, 
  Sliders, 
  Palette, 
  Save, 
  Plus, 
  Trash2, 
  Check, 
  Phone, 
  Mail, 
  MapPin, 
  Globe,
  Headphones,
  BookOpen,
  Search,
  HelpCircle
} from 'lucide-react';
import { useToast } from '../Toast';

interface SettingsViewProps {
  businessConfig: BusinessConfig;
  onUpdateConfig: (config: BusinessConfig) => void;
}

type SettingsTab = 'profile' | 'personality' | 'hours' | 'services' | 'booking' | 'knowledge' | 'notifications' | 'appearance';

export const SettingsView: React.FC<SettingsViewProps> = ({
  businessConfig: initialConfig,
  onUpdateConfig
}) => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  const [config, setConfig] = useState<BusinessConfig>(initialConfig);
  const [services, setServices] = useState<Service[]>(mockServices);

  // New service state
  const [newServiceName, setNewServiceName] = useState('');
  const [newServicePrice, setNewServicePrice] = useState('150');
  const [newServiceDuration, setNewServiceDuration] = useState('30');
  const [newServiceCategory, setNewServiceCategory] = useState('Consultation');

  // Custom knowledge state
  const [knowledgeSearch, setKnowledgeSearch] = useState('');
  const [newQQuestion, setNewQQuestion] = useState('');
  const [newQAnswer, setNewQAnswer] = useState('');
  const [newQCategory, setNewQCategory] = useState('General FAQ');

  const handleAddKnowledge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQQuestion.trim() || !newQAnswer.trim()) return;

    const newK = {
      id: `k-${Date.now()}`,
      question: newQQuestion.trim(),
      answer: newQAnswer.trim(),
      category: newQCategory
    };

    const updated = [...(config.customKnowledge || []), newK];
    const newConfig = { ...config, customKnowledge: updated };
    setConfig(newConfig);
    onUpdateConfig(newConfig);

    setNewQQuestion('');
    setNewQAnswer('');
    showToast({
      type: 'success',
      title: 'Knowledge Fact Added',
      message: 'AI Receptionist immediately learned this answer.'
    });
  };

  const handleDeleteKnowledge = (id: string) => {
    const updated = (config.customKnowledge || []).filter(k => k.id !== id);
    const newConfig = { ...config, customKnowledge: updated };
    setConfig(newConfig);
    onUpdateConfig(newConfig);
    showToast({
      type: 'info',
      title: 'Knowledge Fact Removed',
      message: 'AI knowledge base updated.'
    });
  };

  const handleSave = () => {
    onUpdateConfig(config);
    showToast({
      type: 'success',
      title: 'Settings Saved',
      message: 'All virtual receptionist preferences updated successfully.'
    });
  };

  const handleToggleDay = (dayIndex: number) => {
    const updatedDays = [...config.workingHours];
    updatedDays[dayIndex] = {
      ...updatedDays[dayIndex],
      isOpen: !updatedDays[dayIndex].isOpen
    };
    setConfig({ ...config, workingHours: updatedDays });
  };

  const handleAddService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newServiceName.trim()) return;

    const newSrv: Service = {
      id: `srv-${Date.now()}`,
      name: newServiceName.trim(),
      category: newServiceCategory,
      durationMinutes: parseInt(newServiceDuration) || 30,
      price: parseInt(newServicePrice) || 120,
      description: 'Custom client service configured in settings.',
      popular: false
    };

    setServices([...services, newSrv]);
    setNewServiceName('');
    showToast({
      type: 'success',
      title: 'Service Added',
      message: `${newSrv.name} is now bookable by AI Receptionist.`
    });
  };

  const handleDeleteService = (id: string) => {
    setServices(services.filter((s) => s.id !== id));
    showToast({
      type: 'info',
      title: 'Service Removed',
      message: 'Service catalog updated.'
    });
  };

  const tabs = [
    { id: 'profile', label: 'Business Profile', icon: <Building2 className="w-4 h-4" /> },
    { id: 'personality', label: 'AI Persona & Voice', icon: <Bot className="w-4 h-4" /> },
    { id: 'hours', label: 'Working Hours', icon: <Clock className="w-4 h-4" /> },
    { id: 'services', label: 'Services Catalog', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'booking', label: 'Booking Rules', icon: <Sliders className="w-4 h-4" /> },
    { id: 'knowledge', label: 'AI Knowledge Base (RAG)', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'notifications', label: 'Notifications & Alerts', icon: <Bell className="w-4 h-4" /> },
    { id: 'appearance', label: 'Widget Appearance', icon: <Palette className="w-4 h-4" /> }
  ];

  return (
    <div className="space-y-6">
      
      {/* Header and Save Button */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Virtual Receptionist Configuration
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Customize practice guidelines, AI voice tone, schedule availability, and customer intake rules.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md shadow-indigo-600/20 transition-all"
        >
          <Save className="w-4 h-4" />
          Save Changes
        </button>
      </div>

      {/* Main Settings Container */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col md:flex-row min-h-[600px]">
        
        {/* Navigation Sidebar */}
        <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-slate-200 bg-slate-50/50 p-4 space-y-1 shrink-0">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as SettingsTab)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-left transition-all ${
                activeTab === tab.id
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Tab Content Panel */}
        <div className="flex-1 p-6 sm:p-8 overflow-y-auto">
          
          {/* TAB 1: BUSINESS PROFILE */}
          {activeTab === 'profile' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Practice & Business Profile</h3>
                <p className="text-xs text-slate-500">This information is shared by Aria when callers ask about your business.</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Business Name</label>
                  <input
                    type="text"
                    value={config.name}
                    onChange={(e) => setConfig({ ...config, name: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Industry</label>
                    <select
                      value={config.industry}
                      onChange={(e) => setConfig({ ...config, industry: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900"
                    >
                      <option value="Medical & Healthcare">Medical & Healthcare</option>
                      <option value="Dental Clinic">Dental Clinic</option>
                      <option value="Legal & Law Firm">Legal & Law Firm</option>
                      <option value="Salon & Luxury Spa">Salon & Luxury Spa</option>
                      <option value="Real Estate">Real Estate</option>
                      <option value="Consulting & Accounting">Consulting & Accounting</option>
                      <option value="Home & Contractor Services">Home & Contractor Services</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Phone Number</label>
                    <input
                      type="text"
                      value={config.phone}
                      onChange={(e) => setConfig({ ...config, phone: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Physical Address</label>
                  <input
                    type="text"
                    value={config.address}
                    onChange={(e) => setConfig({ ...config, address: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Public Email</label>
                    <input
                      type="email"
                      value={config.email}
                      onChange={(e) => setConfig({ ...config, email: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Timezone</label>
                    <select
                      value={config.timezone}
                      onChange={(e) => setConfig({ ...config, timezone: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900"
                    >
                      <option value="America/Los_Angeles">Pacific Time (PT)</option>
                      <option value="America/Denver">Mountain Time (MT)</option>
                      <option value="America/Chicago">Central Time (CT)</option>
                      <option value="America/New_York">Eastern Time (ET)</option>
                      <option value="Europe/London">London (GMT)</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: AI PERSONALITY & VOICE */}
          {activeTab === 'personality' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h3 className="text-lg font-bold text-slate-900">AI Personality & Voice Synthesis</h3>
                <p className="text-xs text-slate-500">Tune how the virtual receptionist sounds, speaks, and behaves during interactions.</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-2">Receptionist Tone</label>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: 'Empathetic & Warm', desc: 'Compassionate, patient, ideal for clinics and salons.' },
                      { id: 'Formal & Professional', desc: 'Crisp, articulate, ideal for law firms & wealth advisors.' },
                      { id: 'Concise & Efficient', desc: 'Fast, punchy, ideal for emergency contractors & home services.' }
                    ].map((tone) => (
                      <div
                        key={tone.id}
                        onClick={() => setConfig({ ...config, aiTone: tone.id })}
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                          config.aiTone === tone.id
                            ? 'border-indigo-600 bg-indigo-50/50 ring-2 ring-indigo-500/20 shadow-xs'
                            : 'border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <div className="font-bold text-xs text-slate-900">{tone.id}</div>
                        <div className="text-[11px] text-slate-500 mt-1 leading-snug">{tone.desc}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Synthetic Voice Persona</label>
                    <select
                      value={config.aiVoice}
                      onChange={(e) => setConfig({ ...config, aiVoice: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900"
                    >
                      <option value="Aria (Warm American Female)">Aria (Warm American Female)</option>
                      <option value="Marcus (Executive American Male)">Marcus (Executive American Male)</option>
                      <option value="Elena (Polished British Female)">Elena (Polished British Female)</option>
                      <option value="Julian (Calm Neutral Male)">Julian (Calm Neutral Male)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Human Handoff Threshold</label>
                    <select
                      value={config.escalationThreshold}
                      onChange={(e) => setConfig({ ...config, escalationThreshold: e.target.value })}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900"
                    >
                      <option value="immediate">Immediate upon frustration or request</option>
                      <option value="after_2_failures">After 2 unsuccessful answers</option>
                      <option value="complex_only">Only for complex clinical/billing topics</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                    Custom Receptionist System Instructions
                  </label>
                  <textarea
                    rows={4}
                    value={config.systemPrompt}
                    onChange={(e) => setConfig({ ...config, systemPrompt: e.target.value })}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none"
                  ></textarea>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: WORKING HOURS */}
          {activeTab === 'hours' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Office Schedule & Hours</h3>
                <p className="text-xs text-slate-500">ReceptionAI answers 24/7, but only offers booking slots during business open hours.</p>
              </div>

              <div className="space-y-3">
                {config.workingHours.map((wh, idx) => (
                  <div
                    key={wh.day}
                    className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3 w-32">
                      <input
                        type="checkbox"
                        checked={wh.isOpen}
                        onChange={() => handleToggleDay(idx)}
                        className="rounded text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className={`font-bold ${wh.isOpen ? 'text-slate-900' : 'text-slate-400'}`}>
                        {wh.day}
                      </span>
                    </div>

                    {wh.isOpen ? (
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-700">{wh.openTime}</span>
                        <span className="text-slate-400">to</span>
                        <span className="font-semibold text-slate-700">{wh.closeTime}</span>
                      </div>
                    ) : (
                      <span className="text-rose-500 font-semibold">Closed for Walk-Ins</span>
                    )}

                    <span className="text-[11px] text-slate-400">
                      {wh.isOpen ? 'AI Books In-Clinic' : 'AI Captures Leads'}
                    </span>
                  </div>
                ))}
              </div>

              <div className="p-4 bg-indigo-50/70 rounded-2xl border border-indigo-200/60 text-xs text-indigo-900">
                <span className="font-bold">After-Hours AI Protocol: </span>
                When callers dial after hours, Aria answers immediately, captures customer contact details, answers FAQ regarding parking and pricing, and schedules next-day appointments.
              </div>
            </div>
          )}

          {/* TAB 4: SERVICES CATALOG */}
          {activeTab === 'services' && (
            <div className="space-y-6 max-w-2xl">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-slate-900">Service Offerings & Prices</h3>
                  <p className="text-xs text-slate-500">Services that ReceptionAI presents and books for callers.</p>
                </div>
              </div>

              {/* Service list */}
              <div className="space-y-3">
                {services.map((srv) => (
                  <div
                    key={srv.id}
                    className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between gap-4"
                  >
                    <div>
                      <div className="font-bold text-slate-900 text-xs sm:text-sm">{srv.name}</div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        {srv.category} • {srv.durationMinutes} mins • ${srv.price}
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteService(srv.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-200/70"
                      title="Remove service"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Add New Service Form */}
              <form onSubmit={handleAddService} className="p-4 bg-white rounded-2xl border border-dashed border-slate-300 space-y-3">
                <h4 className="text-xs font-bold uppercase text-slate-700">Add New Service</h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input
                    type="text"
                    value={newServiceName}
                    onChange={(e) => setNewServiceName(e.target.value)}
                    placeholder="Service Name (e.g. Whitening)"
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                  />
                  <input
                    type="number"
                    value={newServicePrice}
                    onChange={(e) => setNewServicePrice(e.target.value)}
                    placeholder="Price ($)"
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                  />
                  <input
                    type="number"
                    value={newServiceDuration}
                    onChange={(e) => setNewServiceDuration(e.target.value)}
                    placeholder="Duration (minutes)"
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                  />
                </div>
                <button
                  type="submit"
                  disabled={!newServiceName.trim()}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-xs"
                >
                  + Add Service to AI
                </button>
              </form>
            </div>
          )}

          {/* TAB 5: BOOKING RULES */}
          {activeTab === 'booking' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Booking Logic & Buffer Constraints</h3>
                <p className="text-xs text-slate-500">Prevent doctor double-booking and maintain room sanitation buffer time.</p>
              </div>

              <div className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold uppercase text-slate-600 mb-1">Appointment Buffer Time</label>
                  <select
                    value={config.bookingBufferMinutes}
                    onChange={(e) => setConfig({ ...config, bookingBufferMinutes: parseInt(e.target.value) })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900"
                  >
                    <option value={0}>No buffer (Back-to-back)</option>
                    <option value={10}>10 minutes buffer</option>
                    <option value={15}>15 minutes buffer (Recommended)</option>
                    <option value={30}>30 minutes buffer</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold uppercase text-slate-600 mb-1">Max Advance Booking Window</label>
                  <select
                    value={config.maxAdvanceBookingDays}
                    onChange={(e) => setConfig({ ...config, maxAdvanceBookingDays: parseInt(e.target.value) })}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900"
                  >
                    <option value={14}>Up to 14 days in advance</option>
                    <option value={30}>Up to 30 days in advance</option>
                    <option value={60}>Up to 60 days in advance</option>
                    <option value={90}>Up to 90 days in advance</option>
                  </select>
                </div>

                <div className="pt-2">
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900">Instant Calendar Sync</div>
                      <div className="text-slate-500 text-[11px]">Sync bookings immediately with Google Calendar, Outlook, and Dentrix.</div>
                    </div>
                    <span className="text-emerald-600 font-bold bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                      Active
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: KNOWLEDGE BASE (RAG) */}
          {activeTab === 'knowledge' && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-indigo-600" />
                  AI Knowledge Base & Custom RAG Facts
                </h3>
                <p className="text-xs text-slate-500">
                  Teach your virtual receptionist custom answers for questions specific to your clinic, law firm, or spa.
                  Answers are applied instantly with zero API calls.
                </p>
              </div>

              {/* Add New Knowledge Fact Card */}
              <form onSubmit={handleAddKnowledge} className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3.5">
                <div className="font-bold text-xs text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Plus className="w-3.5 h-3.5 text-indigo-600" />
                  Add New Practice Fact / Q&A Rule
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Frequently Asked Question / Topic</label>
                    <input
                      type="text"
                      placeholder="e.g. Do you have a student or military discount?"
                      value={newQQuestion}
                      onChange={(e) => setNewQQuestion(e.target.value)}
                      className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Category</label>
                    <select
                      value={newQCategory}
                      onChange={(e) => setNewQCategory(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-indigo-500"
                    >
                      <option value="General FAQ">General FAQ</option>
                      <option value="Pricing & Discounts">Pricing & Discounts</option>
                      <option value="Location & Parking">Location & Parking</option>
                      <option value="Clinic Policies">Clinic Policies</option>
                      <option value="Language Support">Language Support</option>
                      <option value="Specialists">Specialists</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Accurate AI Receptionist Answer</label>
                  <textarea
                    rows={3}
                    placeholder="e.g. Yes! We offer a 10% discount for students and active military personnel with valid ID on all out-of-pocket services."
                    value={newQAnswer}
                    onChange={(e) => setNewQAnswer(e.target.value)}
                    className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-indigo-500"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Save to AI Knowledge Base
                  </button>
                </div>
              </form>

              {/* Search Knowledge Base */}
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search existing knowledge base facts..."
                  value={knowledgeSearch}
                  onChange={(e) => setKnowledgeSearch(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                />
              </div>

              {/* Existing Knowledge Base Items */}
              <div className="space-y-3">
                {((config.customKnowledge || []).filter(k => 
                  !knowledgeSearch || 
                  k.question.toLowerCase().includes(knowledgeSearch.toLowerCase()) || 
                  k.answer.toLowerCase().includes(knowledgeSearch.toLowerCase())
                )).map((item) => (
                  <div key={item.id} className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2 group hover:border-indigo-300 transition-all">
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                            {item.category}
                          </span>
                          <span className="text-xs font-bold text-slate-900">{item.question}</span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed pl-1">{item.answer}</p>
                      </div>

                      <button
                        onClick={() => handleDeleteKnowledge(item.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors shrink-0"
                        title="Delete Knowledge Rule"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}

                {(!config.customKnowledge || config.customKnowledge.length === 0) && (
                  <div className="p-8 text-center text-slate-400 border border-dashed border-slate-200 rounded-2xl text-xs">
                    No custom knowledge facts added yet. Add questions above to teach your receptionist custom answers!
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 6: NOTIFICATIONS */}
          {activeTab === 'notifications' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Alerts & SMS Notifications</h3>
                <p className="text-xs text-slate-500">Configure how and when your staff and patients receive updates.</p>
              </div>

              <div className="space-y-3">
                {[
                  { title: 'SMS Confirmation to Patient', desc: 'Sends immediate text message with date, time, and address.', state: config.smsNotificationsEnabled },
                  { title: 'Staff Escalation Notifications', desc: 'Text front desk manager when a caller requires urgent human handoff.', state: true },
                  { title: 'Daily Digest Email', desc: 'Daily morning email summarizing appointments and captured leads.', state: config.emailNotificationsEnabled }
                ].map((notif, nIdx) => (
                  <div
                    key={nIdx}
                    className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-bold text-xs text-slate-900">{notif.title}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{notif.desc}</div>
                    </div>
                    <input
                      type="checkbox"
                      defaultChecked={notif.state}
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: APPEARANCE */}
          {activeTab === 'appearance' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Website Widget Styling</h3>
                <p className="text-xs text-slate-500">Customize how ReceptionAI appears on your clinic or law firm website.</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-2">Theme Accent Color</label>
                  <div className="flex items-center gap-3">
                    {['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#0f172a'].map((col) => (
                      <div
                        key={col}
                        style={{ backgroundColor: col }}
                        className="w-9 h-9 rounded-xl cursor-pointer ring-2 ring-offset-2 ring-slate-200 hover:scale-105 transition-transform"
                      ></div>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Widget Header Headline</label>
                  <input
                    type="text"
                    defaultValue="Hi there! 👋 How can ReceptionAI help you today?"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                  />
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-slate-900">Floating Chat Launcher</div>
                    <div className="text-slate-500 text-[11px]">Position in bottom-right corner of client website.</div>
                  </div>
                  <span className="text-indigo-600 font-semibold">Bottom-Right</span>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
