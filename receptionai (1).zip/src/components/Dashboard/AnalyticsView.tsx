import React, { useState } from 'react';
import { mockAnalyticsData } from '../../data/mockData';
import { 
  TrendingUp, 
  BarChart3, 
  Clock, 
  Sparkles, 
  MessageSquare, 
  Calendar, 
  Users, 
  CheckCircle2, 
  ArrowUpRight, 
  PhoneCall, 
  AlertCircle,
  Lightbulb,
  ArrowRight
} from 'lucide-react';
import { useToast } from '../Toast';

export const AnalyticsView: React.FC = () => {
  const { showToast } = useToast();
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');
  const { summary, weeklyPerformance, hourlyHeatmap, aiInsights } = mockAnalyticsData;

  const channelDistribution = [
    { channel: 'AI Phone Voice Calls', percentage: 48, count: '884 calls' },
    { channel: 'Website Interactive Chat', percentage: 32, count: '589 inquiries' },
    { channel: 'SMS Two-Way Messaging', percentage: 14, count: '258 chats' },
    { channel: 'WhatsApp Concierge', percentage: 6, count: '111 chats' }
  ];

  const handleApplyInsight = (title: string) => {
    showToast({
      type: 'success',
      title: 'Insight Recommendation Applied',
      message: `Updated AI Knowledge base based on: "${title}".`
    });
  };

  return (
    <div className="space-y-8">
      
      {/* Header and Time Range Filter */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Performance Analytics & Intelligence
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Real-time analytics on patient inquiries, conversion funnel, and receptionist optimization.
          </p>
        </div>

        <div className="flex items-center gap-1 bg-slate-200/70 p-1 rounded-xl">
          {[
            { id: '7d', label: 'Last 7 Days' },
            { id: '30d', label: 'Last 30 Days' },
            { id: '90d', label: 'Quarterly' }
          ].map((r) => (
            <button
              key={r.id}
              onClick={() => setTimeRange(r.id as any)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                timeRange === r.id
                  ? 'bg-white text-indigo-700 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Handled</span>
            <MessageSquare className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-slate-900">{summary.totalConversations}</div>
          <div className="text-[11px] font-semibold text-emerald-600 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            <span>{summary.conversationsGrowth} vs previous period</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Confirmed Bookings</span>
            <Calendar className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-slate-900">{summary.appointmentsBooked}</div>
          <div className="text-[11px] font-semibold text-emerald-600 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            <span>{summary.appointmentsGrowth} booked</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Funnel Conversion Rate</span>
            <ArrowUpRight className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-slate-900">{summary.conversionRate}%</div>
          <div className="text-[11px] font-semibold text-emerald-600 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            <span>{summary.conversionGrowth} lift</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Captured Revenue</span>
            <span className="text-xs font-bold text-emerald-600">$</span>
          </div>
          <div className="text-2xl font-black text-slate-900">{summary.revenueOpportunity}</div>
          <div className="text-[11px] font-semibold text-emerald-600 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            <span>{summary.revenueGrowth} volume</span>
          </div>
        </div>
      </div>

      {/* AI Strategic Insights Section */}
      <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-indigo-950 rounded-3xl p-6 sm:p-8 text-white space-y-6 shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-indigo-800/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300">
              <Sparkles className="w-4 h-4 text-amber-300" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">AI Front Desk Diagnostics & Strategic Insights</h3>
              <p className="text-xs text-slate-300">Automated patterns discovered by analyzing 1,480 inbound caller interactions</p>
            </div>
          </div>
          <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-3 py-1 rounded-full">
            4 High Impact Recommendations
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {aiInsights.map((ins) => (
            <div
              key={ins.id}
              className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-5 space-y-4 hover:border-indigo-500/60 transition-all flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-900/60 text-indigo-300 border border-indigo-700">
                    {ins.tag}
                  </span>
                  <span className="text-[11px] font-bold text-amber-300">{ins.metric}</span>
                </div>

                <h4 className="font-bold text-sm text-white pt-1">{ins.title}</h4>
                <p className="text-xs text-slate-300 leading-relaxed">{ins.description}</p>
              </div>

              <button
                onClick={() => handleApplyInsight(ins.title)}
                className="w-full py-2 bg-indigo-600/40 hover:bg-indigo-600/70 border border-indigo-400/30 rounded-xl text-xs font-semibold text-indigo-200 flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>Apply Suggestion</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Grid: Peak Interaction Hours + Channel Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Peak Hours (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900">Hourly Interaction Heatmap</h3>
              <p className="text-xs text-slate-500">Inbound caller and chat distribution throughout the 24-hour cycle</p>
            </div>
            <span className="text-xs text-indigo-600 font-semibold flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              Peak: 11:00 AM – 2:00 PM
            </span>
          </div>

          <div className="space-y-2.5">
            {hourlyHeatmap.map((ph) => (
              <div key={ph.hour} className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-slate-600">
                  <span>{ph.hour}</span>
                  <span className="text-slate-900 font-bold">{ph.value} inquiries</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${Math.min(100, (ph.value / 120) * 100)}%` }}
                    className="h-full bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-full transition-all"
                  ></div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-indigo-50/60 rounded-xl border border-indigo-100 text-xs text-indigo-900">
            💡 ReceptionAI responded to <strong className="font-bold">100%</strong> of peak inquiries in under 1 second without putting callers on hold.
          </div>
        </div>

        {/* Channel Distribution & Front desk time saved (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Channel Split Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-base font-bold text-slate-900">Channel Breakdown</h3>
            <p className="text-xs text-slate-500">Inbound traffic origin across communication channels</p>

            <div className="space-y-3 pt-2">
              {channelDistribution.map((ch) => (
                <div key={ch.channel} className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold text-slate-700">
                    <span>{ch.channel}</span>
                    <span className="font-bold text-slate-900">{ch.percentage}% ({ch.count})</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${ch.percentage}%` }}
                      className="h-full bg-indigo-600 rounded-full"
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Front Desk Time Saved */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-3">
            <h3 className="text-base font-bold text-slate-900">Front Desk Time Saved</h3>
            <div className="text-3xl font-black text-indigo-600">32.4 hrs / wk</div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Equivalent to saving <strong>$3,200/month</strong> in front desk overtime and answering 100% of after-hours patient calls without voicemail dropoff.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
};
