import React from 'react';
import { 
  Appointment, 
  Conversation, 
  Lead, 
  DashboardSubView, 
  AppView 
} from '../../types';
import { mockAnalyticsData } from '../../data/mockData';
import { 
  MessageSquare, 
  Calendar, 
  Users, 
  TrendingUp, 
  DollarSign, 
  Clock, 
  ArrowUpRight, 
  Bot, 
  CheckCircle2, 
  AlertTriangle, 
  ChevronRight,
  Headphones,
  Plus,
  Sparkles
} from 'lucide-react';
import { useToast } from '../Toast';

interface OverviewViewProps {
  conversations: Conversation[];
  appointments: Appointment[];
  leads: Lead[];
  onSelectSubView: (subView: DashboardSubView) => void;
  onSelectConversation?: (convId: string) => void;
  onNavigate: (view: AppView) => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  conversations,
  appointments,
  leads,
  onSelectSubView,
  onSelectConversation,
  onNavigate
}) => {
  const { showToast } = useToast();
  const summary = mockAnalyticsData.summary;

  return (
    <div className="space-y-8">
      
      {/* Top Banner Alert / Quick Action */}
      <div className="bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden">
        <div className="space-y-2 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-800/60 text-indigo-300 text-xs font-semibold border border-indigo-700">
            <Sparkles className="w-3.5 h-3.5" />
            AI Receptionist System Operational
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
            Apex Health Virtual Front Desk
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            Aria answered <span className="font-bold text-white">184 inquiries</span> and booked <span className="font-bold text-emerald-400">42 appointments</span> over the last 72 hours with an average response time of 780ms.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 relative z-10">
          <button
            onClick={() => onNavigate('receptionist')}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md transition-colors"
          >
            <Headphones className="w-4 h-4" />
            Launch Live Receptionist
          </button>
          <button
            onClick={() => onNavigate('booking')}
            className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold border border-white/20 transition-colors"
          >
            New Booking
          </button>
        </div>
      </div>

      {/* 5 KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        
        {/* Metric 1: Total Conversations */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Conversations</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <MessageSquare className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">{summary.totalConversations}</div>
            <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 mt-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>{summary.conversationsGrowth} this month</span>
            </div>
          </div>
        </div>

        {/* Metric 2: Appointments Booked */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Appointments</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">{summary.appointmentsBooked}</div>
            <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 mt-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>{summary.appointmentsGrowth} booked</span>
            </div>
          </div>
        </div>

        {/* Metric 3: Leads Captured */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Leads Captured</span>
            <div className="w-8 h-8 rounded-lg bg-violet-50 text-violet-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">{summary.leadsCaptured}</div>
            <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 mt-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>{summary.leadsGrowth} hot leads</span>
            </div>
          </div>
        </div>

        {/* Metric 4: Conversion Rate */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Conversion Rate</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">{summary.conversionRate}%</div>
            <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 mt-1">
              <span>{summary.conversionGrowth} vs traditional</span>
            </div>
          </div>
        </div>

        {/* Metric 5: Revenue Pipeline Opportunity */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Pipeline Value</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">{summary.revenueOpportunity}</div>
            <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 mt-1">
              <span>{summary.revenueGrowth} captured</span>
            </div>
          </div>
        </div>

      </div>

      {/* Main Grid: Left (Recent Chats & Activity) + Right (Upcoming Appointments & AI Stats) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Recent Conversations & Lead Activity (7 cols) */}
        <div className="lg:col-span-7 space-y-8">
          
          {/* Recent Conversations Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Recent Customer Inquiries</h3>
                <p className="text-xs text-slate-500">Live conversations handled across web, call, and SMS</p>
              </div>
              <button
                onClick={() => onSelectSubView('conversations')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                View All Inbox &rarr;
              </button>
            </div>

            <div className="space-y-3">
              {conversations.slice(0, 4).map((conv) => (
                <div
                  key={conv.id}
                  onClick={() => {
                    if (onSelectConversation) onSelectConversation(conv.id);
                    onSelectSubView('conversations');
                  }}
                  className="p-3.5 rounded-xl border border-slate-100 hover:border-indigo-200 hover:bg-slate-50/70 cursor-pointer transition-all flex items-start gap-3"
                >
                  <img
                    src={conv.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100'}
                    alt={conv.customerName}
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-slate-900 text-sm truncate">
                        {conv.customerName}
                      </h4>
                      <span className="text-[10px] text-slate-400 shrink-0">{conv.lastMessageTime}</span>
                    </div>

                    <p className="text-xs text-slate-600 truncate mt-0.5">
                      {conv.lastMessage}
                    </p>

                    <div className="flex items-center gap-2 mt-2">
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        conv.status === 'appointment_booked'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : conv.status === 'escalated'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                      }`}>
                        {conv.status === 'appointment_booked' ? 'Booked' : conv.status === 'escalated' ? 'Needs Human' : 'Active AI'}
                      </span>

                      <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                        Channel: {conv.channel}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Lead Activity Chart Visualization */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Weekly Lead & Booking Flow</h3>
                <p className="text-xs text-slate-500">Conversations vs Confirmed Appointments by Day</p>
              </div>
              <span className="text-xs bg-slate-100 px-2.5 py-1 rounded-lg text-slate-600 font-medium">
                Last 7 Days
              </span>
            </div>

            {/* Custom SVG Weekly Bar Graphic */}
            <div className="pt-2">
              <div className="grid grid-cols-7 gap-2 sm:gap-4 items-end h-48 border-b border-slate-200 pb-3">
                {mockAnalyticsData.weeklyPerformance.map((day) => {
                  const maxVal = 330;
                  const convHeight = Math.round((day.conversations / maxVal) * 100);
                  const aptHeight = Math.round(((day.appointments * 3) / maxVal) * 100);

                  return (
                    <div key={day.day} className="flex flex-col items-center gap-1.5 h-full justify-end group">
                      <div className="flex items-end gap-1 w-full justify-center h-full">
                        {/* Conversations Bar */}
                        <div
                          style={{ height: `${convHeight}%` }}
                          className="w-3 sm:w-4 bg-indigo-500 rounded-t-sm group-hover:bg-indigo-600 transition-all relative"
                          title={`${day.day}: ${day.conversations} conversations`}
                        ></div>
                        {/* Bookings Bar */}
                        <div
                          style={{ height: `${aptHeight}%` }}
                          className="w-3 sm:w-4 bg-emerald-500 rounded-t-sm group-hover:bg-emerald-600 transition-all relative"
                          title={`${day.day}: ${day.appointments} booked`}
                        ></div>
                      </div>
                      <span className="text-[11px] font-bold text-slate-500 mt-1">{day.day}</span>
                    </div>
                  );
                })}
              </div>

              {/* Legend */}
              <div className="flex items-center justify-center gap-6 pt-4 text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-indigo-500"></div>
                  <span>Total Inquiries</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-emerald-500"></div>
                  <span>Confirmed Appointments</span>
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* Right Column: Upcoming Appointments & AI Performance (5 cols) */}
        <div className="lg:col-span-5 space-y-8">
          
          {/* Upcoming Appointments */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Upcoming Appointments</h3>
                <p className="text-xs text-slate-500">Next confirmed patient check-ins</p>
              </div>
              <button
                onClick={() => onSelectSubView('appointments')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
              >
                Schedule &rarr;
              </button>
            </div>

            <div className="space-y-3">
              {appointments.slice(0, 4).map((apt) => (
                <div
                  key={apt.id}
                  className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/60 flex items-start justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="font-bold text-slate-900 text-xs sm:text-sm">
                      {apt.customerName}
                    </div>
                    <div className="text-xs text-slate-600">{apt.serviceName}</div>
                    <div className="text-[11px] text-slate-400">{apt.staffName}</div>
                  </div>

                  <div className="text-right space-y-1 shrink-0">
                    <div className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg">
                      {apt.time}
                    </div>
                    <div className="text-[10px] text-slate-500">{apt.date}</div>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => onNavigate('booking')}
              className="w-full py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              Manual Booking Entry
            </button>
          </div>

          {/* AI Receptionist Health & Performance Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">AI Performance Health</h3>
              </div>
              <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded">
                Optimal (99.8%)
              </span>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <div className="flex justify-between text-slate-600 font-medium mb-1">
                  <span>AI Resolution Without Human Intervention</span>
                  <span className="font-bold text-slate-900">{summary.resolutionRate}</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full w-[94%]"></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-600 font-medium mb-1">
                  <span>Average Voice & Chat Latency</span>
                  <span className="font-bold text-slate-900">{summary.avgResponseTime}</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-600 rounded-full w-[88%]"></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-600 font-medium mb-1">
                  <span>Human Front Desk Escalation Rate</span>
                  <span className="font-bold text-slate-900">{summary.humanEscalationRate}</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500 rounded-full w-[6%]"></div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-500">Patient Satisfaction Score</span>
                <span className="font-extrabold text-amber-500 text-sm">★ {summary.csatScore}</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
