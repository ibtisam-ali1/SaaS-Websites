import React, { useState } from 'react';
import { Conversation, ChatMessage } from '../../types';
import { 
  Search, 
  Filter, 
  Bot, 
  UserCheck, 
  Send, 
  Phone, 
  Mail, 
  Tag, 
  Plus, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles,
  MessageSquare,
  ShieldCheck,
  Calendar,
  X
} from 'lucide-react';
import { useToast } from '../Toast';

interface ConversationsViewProps {
  conversations: Conversation[];
  selectedConvId?: string;
  onUpdateConversation?: (updated: Conversation) => void;
  onBookForCustomer?: (customerName: string) => void;
}

export const ConversationsView: React.FC<ConversationsViewProps> = ({
  conversations: initialConversations,
  selectedConvId,
  onUpdateConversation,
  onBookForCustomer
}) => {
  const { showToast } = useToast();
  const [conversations, setConversations] = useState<Conversation[]>(initialConversations);
  const [activeId, setActiveId] = useState<string>(selectedConvId || initialConversations[0]?.id || '');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTab, setFilterTab] = useState<'all' | 'escalated' | 'booked' | 'active'>('all');

  // Active conversation
  const activeConv = conversations.find((c) => c.id === activeId) || conversations[0];

  // Reply text input
  const [replyText, setReplyText] = useState('');

  // Internal note input
  const [newNote, setNewNote] = useState('');

  // New tag input
  const [newTagInput, setNewTagInput] = useState('');
  const [showTagInput, setShowTagInput] = useState(false);

  // Filter conversations
  const filteredConversations = conversations.filter((c) => {
    const matchesSearch = 
      c.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.lastMessage.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.customerPhone.includes(searchQuery);

    if (!matchesSearch) return false;
    if (filterTab === 'escalated') return c.status === 'escalated';
    if (filterTab === 'booked') return c.status === 'appointment_booked';
    if (filterTab === 'active') return c.status === 'active';
    return true;
  });

  // Toggle Human vs AI mode
  const handleToggleAiHandoff = () => {
    if (!activeConv) return;
    const newAiState = !activeConv.isAiHandled;
    const updatedConv: Conversation = {
      ...activeConv,
      isAiHandled: newAiState,
      status: newAiState ? 'active' : 'escalated'
    };

    updateConversationState(updatedConv);

    showToast({
      type: newAiState ? 'info' : 'warning',
      title: newAiState ? 'AI Auto-Pilot Resumed' : 'Human Front Desk Takeover Active',
      message: newAiState
        ? 'Aria has resumed automated replies for this caller.'
        : 'AI automated replies paused. You are now communicating directly with this caller.'
    });
  };

  // Send human message
  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !activeConv) return;

    const newMsg: ChatMessage = {
      id: `m-${Date.now()}`,
      sender: activeConv.isAiHandled ? 'ai' : 'human_agent',
      text: replyText.trim(),
      timestamp: 'Just now'
    };

    const updatedConv: Conversation = {
      ...activeConv,
      messages: [...activeConv.messages, newMsg],
      lastMessage: replyText.trim(),
      lastMessageTime: 'Just now'
    };

    updateConversationState(updatedConv);
    setReplyText('');

    showToast({
      type: 'success',
      title: 'Message Sent',
      message: `Delivered via ${activeConv.channel.toUpperCase()} to ${activeConv.customerName}.`
    });
  };

  // Add staff note
  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim() || !activeConv) return;

    const updatedNotes = [...activeConv.internalNotes, newNote.trim()];
    const updatedConv: Conversation = {
      ...activeConv,
      internalNotes: updatedNotes
    };

    updateConversationState(updatedConv);
    setNewNote('');
    showToast({
      type: 'info',
      title: 'Internal Note Saved',
      message: 'Visible only to clinic staff.'
    });
  };

  // Add tag
  const handleAddTag = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagInput.trim() || !activeConv) return;
    if (activeConv.tags.includes(newTagInput.trim())) return;

    const updatedTags = [...activeConv.tags, newTagInput.trim()];
    const updatedConv: Conversation = {
      ...activeConv,
      tags: updatedTags
    };

    updateConversationState(updatedConv);
    setNewTagInput('');
    setShowTagInput(false);
  };

  // Remove tag
  const handleRemoveTag = (tagToRemove: string) => {
    if (!activeConv) return;
    const updatedConv: Conversation = {
      ...activeConv,
      tags: activeConv.tags.filter((t) => t !== tagToRemove)
    };
    updateConversationState(updatedConv);
  };

  const updateConversationState = (updated: Conversation) => {
    setConversations((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    if (onUpdateConversation) {
      onUpdateConversation(updated);
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[calc(100vh-8.5rem)]">
      
      <div className="flex-1 flex overflow-hidden">
        
        {/* ================= LEFT COLUMN: CONVERSATION LIST ================= */}
        <div className="w-full md:w-80 lg:w-96 border-r border-slate-200 flex flex-col shrink-0 bg-slate-50/50">
          
          {/* Search bar & filter pills */}
          <div className="p-4 border-b border-slate-200 space-y-3 bg-white">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search patient or message..."
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pb-1">
              {[
                { id: 'all', label: 'All' },
                { id: 'escalated', label: 'Escalated' },
                { id: 'booked', label: 'Booked' },
                { id: 'active', label: 'AI Active' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setFilterTab(tab.id as any)}
                  className={`whitespace-nowrap px-2.5 py-1 text-[11px] font-semibold rounded-lg transition-all ${
                    filterTab === tab.id
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200/70'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Conversations Scrollable List */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
            {filteredConversations.length === 0 ? (
              <div className="p-6 text-center text-slate-400 text-xs">
                No matching conversations found.
              </div>
            ) : (
              filteredConversations.map((c) => {
                const isSelected = activeConv?.id === c.id;

                return (
                  <div
                    key={c.id}
                    onClick={() => setActiveId(c.id)}
                    className={`p-4 cursor-pointer transition-all flex items-start gap-3 ${
                      isSelected
                        ? 'bg-indigo-50/70 border-l-4 border-indigo-600'
                        : 'hover:bg-slate-100/60'
                    }`}
                  >
                    <div className="relative shrink-0">
                      <img
                        src={c.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100'}
                        alt={c.customerName}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200"
                      />
                      <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-white ${
                        c.isAiHandled ? 'bg-indigo-500' : 'bg-emerald-500'
                      }`}></span>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-slate-900 text-xs sm:text-sm truncate">
                          {c.customerName}
                        </h4>
                        <span className="text-[10px] text-slate-400 shrink-0">{c.lastMessageTime}</span>
                      </div>

                      <p className="text-xs text-slate-500 truncate mt-0.5">
                        {c.lastMessage}
                      </p>

                      <div className="flex items-center gap-1.5 mt-2">
                        <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-slate-200/70 text-slate-600">
                          {c.channel}
                        </span>

                        {c.status === 'escalated' && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200">
                            Needs Human
                          </span>
                        )}

                        {c.status === 'appointment_booked' && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                            Booked
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

        </div>

        {/* ================= MIDDLE: CONVERSATION DETAIL & TRANSCRIPT ================= */}
        {activeConv ? (
          <div className="flex-1 flex flex-col min-w-0 bg-white">
            
            {/* Conversation Header */}
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-white shrink-0">
              <div className="flex items-center gap-3">
                <img
                  src={activeConv.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100'}
                  alt={activeConv.customerName}
                  className="w-10 h-10 rounded-full object-cover border border-slate-200"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                      {activeConv.customerName}
                    </h3>
                    <span className="text-xs text-slate-400 font-mono">
                      {activeConv.customerPhone}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span>Channel: <strong className="capitalize">{activeConv.channel}</strong></span>
                    <span>•</span>
                    <span className="text-indigo-600 font-semibold">Lead Score: {activeConv.leadScore}/100</span>
                  </div>
                </div>
              </div>

              {/* AI vs Human Handoff Control */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleToggleAiHandoff}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                    activeConv.isAiHandled
                      ? 'bg-indigo-50 border-indigo-200 text-indigo-700'
                      : 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  }`}
                  title="Toggle between AI automated agent and human front desk takeover"
                >
                  {activeConv.isAiHandled ? (
                    <>
                      <Bot className="w-3.5 h-3.5" />
                      <span>Mode: AI Auto-Pilot</span>
                    </>
                  ) : (
                    <>
                      <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Mode: Human Staff Live</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* AI Paused Banner if in Human Mode */}
            {!activeConv.isAiHandled && (
              <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 text-xs text-amber-800 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>AI auto-responses are paused. You are currently chatting as the human front desk.</span>
                </div>
                <button
                  onClick={handleToggleAiHandoff}
                  className="font-bold text-amber-900 underline hover:text-amber-950"
                >
                  Resume AI
                </button>
              </div>
            )}

            {/* Chat Transcript */}
            <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 bg-slate-50/40">
              {activeConv.messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex gap-3 ${m.sender === 'user' ? 'justify-start' : 'justify-end'}`}
                >
                  {m.sender === 'user' && (
                    <img
                      src={activeConv.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100'}
                      alt="User"
                      className="w-7 h-7 rounded-full object-cover shrink-0 mt-0.5"
                    />
                  )}

                  <div className="space-y-1 max-w-[80%]">
                    <div
                      className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                        m.sender === 'user'
                          ? 'bg-white text-slate-800 border border-slate-200 rounded-tl-xs shadow-xs'
                          : m.sender === 'human_agent'
                          ? 'bg-emerald-600 text-white rounded-tr-xs shadow-xs'
                          : m.sender === 'system'
                          ? 'bg-amber-100 text-amber-900 rounded-xl mx-auto text-center border border-amber-200'
                          : 'bg-indigo-600 text-white rounded-tr-xs shadow-xs'
                      }`}
                    >
                      {/* Sender Indicator */}
                      {m.sender !== 'user' && m.sender !== 'system' && (
                        <div className="text-[10px] font-bold opacity-80 mb-1">
                          {m.sender === 'human_agent' ? 'Staff Agent' : 'Aria (AI)'}
                        </div>
                      )}
                      {m.text}
                    </div>

                    <div className={`text-[10px] text-slate-400 ${m.sender === 'user' ? 'text-left' : 'text-right'}`}>
                      {m.timestamp}
                    </div>
                  </div>

                  {m.sender === 'ai' && (
                    <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white shrink-0 mt-0.5">
                      <Bot className="w-4 h-4" />
                    </div>
                  )}

                  {m.sender === 'human_agent' && (
                    <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center text-white shrink-0 mt-0.5">
                      <UserCheck className="w-4 h-4" />
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Quick Canned Responses */}
            <div className="p-2 bg-slate-50 border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs">
              <span className="text-[10px] uppercase font-bold text-slate-400 px-2">Quick:</span>
              <button
                onClick={() => setReplyText("We have an opening this Friday at 10:00 AM with Dr. Lin. Would that suit your schedule?")}
                className="whitespace-nowrap px-2.5 py-1 bg-white hover:bg-slate-100 rounded-md border border-slate-200 text-slate-700"
              >
                Suggest Friday 10 AM
              </button>
              <button
                onClick={() => setReplyText("Our clinic accepts all major PPO plans. We can run your insurance verification upon check-in.")}
                className="whitespace-nowrap px-2.5 py-1 bg-white hover:bg-slate-100 rounded-md border border-slate-200 text-slate-700"
              >
                Insurance Info
              </button>
              <button
                onClick={() => setReplyText("Validated parking is available in the Sutter Square garage directly behind our office. Use validation code #774.")}
                className="whitespace-nowrap px-2.5 py-1 bg-white hover:bg-slate-100 rounded-md border border-slate-200 text-slate-700"
              >
                Parking Directions
              </button>
            </div>

            {/* Staff Reply Form */}
            <form onSubmit={handleSendReply} className="p-3 sm:p-4 border-t border-slate-200 bg-white flex items-center gap-2">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder={
                  activeConv.isAiHandled
                    ? "Type manual message or canned response..."
                    : "Type live human response as front desk staff..."
                }
                className="flex-1 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
              <button
                type="submit"
                disabled={!replyText.trim()}
                className="p-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white rounded-xl transition-colors shadow-xs"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center p-8 text-slate-400 text-xs">
            Select a conversation from the left to view transcript.
          </div>
        )}

        {/* ================= RIGHT: CUSTOMER INTEL & NOTES SIDEBAR (Desktop) ================= */}
        {activeConv && (
          <div className="hidden xl:flex w-72 border-l border-slate-200 flex-col p-5 space-y-6 shrink-0 bg-white overflow-y-auto">
            
            {/* Customer Details */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Patient Intelligence
              </h4>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2 text-xs">
                <div>
                  <span className="text-slate-400">Email:</span>
                  <div className="font-medium text-slate-800 truncate">{activeConv.customerEmail}</div>
                </div>
                <div>
                  <span className="text-slate-400">Phone:</span>
                  <div className="font-medium text-slate-800">{activeConv.customerPhone}</div>
                </div>
                <div>
                  <span className="text-slate-400">Estimated Pipeline:</span>
                  <div className="font-bold text-emerald-600">${activeConv.estimatedValue}</div>
                </div>
              </div>
            </div>

            {/* Interactive Tags */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Tags
                </h4>
                <button
                  onClick={() => setShowTagInput(!showTagInput)}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-0.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add
                </button>
              </div>

              {showTagInput && (
                <form onSubmit={handleAddTag} className="flex gap-1.5">
                  <input
                    type="text"
                    value={newTagInput}
                    onChange={(e) => setNewTagInput(e.target.value)}
                    placeholder="New tag..."
                    className="flex-1 text-xs px-2 py-1 bg-slate-50 border border-slate-200 rounded-lg text-slate-800"
                  />
                  <button
                    type="submit"
                    className="px-2 py-1 bg-indigo-600 text-white rounded-lg text-xs"
                  >
                    Save
                  </button>
                </form>
              )}

              <div className="flex flex-wrap gap-1.5">
                {activeConv.tags.map((tag, tIdx) => (
                  <span
                    key={tIdx}
                    className="inline-flex items-center gap-1 text-[11px] font-medium bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md border border-slate-200"
                  >
                    {tag}
                    <button
                      onClick={() => handleRemoveTag(tag)}
                      className="text-slate-400 hover:text-rose-500"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            </div>

            {/* Internal Staff Notes */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Internal Staff Notes
              </h4>

              <div className="space-y-2">
                {activeConv.internalNotes.map((note, nIdx) => (
                  <div
                    key={nIdx}
                    className="p-2.5 bg-amber-50/70 border border-amber-200/60 rounded-xl text-xs text-amber-900 leading-relaxed"
                  >
                    {note}
                  </div>
                ))}
              </div>

              <form onSubmit={handleAddNote} className="space-y-2 pt-1">
                <textarea
                  rows={2}
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Add a private staff note..."
                  className="w-full p-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                ></textarea>
                <button
                  type="submit"
                  disabled={!newNote.trim()}
                  className="w-full py-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white text-xs font-semibold rounded-lg transition-colors"
                >
                  Save Note
                </button>
              </form>
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
