import React, { useState } from 'react';
import { Appointment, StaffMember, Service } from '../../types';
import { mockStaff, mockServices } from '../../data/mockData';
import { 
  Calendar, 
  Clock, 
  User, 
  Search, 
  Filter, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  Plus, 
  Phone, 
  Mail, 
  MoreVertical,
  ChevronLeft,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { useToast } from '../Toast';

interface AppointmentsViewProps {
  appointments: Appointment[];
  onAddAppointment?: (apt: Appointment) => void;
  onUpdateAppointment?: (apt: Appointment) => void;
  onOpenBooking: () => void;
}

export const AppointmentsView: React.FC<AppointmentsViewProps> = ({
  appointments: initialAppointments,
  onAddAppointment,
  onUpdateAppointment,
  onOpenBooking
}) => {
  const { showToast } = useToast();
  const [appointments, setAppointments] = useState<Appointment[]>(initialAppointments);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [staffFilter, setStaffFilter] = useState<string>('All');

  // Quick Action Modal state
  const [selectedApt, setSelectedApt] = useState<Appointment | null>(null);

  // Filtered
  const filteredAppointments = appointments.filter((a) => {
    const matchesSearch =
      a.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.serviceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.customerPhone.includes(searchQuery);

    if (!matchesSearch) return false;
    if (statusFilter !== 'All' && a.status !== statusFilter.toLowerCase()) return false;
    if (staffFilter !== 'All' && a.staffName !== staffFilter) return false;
    return true;
  });

  const handleStatusChange = (aptId: string, newStatus: Appointment['status']) => {
    setAppointments((prev) =>
      prev.map((a) => (a.id === aptId ? { ...a, status: newStatus } : a))
    );
    if (selectedApt && selectedApt.id === aptId) {
      setSelectedApt((prev) => (prev ? { ...prev, status: newStatus } : null));
    }

    showToast({
      type: newStatus === 'cancelled' ? 'warning' : 'success',
      title: 'Status Updated',
      message: `Appointment marked as ${newStatus}.`
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Appointment Calendar & Roster
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Bookings synchronized across online chat, voice receptionist, and front desk walk-ins.
          </p>
        </div>

        <button
          onClick={onOpenBooking}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md shadow-indigo-600/20 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Schedule New Appointment
        </button>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-xs font-semibold text-slate-500">Total Bookings</div>
          <div className="text-2xl font-black text-slate-900 mt-1">{appointments.length}</div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-xs font-semibold text-slate-500">Confirmed</div>
          <div className="text-2xl font-black text-emerald-600 mt-1">
            {appointments.filter((a) => a.status === 'confirmed').length}
          </div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-xs font-semibold text-slate-500">Avg Booking Lead</div>
          <div className="text-2xl font-black text-indigo-600 mt-1">2.4 Days</div>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-xs font-semibold text-slate-500">No-Show Protection</div>
          <div className="text-2xl font-black text-slate-900 mt-1">98.2%</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col md:flex-row items-center justify-between gap-4 shadow-xs">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search patient, phone, or procedure..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Status Filter */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
            {['All', 'Confirmed', 'Completed', 'Cancelled'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                  statusFilter === st
                    ? 'bg-white text-indigo-700 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          {/* Specialist Filter */}
          <select
            value={staffFilter}
            onChange={(e) => setStaffFilter(e.target.value)}
            className="text-xs px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 focus:outline-none"
          >
            <option value="All">All Specialists</option>
            {mockStaff.map((st) => (
              <option key={st.id} value={st.name}>
                {st.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Appointments List / Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAppointments.map((apt) => (
          <div
            key={apt.id}
            className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4 hover:border-indigo-200 transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <span className={`text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-full border ${
                    apt.status === 'confirmed'
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : apt.status === 'completed'
                      ? 'bg-slate-100 text-slate-700 border-slate-200'
                      : 'bg-rose-50 text-rose-700 border-rose-200'
                  }`}>
                    {apt.status}
                  </span>
                  <h3 className="font-bold text-slate-900 text-sm mt-2">{apt.customerName}</h3>
                </div>

                <div className="text-right">
                  <div className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg">
                    {apt.time}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">{apt.date}</div>
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-slate-600 pt-1">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                  <span className="font-semibold text-slate-800 truncate">{apt.serviceName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{apt.staffName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{apt.customerPhone}</span>
                </div>
              </div>

              {apt.notes && (
                <div className="p-2.5 bg-slate-50 rounded-xl text-[11px] text-slate-500 border border-slate-100">
                  <span className="font-semibold text-slate-700">Intake: </span>
                  {apt.notes}
                </div>
              )}
            </div>

            {/* Quick Action Footer */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900">${apt.price}</span>

              <div className="flex items-center gap-1.5">
                {apt.status === 'confirmed' && (
                  <>
                    <button
                      onClick={() => handleStatusChange(apt.id, 'completed')}
                      className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg font-semibold text-[11px] transition-colors"
                    >
                      Check-In
                    </button>
                    <button
                      onClick={() => handleStatusChange(apt.id, 'cancelled')}
                      className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-semibold text-[11px] transition-colors"
                    >
                      Cancel
                    </button>
                  </>
                )}

                {apt.status === 'cancelled' && (
                  <button
                    onClick={() => handleStatusChange(apt.id, 'confirmed')}
                    className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-semibold text-[11px] transition-colors"
                  >
                    Restore
                  </button>
                )}

                {apt.status === 'completed' && (
                  <span className="text-[11px] text-slate-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Completed
                  </span>
                )}
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
