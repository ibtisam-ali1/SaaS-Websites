import React, { useState } from 'react';
import { AppView, Service, StaffMember, Appointment } from '../../types';
import { mockServices, mockStaff } from '../../data/mockData';
import { 
  Calendar, 
  Clock, 
  User, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft, 
  Star, 
  Sparkles, 
  MapPin, 
  Phone, 
  Mail, 
  ShieldCheck, 
  CalendarPlus,
  RefreshCw,
  XCircle,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useToast } from '../Toast';

interface BookingFlowProps {
  onNavigate: (view: AppView) => void;
  preselectedServiceId?: string;
  onAppointmentCreated?: (appointment: Appointment) => void;
}

export const BookingFlow: React.FC<BookingFlowProps> = ({
  onNavigate,
  preselectedServiceId,
  onAppointmentCreated
}) => {
  const { showToast } = useToast();

  // Wizard steps: 1: Service, 2: Staff, 3: Date & Time, 4: Contact Info, 5: Success
  const [currentStep, setCurrentStep] = useState<number>(1);

  // Selections
  const [selectedService, setSelectedService] = useState<Service>(
    mockServices.find((s) => s.id === preselectedServiceId) || mockServices[0]
  );
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(mockStaff[0]);

  // Calendar dates: current month dates
  const today = new Date();
  const [selectedDate, setSelectedDate] = useState<string>('2026-09-18');
  const [selectedTime, setSelectedTime] = useState<string>('10:00 AM');

  // Customer form
  const [customerName, setCustomerName] = useState('Victoria Sterling');
  const [customerEmail, setCustomerEmail] = useState('v.sterling@vanguardtech.io');
  const [customerPhone, setCustomerPhone] = useState('+1 (415) 555-0192');
  const [notes, setNotes] = useState('First time visiting clinic; routine consultation.');
  const [receiveReminders, setReceiveReminders] = useState(true);

  // Success state
  const [confirmedBooking, setConfirmedBooking] = useState<Appointment | null>(null);

  // Mock time slots
  const morningSlots = ['08:30 AM', '09:15 AM', '10:00 AM', '11:15 AM'];
  const afternoonSlots = ['01:30 PM', '02:15 PM', '03:00 PM', '04:15 PM'];
  const eveningSlots = ['05:00 PM', '05:45 PM'];

  // Trigger booking confirmation
  const handleConfirmBooking = () => {
    if (!customerName || !customerPhone) {
      showToast({
        type: 'warning',
        title: 'Missing Details',
        message: 'Please complete your name and phone number.'
      });
      return;
    }

    const newApt: Appointment = {
      id: `apt-${Math.floor(100000 + Math.random() * 900000)}`,
      serviceId: selectedService.id,
      serviceName: selectedService.name,
      staffId: selectedStaff?.id || 'any',
      staffName: selectedStaff?.name || 'Any Available Specialist',
      customerName,
      customerEmail,
      customerPhone,
      notes,
      date: selectedDate,
      time: selectedTime,
      status: 'confirmed',
      price: selectedService.price,
      createdAt: new Date().toISOString().split('T')[0]
    };

    setConfirmedBooking(newApt);
    if (onAppointmentCreated) {
      onAppointmentCreated(newApt);
    }

    setCurrentStep(5);

    // Fire celebratory confetti!
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (err) {
      // safe fallback
    }

    showToast({
      type: 'success',
      title: 'Appointment Confirmed!',
      message: `Reserved for ${selectedDate} at ${selectedTime}. Confirmation sent to ${customerPhone}.`
    });
  };

  const stepsList = [
    { num: 1, label: 'Service' },
    { num: 2, label: 'Specialist' },
    { num: 3, label: 'Date & Time' },
    { num: 4, label: 'Details' }
  ];

  return (
    <div className="min-h-[calc(100vh-4.5rem)] bg-slate-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        
        {/* Navigation back and header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => onNavigate('landing')}
            className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 px-3 py-1.5 rounded-lg shadow-xs transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </button>

          <div className="text-right">
            <span className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">
              Apex Health & Wellness Clinic
            </span>
            <div className="text-[11px] text-slate-400">Live Online Booking System</div>
          </div>
        </div>

        {/* Step Progress Header */}
        {currentStep < 5 && (
          <div className="bg-white rounded-2xl border border-slate-200 p-4 mb-6 shadow-xs">
            <div className="flex items-center justify-between">
              {stepsList.map((step, sIdx) => {
                const isCompleted = currentStep > step.num;
                const isCurrent = currentStep === step.num;

                return (
                  <React.Fragment key={step.num}>
                    <div
                      onClick={() => {
                        if (isCompleted) setCurrentStep(step.num);
                      }}
                      className={`flex items-center gap-2.5 ${isCompleted ? 'cursor-pointer' : ''}`}
                    >
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs transition-all ${
                          isCompleted
                            ? 'bg-emerald-600 text-white'
                            : isCurrent
                            ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 ring-4 ring-indigo-100'
                            : 'bg-slate-100 text-slate-400'
                        }`}
                      >
                        {isCompleted ? <Check className="w-4 h-4" /> : step.num}
                      </div>
                      <span
                        className={`text-xs sm:text-sm font-semibold hidden sm:inline ${
                          isCurrent ? 'text-slate-900 font-bold' : 'text-slate-500'
                        }`}
                      >
                        {step.label}
                      </span>
                    </div>

                    {sIdx < stepsList.length - 1 && (
                      <div
                        className={`flex-1 h-0.5 mx-2 sm:mx-4 transition-colors ${
                          currentStep > step.num ? 'bg-emerald-500' : 'bg-slate-200'
                        }`}
                      />
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          </div>
        )}

        {/* ================= STEP 1: SERVICE SELECTION ================= */}
        {currentStep === 1 && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                Select Your Desired Service
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Choose a clinical procedure, diagnostic checkup, or consultation.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {mockServices.map((srv) => {
                const isSelected = selectedService.id === srv.id;

                return (
                  <div
                    key={srv.id}
                    onClick={() => setSelectedService(srv)}
                    className={`cursor-pointer p-5 rounded-2xl border transition-all ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/40 ring-2 ring-indigo-500/20 shadow-md'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/70'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200/50">
                          {srv.category}
                        </span>
                        <h3 className="font-bold text-slate-900 text-sm sm:text-base mt-2">
                          {srv.name}
                        </h3>
                      </div>
                      <div className="text-right">
                        <div className="text-base sm:text-lg font-black text-slate-900">${srv.price}</div>
                        <div className="text-[11px] text-slate-500">{srv.durationMinutes} mins</div>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                      {srv.description}
                    </p>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                      {srv.popular && (
                        <span className="text-emerald-700 font-semibold flex items-center gap-1">
                          <Sparkles className="w-3.5 h-3.5" /> Most Requested
                        </span>
                      )}
                      <div
                        className={`w-5 h-5 rounded-full border flex items-center justify-center ml-auto ${
                          isSelected
                            ? 'bg-indigo-600 border-indigo-600 text-white'
                            : 'border-slate-300'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3" />}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-4 flex justify-end">
              <button
                onClick={() => setCurrentStep(2)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold text-sm shadow-md transition-colors"
              >
                Continue to Specialist Selection
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 2: STAFF / SPECIALIST SELECTION ================= */}
        {currentStep === 2 && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                Select Your Doctor or Specialist
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                You can select a specific attending practitioner or opt for the earliest available provider.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Option 1: Any Available Provider */}
              <div
                onClick={() => setSelectedStaff(null)}
                className={`cursor-pointer p-5 rounded-2xl border transition-all flex items-center gap-4 ${
                  selectedStaff === null
                    ? 'border-indigo-600 bg-indigo-50/40 ring-2 ring-indigo-500/20 shadow-md'
                    : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/70'
                }`}
              >
                <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-lg shrink-0">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                    Earliest Available Specialist
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Recommended for urgent availability & maximum slot flexibility.
                  </p>
                </div>
                <div
                  className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                    selectedStaff === null
                      ? 'bg-indigo-600 border-indigo-600 text-white'
                      : 'border-slate-300'
                  }`}
                >
                  {selectedStaff === null && <Check className="w-3 h-3" />}
                </div>
              </div>

              {/* Specific Staff Members */}
              {mockStaff.map((staff) => {
                const isSelected = selectedStaff?.id === staff.id;

                return (
                  <div
                    key={staff.id}
                    onClick={() => setSelectedStaff(staff)}
                    className={`cursor-pointer p-5 rounded-2xl border transition-all flex items-start gap-4 ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/40 ring-2 ring-indigo-500/20 shadow-md'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/70'
                    }`}
                  >
                    <img
                      src={staff.avatar}
                      alt={staff.name}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold text-slate-900 text-sm truncate">
                          {staff.name}
                        </h3>
                        <div className="flex items-center gap-0.5 text-xs text-amber-500 font-semibold shrink-0">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                          <span>{staff.rating}</span>
                        </div>
                      </div>
                      <p className="text-xs text-indigo-600 font-medium">{staff.role}</p>
                      
                      <div className="flex flex-wrap gap-1 mt-2">
                        {staff.specialties.map((spec, sIdx) => (
                          <span
                            key={sIdx}
                            className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded"
                          >
                            {spec}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-1 ${
                        isSelected
                          ? 'bg-indigo-600 border-indigo-600 text-white'
                          : 'border-slate-300'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3" />}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-4 flex items-center justify-between border-t border-slate-100">
              <button
                onClick={() => setCurrentStep(1)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 text-slate-600 hover:text-slate-900 text-xs sm:text-sm font-semibold rounded-xl hover:bg-slate-100"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Services
              </button>

              <button
                onClick={() => setCurrentStep(3)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold text-sm shadow-md transition-colors"
              >
                Continue to Date & Time
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 3: DATE & TIME SELECTION ================= */}
        {currentStep === 3 && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                Select Date & Available Time Slot
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Appointments are automatically synced in real time with our practice schedule.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              
              {/* Left: Quick Date Buttons */}
              <div className="md:col-span-5 space-y-3">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                  Select Day
                </label>
                
                <div className="space-y-2">
                  {[
                    { date: '2026-09-18', label: 'Tomorrow (Friday, Sep 18)', slots: '6 slots open' },
                    { date: '2026-09-19', label: 'Saturday, Sep 19', slots: '4 slots open' },
                    { date: '2026-09-21', label: 'Monday, Sep 21', slots: '8 slots open' },
                    { date: '2026-09-22', label: 'Tuesday, Sep 22', slots: '7 slots open' },
                    { date: '2026-09-23', label: 'Wednesday, Sep 23', slots: '9 slots open' }
                  ].map((d) => (
                    <div
                      key={d.date}
                      onClick={() => setSelectedDate(d.date)}
                      className={`cursor-pointer p-3.5 rounded-xl border flex items-center justify-between transition-all ${
                        selectedDate === d.date
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/20'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-xs sm:text-sm">{d.label}</div>
                        <div className={`text-[11px] ${selectedDate === d.date ? 'text-indigo-200' : 'text-slate-500'}`}>
                          {d.slots}
                        </div>
                      </div>
                      <Calendar className={`w-4 h-4 ${selectedDate === d.date ? 'text-white' : 'text-slate-400'}`} />
                    </div>
                  ))}
                </div>

                <div className="p-3 bg-indigo-50/70 border border-indigo-200/60 rounded-xl text-[11px] text-indigo-900 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-indigo-600 shrink-0" />
                  <span>All times displayed in Pacific Time (PST).</span>
                </div>
              </div>

              {/* Right: Time Slots Grid */}
              <div className="md:col-span-7 space-y-4">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                  Available Slots for {selectedDate}
                </label>

                {/* Morning Slots */}
                <div>
                  <div className="text-xs font-semibold text-slate-400 mb-2 flex items-center gap-1.5">
                    <span>Morning</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {morningSlots.map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all ${
                          selectedTime === time
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                            : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Afternoon Slots */}
                <div>
                  <div className="text-xs font-semibold text-slate-400 mb-2 flex items-center gap-1.5">
                    <span>Afternoon</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {afternoonSlots.map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all ${
                          selectedTime === time
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                            : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Evening Slots */}
                <div>
                  <div className="text-xs font-semibold text-slate-400 mb-2 flex items-center gap-1.5">
                    <span>Evening</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {eveningSlots.map((time) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all ${
                          selectedTime === time
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                            : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Selected summary */}
                <div className="p-3.5 bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span className="font-semibold text-slate-900">
                      Selected: {selectedDate} at {selectedTime}
                    </span>
                  </div>
                  <span className="text-slate-500 font-medium">
                    {selectedStaff?.name || 'Any Specialist'}
                  </span>
                </div>

              </div>

            </div>

            <div className="pt-4 flex items-center justify-between border-t border-slate-100">
              <button
                onClick={() => setCurrentStep(2)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 text-slate-600 hover:text-slate-900 text-xs sm:text-sm font-semibold rounded-xl hover:bg-slate-100"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Specialist
              </button>

              <button
                onClick={() => setCurrentStep(4)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold text-sm shadow-md transition-colors"
              >
                Continue to Contact Details
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 4: CUSTOMER CONTACT INFO & CONFIRMATION ================= */}
        {currentStep === 4 && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                Client Information & Confirmation
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                We will text and email you booking confirmation and calendar sync links.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Form inputs */}
              <div className="lg:col-span-7 space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Full Legal Name *
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Victoria Sterling"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                      Mobile Phone (for SMS Reminders) *
                    </label>
                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="+1 (415) 555-0192"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      placeholder="v.sterling@example.com"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                    Reason for Visit / Intake Notes (Optional)
                  </label>
                  <textarea
                    rows={3}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Describe any symptoms, medical history, or specific questions for the doctor..."
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  ></textarea>
                </div>

                <div className="flex items-start gap-2.5 pt-1">
                  <input
                    id="sms-consent"
                    type="checkbox"
                    checked={receiveReminders}
                    onChange={(e) => setReceiveReminders(e.target.checked)}
                    className="mt-1 rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <label htmlFor="sms-consent" className="text-xs text-slate-600 cursor-pointer">
                    Send me automated SMS appointment reminders 24 hours & 2 hours prior to visit (eliminates missed visits).
                  </label>
                </div>
              </div>

              {/* Order summary card */}
              <div className="lg:col-span-5">
                <div className="bg-slate-50 rounded-2xl border border-slate-200 p-5 space-y-4">
                  <h3 className="font-bold text-slate-900 text-sm pb-2 border-b border-slate-200">
                    Appointment Summary
                  </h3>

                  <div className="space-y-3 text-xs">
                    <div>
                      <div className="text-slate-400 font-medium">Service</div>
                      <div className="font-bold text-slate-900 text-sm mt-0.5">{selectedService.name}</div>
                      <div className="text-slate-500">{selectedService.durationMinutes} mins</div>
                    </div>

                    <div>
                      <div className="text-slate-400 font-medium">Provider</div>
                      <div className="font-semibold text-slate-900 mt-0.5">
                        {selectedStaff ? selectedStaff.name : 'First Available Doctor'}
                      </div>
                    </div>

                    <div>
                      <div className="text-slate-400 font-medium">Scheduled Time</div>
                      <div className="font-semibold text-indigo-700 mt-0.5 flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{selectedDate} at {selectedTime}</span>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-200 flex items-center justify-between text-sm">
                      <span className="font-bold text-slate-900">Total Price</span>
                      <span className="font-extrabold text-slate-900 text-base">
                        ${selectedService.price}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-500 pt-1">
                      No upfront deposit required. Payment collected at clinic desk or via superbill.
                    </div>
                  </div>
                </div>
              </div>

            </div>

            <div className="pt-4 flex items-center justify-between border-t border-slate-100">
              <button
                onClick={() => setCurrentStep(3)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 text-slate-600 hover:text-slate-900 text-xs sm:text-sm font-semibold rounded-xl hover:bg-slate-100"
              >
                <ArrowLeft className="w-4 h-4" />
                Change Date & Time
              </button>

              <button
                onClick={handleConfirmBooking}
                className="inline-flex items-center gap-2 px-7 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-sm shadow-lg shadow-emerald-600/25 transition-all transform hover:-translate-y-0.5"
              >
                <CheckCircle2 className="w-5 h-5" />
                Confirm Appointment Now
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 5: SUCCESS CONFIRMATION SCREEN ================= */}
        {currentStep === 5 && confirmedBooking && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-10 shadow-lg text-center space-y-6">
            
            {/* Success Icon */}
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-md">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-2 max-w-md mx-auto">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-semibold border border-emerald-200">
                <Sparkles className="w-3.5 h-3.5" />
                Booking Confirmed & Calendar Synced
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                You Are All Set, {confirmedBooking.customerName}!
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                A confirmation text and email with arrival directions were sent to{' '}
                <span className="font-semibold text-slate-800">{confirmedBooking.customerPhone}</span>.
              </p>
            </div>

            {/* Upcoming Appointment Card */}
            <div className="max-w-md mx-auto bg-slate-50 border border-slate-200/90 rounded-2xl p-5 text-left space-y-4 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                  Appointment Card
                </span>
                <span className="text-xs font-mono text-slate-500">Ref: {confirmedBooking.id}</span>
              </div>

              <div className="space-y-2.5 text-xs">
                <div>
                  <div className="text-slate-400">Service</div>
                  <div className="font-bold text-slate-900 text-sm">{confirmedBooking.serviceName}</div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="text-slate-400">Date & Time</div>
                    <div className="font-semibold text-slate-900">
                      {confirmedBooking.date} at {confirmedBooking.time}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-400">Provider</div>
                    <div className="font-semibold text-slate-900">{confirmedBooking.staffName}</div>
                  </div>
                </div>

                <div>
                  <div className="text-slate-400">Location</div>
                  <div className="font-medium text-slate-800">
                    Apex Health Clinic • 742 Evergreen Terrace, Suite 300, SF
                  </div>
                </div>
              </div>

              {/* Add to Calendar Action */}
              <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                <button
                  onClick={() => {
                    showToast({
                      type: 'info',
                      title: 'Calendar Event Downloaded',
                      message: 'Added to Google Calendar / iCal.'
                    });
                  }}
                  className="inline-flex items-center gap-1 text-xs font-bold text-indigo-600 hover:text-indigo-800"
                >
                  <CalendarPlus className="w-4 h-4" />
                  Add to Google Calendar
                </button>

                <span className="text-[11px] text-emerald-600 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Confirmed
                </span>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => {
                  setCurrentStep(1);
                  setConfirmedBooking(null);
                }}
                className="w-full sm:w-auto px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-semibold transition-colors"
              >
                Book Another Appointment
              </button>

              <button
                onClick={() => onNavigate('dashboard')}
                className="w-full sm:w-auto px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-md transition-colors"
              >
                View in Business Dashboard &rarr;
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
