import React, { useState } from 'react';
import { mockPricingPlans } from '../../data/mockData';
import { AppView } from '../../types';
import { Check, Sparkles, ArrowRight } from 'lucide-react';
import { useToast } from '../Toast';

interface PricingSectionProps {
  onNavigate: (view: AppView) => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onNavigate }) => {
  const [isAnnual, setIsAnnual] = useState(true);
  const { showToast } = useToast();

  const handlePlanSelect = (planName: string) => {
    showToast({
      type: 'success',
      title: `${planName} Selected`,
      message: 'Launching business setup portal. Your 14-day free trial has started!'
    });
    onNavigate('dashboard');
  };

  return (
    <section id="pricing" className="py-20 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold border border-indigo-200/60">
            <Sparkles className="w-3.5 h-3.5" />
            Simple, Transparent Pricing
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Plans That Scale with Your Booking Volume
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            No surprise overage fees. Start with a 14-day free trial. Cancel or change plans anytime.
          </p>

          {/* Monthly / Annual Toggle */}
          <div className="pt-4 flex items-center justify-center gap-3">
            <span className={`text-xs sm:text-sm font-semibold ${!isAnnual ? 'text-slate-900' : 'text-slate-500'}`}>
              Monthly Billing
            </span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className="relative w-12 h-6 rounded-full bg-slate-200 p-0.5 transition-colors focus:outline-none"
              aria-label="Toggle annual pricing"
            >
              <div
                className={`w-5 h-5 rounded-full bg-indigo-600 transition-transform ${
                  isAnnual ? 'translate-x-6' : 'translate-x-0'
                }`}
              ></div>
            </button>
            <div className="flex items-center gap-1.5">
              <span className={`text-xs sm:text-sm font-semibold ${isAnnual ? 'text-slate-900' : 'text-slate-500'}`}>
                Annual Billing
              </span>
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                Save 20%
              </span>
            </div>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {mockPricingPlans.map((plan) => {
            const price = isAnnual ? plan.annualPrice : plan.monthlyPrice;

            return (
              <div
                key={plan.id}
                className={`relative rounded-3xl p-8 transition-all flex flex-col justify-between ${
                  plan.highlight
                    ? 'bg-slate-900 text-white shadow-2xl shadow-indigo-900/20 ring-2 ring-indigo-500'
                    : 'bg-white text-slate-900 border border-slate-200/90 shadow-md hover:shadow-xl'
                }`}
              >
                {/* Popular Badge */}
                {plan.badge && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-indigo-500 to-violet-500 text-white text-[11px] font-bold px-3.5 py-1 rounded-full uppercase tracking-wider shadow-md">
                    {plan.badge}
                  </div>
                )}

                <div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold">{plan.name}</h3>
                    <p className={`text-xs leading-relaxed ${plan.highlight ? 'text-slate-300' : 'text-slate-600'}`}>
                      {plan.description}
                    </p>
                  </div>

                  {/* Price */}
                  <div className="py-6 border-b border-slate-200/40 my-4 flex items-baseline gap-1">
                    <span className="text-4xl sm:text-5xl font-extrabold tracking-tight">${price}</span>
                    <span className={`text-xs font-semibold ${plan.highlight ? 'text-slate-400' : 'text-slate-500'}`}>
                      / month {isAnnual ? '(billed annually)' : ''}
                    </span>
                  </div>

                  {/* Feature List */}
                  <ul className="space-y-3 pt-2 text-xs sm:text-sm">
                    {plan.features.map((feat, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-2.5">
                        <div
                          className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                            plan.highlight ? 'bg-indigo-500/30 text-indigo-400' : 'bg-emerald-100 text-emerald-700'
                          }`}
                        >
                          <Check className="w-3 h-3" />
                        </div>
                        <span className={plan.highlight ? 'text-slate-200' : 'text-slate-700'}>
                          {feat}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* CTA Button */}
                <div className="pt-8">
                  <button
                    onClick={() => handlePlanSelect(plan.name)}
                    className={`w-full py-3.5 px-4 rounded-xl font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-sm ${
                      plan.highlight
                        ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
                        : 'bg-slate-900 hover:bg-slate-800 text-white'
                    }`}
                  >
                    <span>{plan.cta}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>

        {/* Enterprise Callout */}
        <div className="mt-12 text-center text-xs text-slate-500">
          Need custom EHR integration or volume-based pricing for 50+ locations?{' '}
          <button
            onClick={() => onNavigate('dashboard')}
            className="text-indigo-600 font-semibold hover:underline"
          >
            Contact our Solutions Engineering Team &rarr;
          </button>
        </div>

      </div>
    </section>
  );
};
