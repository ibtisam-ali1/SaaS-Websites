import React, { useState } from 'react';
import { mockIndustrySolutions } from '../../data/mockData';
import { AppView } from '../../types';
import { 
  Building2, 
  Scissors, 
  Scale, 
  Home, 
  Wrench, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  MessageSquare,
  Bot
} from 'lucide-react';

interface IndustrySolutionsProps {
  onNavigate: (view: AppView) => void;
}

export const IndustrySolutions: React.FC<IndustrySolutionsProps> = ({ onNavigate }) => {
  const [selectedIndustry, setSelectedIndustry] = useState(mockIndustrySolutions[0].id);

  const getIndustryIcon = (id: string) => {
    switch (id) {
      case 'clinics': return <Building2 className="w-4 h-4" />;
      case 'salons': return <Scissors className="w-4 h-4" />;
      case 'legal': return <Scale className="w-4 h-4" />;
      case 'realestate': return <Home className="w-4 h-4" />;
      case 'homeservices': return <Wrench className="w-4 h-4" />;
      default: return <Building2 className="w-4 h-4" />;
    }
  };

  const activeData = mockIndustrySolutions.find((i) => i.id === selectedIndustry) || mockIndustrySolutions[0];

  return (
    <section id="solutions" className="py-20 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold border border-indigo-200/60">
            <Sparkles className="w-3.5 h-3.5" />
            Tailored Industry Workflows
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Specialized Knowledge Bases for Your Exact Business
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            ReceptionAI comes pre-trained on domain-specific vocabulary, compliance protocols, and standard booking workflows.
          </p>
        </div>

        {/* Industry Pill Selector Tabs */}
        <div className="flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-4 mb-10 no-scrollbar">
          {mockIndustrySolutions.map((ind) => (
            <button
              key={ind.id}
              onClick={() => setSelectedIndustry(ind.id)}
              className={`whitespace-nowrap flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                selectedIndustry === ind.id
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'bg-slate-100 hover:bg-slate-200/70 text-slate-700'
              }`}
            >
              {getIndustryIcon(ind.id)}
              <span>{ind.name}</span>
            </button>
          ))}
        </div>

        {/* Active Industry Card Display */}
        <div className="bg-slate-50 rounded-3xl border border-slate-200/90 p-6 sm:p-10 shadow-lg shadow-slate-900/5">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            
            {/* Left Content */}
            <div className="lg:col-span-6 space-y-6">
              <div className="space-y-2">
                <span className="inline-block text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-md border border-indigo-200/60">
                  {activeData.badge}
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight">
                  {activeData.headline}
                </h3>
                <p className="text-slate-600 text-sm sm:text-base leading-relaxed pt-2">
                  {activeData.description}
                </p>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 pt-1">
                {activeData.tags.map((tag, tIdx) => (
                  <span
                    key={tIdx}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white border border-slate-200 text-xs font-medium text-slate-700 shadow-xs"
                  >
                    <CheckCircle2 className="w-3 h-3 text-indigo-600" />
                    {tag}
                  </span>
                ))}
              </div>

              {/* Metrics */}
              <div className="grid grid-cols-3 gap-3 pt-4 border-t border-slate-200/80">
                <div className="p-3 bg-white rounded-xl border border-slate-200/80 text-center">
                  <div className="text-lg sm:text-xl font-extrabold text-indigo-600">{activeData.metrics.bookings}</div>
                  <div className="text-[11px] text-slate-500 font-medium mt-0.5">Booking Volume</div>
                </div>
                <div className="p-3 bg-white rounded-xl border border-slate-200/80 text-center">
                  <div className="text-lg sm:text-xl font-extrabold text-slate-900">{activeData.metrics.responseTime}</div>
                  <div className="text-[11px] text-slate-500 font-medium mt-0.5">Avg Response</div>
                </div>
                <div className="p-3 bg-white rounded-xl border border-slate-200/80 text-center">
                  <div className="text-lg sm:text-xl font-extrabold text-emerald-600">{activeData.metrics.savedHours}</div>
                  <div className="text-[11px] text-slate-500 font-medium mt-0.5">Admin Saved</div>
                </div>
              </div>

              {/* Action */}
              <div className="pt-2">
                <button
                  onClick={() => onNavigate('receptionist')}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs sm:text-sm shadow-md transition-colors"
                >
                  <Bot className="w-4 h-4 text-indigo-400" />
                  Test ReceptionAI for {activeData.name}
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>

            {/* Right Chat Example Card */}
            <div className="lg:col-span-6">
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xl p-6 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                      AI
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">Live Client Conversation</div>
                      <div className="text-[10px] text-slate-400">Industry: {activeData.name}</div>
                    </div>
                  </div>
                  <span className="text-[11px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full font-medium border border-emerald-200/60">
                    Live Verified
                  </span>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-end">
                    <div className="bg-indigo-600 text-white text-xs sm:text-sm p-3.5 rounded-2xl rounded-br-xs max-w-[85%] shadow-xs">
                      {activeData.sampleQuery}
                    </div>
                  </div>

                  <div className="flex justify-start">
                    <div className="bg-slate-100 text-slate-800 text-xs sm:text-sm p-3.5 rounded-2xl rounded-bl-xs max-w-[85%] border border-slate-200/60">
                      {activeData.sampleResponse}
                    </div>
                  </div>
                </div>

                <div className="mt-4 p-3 bg-indigo-50/70 border border-indigo-100 rounded-xl flex items-center justify-between text-xs text-indigo-900">
                  <span>Automatic Calendar Block created</span>
                  <button
                    onClick={() => onNavigate('booking')}
                    className="font-bold text-indigo-600 hover:text-indigo-800 underline"
                  >
                    View Slot &rarr;
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
