import React, { useState } from 'react';
import { AppView } from '../../types';
import { 
  Bot, 
  Sparkles, 
  ArrowRight, 
  Calendar, 
  CheckCircle2, 
  Star, 
  Send, 
  Clock, 
  ShieldCheck, 
  Headphones,
  Zap,
  PhoneCall
} from 'lucide-react';

interface HeroSectionProps {
  onNavigate: (view: AppView) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onNavigate }) => {
  // Live mini preview chat state
  const [messages, setMessages] = useState([
    {
      id: 'h1',
      sender: 'ai',
      text: 'Hello! I am Aria, your AI Receptionist. I can answer inquiries, check practitioner availability, or book appointments 24/7. How can I help you today?'
    },
    {
      id: 'h2',
      sender: 'user',
      text: 'Do you have any openings for a dental checkup and whitening this Friday?'
    },
    {
      id: 'h3',
      sender: 'ai',
      text: 'Yes! Dr. Marcus Vance has availability this Friday at 10:30 AM and 2:30 PM. Would you like me to reserve one of these slots?'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const handleQuickPrompt = (prompt: string) => {
    if (isTyping) return;
    const userMsg = { id: Date.now().toString(), sender: 'user', text: prompt };
    setMessages((prev) => [...prev, userMsg]);
    setIsTyping(true);

    setTimeout(() => {
      let aiReply = "I'd be delighted to assist! You can choose from our general consultation, dental screening, or physical therapy sessions. Would you like to select a specialist?";
      if (prompt.includes('Book') || prompt.includes('slot') || prompt.includes('reserve')) {
        aiReply = "I have Friday at 10:30 AM reserved for you. Let's complete your details, or click 'Book Appointment' to choose your preferred specialist!";
      } else if (prompt.includes('hours') || prompt.includes('Open')) {
        aiReply = "Our clinic is open Monday through Saturday from 8:00 AM to 6:30 PM. I am available right here 24 hours a day to handle your bookings!";
      } else if (prompt.includes('human') || prompt.includes('speak')) {
        aiReply = "I can immediately initiate a warm phone transfer to our front desk team, or take down your callback number. Would you like a call back?";
      }

      setMessages((prev) => [
        ...prev,
        { id: (Date.now() + 1).toString(), sender: 'ai', text: aiReply }
      ]);
      setIsTyping(false);
    }, 900);
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isTyping) return;
    const prompt = inputText.trim();
    setInputText('');
    handleQuickPrompt(prompt);
  };

  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:pt-16 lg:pb-24 bg-gradient-to-b from-indigo-50/40 via-white to-slate-50">
      
      {/* Background ambient orbs */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 pointer-events-none opacity-40">
        <div className="absolute top-10 left-1/4 w-72 h-72 bg-indigo-300/30 rounded-full blur-3xl"></div>
        <div className="absolute top-20 right-1/4 w-80 h-80 bg-violet-300/25 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Hero Content */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Top pill badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white border border-indigo-200/80 shadow-xs text-xs font-semibold text-indigo-700">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-600"></span>
              </span>
              <span>Next-Gen Voice & Chat Virtual Receptionist</span>
              <span className="text-slate-300">|</span>
              <span className="text-slate-500 font-normal">v3.2 Released</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.12]">
              Your AI Receptionist.{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-600">
                Always Available.
              </span>
            </h1>

            {/* Supporting paragraph */}
            <p className="text-lg sm:text-xl text-slate-600 leading-relaxed max-w-2xl font-normal">
              Capture every client, qualify leads, and book appointments directly into your calendar 24 hours a day. Never let a missed call or delayed message turn into lost revenue again.
            </p>

            {/* Key benefits list */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
              <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Zero Missed Calls</span>
              </div>
              <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Instant Calendar Booking</span>
              </div>
              <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Warm Human Escalation</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 pt-4">
              <button
                id="hero-try-receptionist-btn"
                onClick={() => onNavigate('receptionist')}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm sm:text-base shadow-lg shadow-indigo-600/25 hover:shadow-indigo-600/35 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <Headphones className="w-5 h-5" />
                Try AI Receptionist
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                id="hero-book-appointment-btn"
                onClick={() => onNavigate('booking')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-sm sm:text-base border border-slate-200 shadow-xs hover:border-slate-300 transition-all"
              >
                <Calendar className="w-5 h-5 text-indigo-600" />
                Book Appointment
              </button>

              <button
                id="hero-view-dashboard-btn"
                onClick={() => onNavigate('dashboard')}
                className="inline-flex items-center justify-center gap-2 px-4 py-3.5 rounded-xl text-slate-600 hover:text-slate-900 font-semibold text-xs sm:text-sm hover:bg-slate-100/70 transition-all"
              >
                Explore Dashboard &rarr;
              </button>
            </div>

            {/* Trust Badges / Social Proof */}
            <div className="pt-6 border-t border-slate-200/80 flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex -space-x-2">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100"
                  alt="Client"
                  className="w-8 h-8 rounded-full border-2 border-white object-cover shadow-xs"
                />
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100"
                  alt="Client"
                  className="w-8 h-8 rounded-full border-2 border-white object-cover shadow-xs"
                />
                <img
                  src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=100"
                  alt="Client"
                  className="w-8 h-8 rounded-full border-2 border-white object-cover shadow-xs"
                />
                <img
                  src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100"
                  alt="Client"
                  className="w-8 h-8 rounded-full border-2 border-white object-cover shadow-xs"
                />
              </div>

              <div className="text-xs text-slate-600">
                <div className="flex items-center gap-1 text-amber-500 font-semibold">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <span className="text-slate-900 font-bold ml-1">4.9/5</span>
                  <span className="text-slate-400 font-normal">from 1,400+ practices</span>
                </div>
                <p className="text-slate-500 mt-0.5">
                  Trusted by clinics, law firms, salons, and real estate teams.
                </p>
              </div>
            </div>

          </div>

          {/* Right Column: Live Interactive Receptionist Mockup */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-md w-full">
              
              {/* Decorative halo */}
              <div className="absolute -inset-1.5 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-3xl blur-xl opacity-20 group-hover:opacity-30 transition duration-1000"></div>

              {/* Chat Card */}
              <div className="relative bg-white rounded-2xl border border-slate-200/90 shadow-2xl shadow-indigo-900/10 overflow-hidden">
                
                {/* Header of the AI widget */}
                <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-md">
                        <Bot className="w-5 h-5" />
                      </div>
                      <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full"></span>
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-semibold text-sm text-white">Aria • Virtual Receptionist</h3>
                        <span className="text-[10px] bg-indigo-900/80 text-indigo-300 font-medium px-1.5 py-0.5 rounded">AI</span>
                      </div>
                      <p className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-emerald-400" /> Replies instantly in &lt;1s
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onNavigate('receptionist')}
                      className="text-[11px] font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1.5 rounded-lg transition-colors flex items-center gap-1"
                      title="Expand to full screen"
                    >
                      <span>Expand</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Subheader info bar */}
                <div className="bg-slate-100/80 border-b border-slate-200/80 px-4 py-2 flex items-center justify-between text-xs text-slate-600">
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    <span className="font-medium text-slate-700">Apex Health & Wellness Clinic</span>
                  </div>
                  <span className="text-slate-400 text-[11px]">HIPAA Protected</span>
                </div>

                {/* Chat Messages Container */}
                <div className="p-4 space-y-3.5 h-72 overflow-y-auto bg-slate-50/50">
                  {messages.map((m) => (
                    <div
                      key={m.id}
                      className={`flex gap-2.5 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      {m.sender === 'ai' && (
                        <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white shrink-0 shadow-xs mt-0.5">
                          <Bot className="w-4 h-4" />
                        </div>
                      )}
                      
                      <div
                        className={`max-w-[82%] rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm leading-relaxed ${
                          m.sender === 'user'
                            ? 'bg-indigo-600 text-white rounded-br-xs shadow-xs'
                            : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-xs shadow-xs'
                        }`}
                      >
                        {m.text}
                      </div>
                    </div>
                  ))}

                  {/* Typing animation indicator */}
                  {isTyping && (
                    <div className="flex items-center gap-2 text-slate-400 text-xs pl-9">
                      <div className="flex space-x-1">
                        <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                        <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                        <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce"></div>
                      </div>
                      <span>Aria is checking availability...</span>
                    </div>
                  )}
                </div>

                {/* Quick Interactive Chip Prompts */}
                <div className="p-2.5 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                  <button
                    onClick={() => handleQuickPrompt('Reserve the 10:30 AM slot')}
                    className="whitespace-nowrap px-2.5 py-1 text-[11px] font-medium rounded-full bg-indigo-50 hover:bg-indigo-100 text-indigo-700 transition-colors"
                  >
                    Reserve 10:30 AM
                  </button>
                  <button
                    onClick={() => handleQuickPrompt('What are your clinic hours?')}
                    className="whitespace-nowrap px-2.5 py-1 text-[11px] font-medium rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                  >
                    Clinic Hours
                  </button>
                  <button
                    onClick={() => handleQuickPrompt('Can I speak with a human receptionist?')}
                    className="whitespace-nowrap px-2.5 py-1 text-[11px] font-medium rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                  >
                    Talk to Human
                  </button>
                </div>

                {/* Input box */}
                <form onSubmit={handleSend} className="p-3 bg-white border-t border-slate-200/80 flex items-center gap-2">
                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Type an inquiry or question..."
                    className="flex-1 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                  />
                  <button
                    type="submit"
                    disabled={!inputText.trim() || isTyping}
                    className="p-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white rounded-xl transition-colors shadow-xs"
                    aria-label="Send message"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>

                {/* Quick Action Footer inside Card */}
                <div className="bg-slate-50 px-4 py-2.5 border-t border-slate-200/60 flex items-center justify-between text-xs">
                  <span className="text-slate-500 text-[11px]">Ready to book?</span>
                  <button
                    onClick={() => onNavigate('booking')}
                    className="text-indigo-600 hover:text-indigo-800 font-semibold text-xs flex items-center gap-1"
                  >
                    Launch Full Booking Form &rarr;
                  </button>
                </div>

              </div>

              {/* Floating notification badge on the side */}
              <div className="hidden sm:flex absolute -bottom-5 -left-6 bg-white p-3 rounded-xl border border-slate-200/90 shadow-xl items-center gap-3 backdrop-blur-md">
                <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">New Appointment Booked</div>
                  <div className="text-[11px] text-slate-500">Rachel Green • Dental Exam (Friday)</div>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
