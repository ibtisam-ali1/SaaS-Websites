import React from 'react';
import { 
  Sparkles, 
  TrendingUp, 
  Clock, 
  DollarSign, 
  ShieldCheck, 
  Check, 
  X 
} from 'lucide-react';

export const BenefitsSection: React.FC = () => {
  const stats = [
    {
      metric: '0',
      suffix: 'Missed Calls',
      label: '100% of calls and chats answered instantly',
      icon: <Clock className="w-5 h-5 text-indigo-600" />
    },
    {
      metric: '3.4x',
      suffix: 'Faster Conversion',
      label: 'From inquiry to confirmed appointment in 45s',
      icon: <TrendingUp className="w-5 h-5 text-emerald-600" />
    },
    {
      metric: '$4,200',
      suffix: '/mo Saved',
      label: 'In overtime, missed booking leakage, and temp staffing',
      icon: <DollarSign className="w-5 h-5 text-indigo-600" />
    },
    {
      metric: '99.8%',
      suffix: 'Accuracy Rate',
      label: 'Exact calendar slot booking and policy compliance',
      icon: <ShieldCheck className="w-5 h-5 text-emerald-600" />
    }
  ];

  return (
    <section className="py-20 bg-slate-900 text-white relative overflow-hidden">
      
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-7xl h-full pointer-events-none opacity-20">
        <div className="absolute top-1/4 left-1/3 w-96 h-96 bg-indigo-500 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-900/60 text-indigo-300 text-xs font-semibold border border-indigo-700/60">
            <Sparkles className="w-3.5 h-3.5" />
            The ROI Breakdown
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Stop Losing 40% of Your Inbound Opportunities
          </h2>
          <p className="text-slate-400 text-base sm:text-lg">
            Traditional front desks are overwhelmed during peak hours and closed on nights and weekends. ReceptionAI captures revenue around the clock.
          </p>
        </div>

        {/* 4 Stat Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((s, idx) => (
            <div
              key={idx}
              className="bg-slate-800/80 border border-slate-700/70 p-6 rounded-2xl backdrop-blur-sm space-y-3"
            >
              <div className="w-10 h-10 rounded-xl bg-slate-700/60 flex items-center justify-center">
                {s.icon}
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-3xl sm:text-4xl font-black text-white">{s.metric}</span>
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">{s.suffix}</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                {s.label}
              </p>
            </div>
          ))}
        </div>

        {/* Side-by-side comparison table */}
        <div className="max-w-4xl mx-auto bg-slate-800/90 rounded-3xl border border-slate-700 overflow-hidden shadow-2xl">
          <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-700">
            
            {/* Traditional Receptionist */}
            <div className="p-6 sm:p-8 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-700/80">
                <h4 className="font-bold text-slate-300 text-sm sm:text-base">Traditional Front Desk</h4>
                <span className="text-xs px-2.5 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-800/60">
                  High Leakage
                </span>
              </div>
              <ul className="space-y-3 text-xs sm:text-sm text-slate-400">
                <li className="flex items-start gap-2.5">
                  <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>Only available 9 AM - 5 PM; closed on weekends and holidays</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>Can only speak with 1 caller at a time while others get busy signals</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>Average monthly wage $3,500 - $4,800 + sick leave & benefits</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>High turnover requiring constant retraining on services & doctors</span>
                </li>
              </ul>
            </div>

            {/* ReceptionAI */}
            <div className="p-6 sm:p-8 space-y-4 bg-indigo-950/30">
              <div className="flex items-center justify-between pb-3 border-b border-slate-700/80">
                <h4 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-400" />
                  ReceptionAI Platform
                </h4>
                <span className="text-xs px-2.5 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 font-semibold">
                  Zero Missed Revenue
                </span>
              </div>
              <ul className="space-y-3 text-xs sm:text-sm text-slate-200">
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>24 hours a day, 7 days a week, 365 days a year availability</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Handles 100+ simultaneous phone calls & web chats concurrently</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Starting at $99/mo with zero overhead or benefits costs</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Instantly updated whenever you alter services or calendar hours</span>
                </li>
              </ul>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
