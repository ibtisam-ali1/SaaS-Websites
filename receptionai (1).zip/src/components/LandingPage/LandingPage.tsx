import React from 'react';
import { AppView } from '../../types';
import { HeroSection } from './HeroSection';
import { FeaturesSection } from './FeaturesSection';
import { HowItWorksSection } from './HowItWorksSection';
import { IndustrySolutions } from './IndustrySolutions';
import { BenefitsSection } from './BenefitsSection';
import { TestimonialsSection } from './TestimonialsSection';
import { PricingSection } from './PricingSection';
import { FaqSection } from './FaqSection';
import { CtaSection } from './CtaSection';

interface LandingPageProps {
  onNavigate: (view: AppView) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <HeroSection onNavigate={onNavigate} />
      <FeaturesSection />
      <HowItWorksSection onNavigate={onNavigate} />
      <IndustrySolutions onNavigate={onNavigate} />
      <BenefitsSection />
      <TestimonialsSection />
      <PricingSection onNavigate={onNavigate} />
      <FaqSection />
      <CtaSection onNavigate={onNavigate} />
    </div>
  );
};
