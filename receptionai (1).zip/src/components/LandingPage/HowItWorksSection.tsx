import React, { useState } from 'react';
import { AppView } from '../../types';
import { Calendar, Bot, CheckCircle2, ArrowRight, ShieldCheck, Sparkles, MessageSquare } from 'lucide-react';

interface HowItWorksSectionProps {
  onNavigate: (view: AppView) => void;
}

export const HowItWorksSection: React.FC<HowItWorksSectionProps> = ({ onNavigate }) => {
  const [activeStep, setActiveStep] = useState(0);

  const steps = [
    {
      step: '01',
      title: 'Plug In Your Calendar & Services',
      description: 'Connect your Google Calendar or practice management system in two clicks. Add your service catalog, team members, and custom business rules.',
      highlight: 'Live two-way calendar sync prevents double-booking.',
      mockContent: (
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 text-xs">
            <span className="font-semibold text-slate-800">Connected Calendars</span>
            <span className="text-emerald-600 font-medium flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Active Sync
            </span>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 text-xs text-slate-700">
              <span className="font-medium">Dr. Sarah Lin (Primary Care)</span>
              <span className="text-slate-400">Google Calendar</span>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 text-xs text-slate-700">
              <span className="font-medium">Dr. Marcus Vance (Dental)</span>
              <span className="text-slate-400">Outlook 365</span>
            </div>
          </div>
          <div className="text-[11px] text-slate-500 bg-indigo-50/70 p-2.5 rounded-lg border border-indigo-100 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
            <span>AI automatically learns buffer times and working hours.</span>
          </div>
        </div>
      )
    },
    {
      step: '02',
      title: 'AI Handles Inbound Calls & Chats',
      description: 'ReceptionAI greets clients with warm, human-like voice and natural conversational tone. It answers complex questions, handles pricing, and collects intake details.',
      highlight: 'Sub-800ms natural latency with zero robotic delays.',
      mockContent: (
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-800 pb-2 border-b border-slate-100">
            <Bot className="w-4 h-4 text-indigo-600" />
            <span>Live Voice AI Call Transcript</span>
          </div>
          <div className="space-y-2 text-xs">
            <div className="bg-slate-100 p-2.5 rounded-lg text-slate-700">
              <span className="font-semibold text-slate-900">Caller:</span> "Hi, do you take BlueShield PPO for a new patient physical?"
            </div>
            <div className="bg-indigo-600 text-white p-2.5 rounded-lg">
              <span className="font-semibold">AI Receptionist:</span> "Yes! We are in-network with BlueShield PPO. Dr. Lin has an opening this Thursday at 10:30 AM. Would you like me to book that?"
            </div>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
            <span>Latency: 720ms</span>
            <span className="text-emerald-600 font-medium">Confidence: 99.4%</span>
          </div>
        </div>
      )
    },
    {
      step: '03',
      title: 'Appointments Land Confirmed in Your Schedule',
      description: 'Bookings immediately sync with your staff schedule. Confirmation SMS and reminders are sent to the customer, drastically reducing no-shows.',
      highlight: '98.2% attendance rate with automated reminders.',
      mockContent: (
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-800 pb-2 border-b border-slate-100">
            <span className="text-emerald-700 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              Appointment Confirmed
            </span>
            <span className="text-[11px] font-normal text-slate-400">Ref #APT-892</span>
          </div>
          <div className="space-y-2 text-xs">
            <div className="p-3 bg-emerald-50/70 border border-emerald-200/60 rounded-lg">
              <div className="font-bold text-slate-900">Comprehensive Health Consultation</div>
              <div className="text-slate-600 mt-1">Victoria Sterling • Dr. Sarah Lin, MD</div>
              <div className="text-emerald-700 font-semibold mt-1">Friday, 10:00 AM - 10:45 AM</div>
            </div>
          </div>
          <div className="text-[11px] text-slate-500 flex items-center justify-between">
            <span>SMS Confirmation sent</span>
            <span className="text-indigo-600 font-medium">Calendar Event Created</span>
          </div>
        </div>
      )
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold border border-indigo-200/60">
            <Sparkles className="w-3.5 h-3.5" />
            Simple 3-Step Setup
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            How ReceptionAI Transforms Your Operations
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Zero complex coding required. Go from signup to automated bookings in under 15 minutes.
          </p>
        </div>

        {/* 3 Step Interactive Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left step selectors */}
          <div className="lg:col-span-6 space-y-4">
            {steps.map((s, idx) => (
              <div
                key={idx}
                onClick={() => setActiveStep(idx)}
                className={`cursor-pointer p-6 rounded-2xl border transition-all duration-300 ${
                  activeStep === idx
                    ? 'bg-white border-indigo-300 shadow-xl shadow-indigo-500/5 ring-2 ring-indigo-500/20'
                    : 'bg-white/60 border-slate-200 hover:bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-start gap-4">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 transition-colors ${
                      activeStep === idx
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {s.step}
                  </div>
                  <div className="space-y-1.5 flex-1">
                    <h3 className="text-base sm:text-lg font-bold text-slate-900">
                      {s.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                      {s.description}
                    </p>
                    <div className="text-xs font-medium text-indigo-600 pt-1 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
                      <span>{s.highlight}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Right dynamic preview */}
          <div className="lg:col-span-6">
            <div className="bg-slate-900 p-6 sm:p-8 rounded-3xl text-white shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none"></div>

              <div className="flex items-center justify-between pb-6 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500"></div>
                  <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                  <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                  <span className="text-xs text-slate-400 font-mono ml-2">ReceptionAI Engine • Step {steps[activeStep].step}</span>
                </div>
                <span className="text-xs bg-indigo-950 text-indigo-300 px-2.5 py-1 rounded-md border border-indigo-800">
                  Live Flow
                </span>
              </div>

              <div className="py-6">
                {steps[activeStep].mockContent}
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                <span className="text-xs text-slate-400">Ready to test it in real-time?</span>
                <button
                  onClick={() => onNavigate('receptionist')}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors"
                >
                  Launch Interactive Demo
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
