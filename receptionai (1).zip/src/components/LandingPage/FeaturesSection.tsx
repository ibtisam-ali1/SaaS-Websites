import React from 'react';
import { 
  Headphones, 
  CalendarCheck, 
  Sparkles, 
  Zap, 
  ShieldCheck, 
  PhoneCall, 
  Users, 
  BellRing,
  Clock,
  Layers,
  BarChart3,
  Bot
} from 'lucide-react';

export const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: <Headphones className="w-6 h-6 text-indigo-600" />,
      title: '24/7 Multi-Channel Reception',
      description: 'Answers web chat inquiries, phone calls, SMS texts, and WhatsApp messages simultaneously with zero wait time and human-level empathy.'
    },
    {
      icon: <CalendarCheck className="w-6 h-6 text-indigo-600" />,
      title: 'Real-Time Calendar Booking',
      description: 'Bi-directionally syncs with Google Calendar, Outlook, and practice management software. Enforces custom buffers, doctor availability, and cancellation policies.'
    },
    {
      icon: <Zap className="w-6 h-6 text-indigo-600" />,
      title: 'Automated Lead Qualification',
      description: 'Scores leads based on customer budget, urgency, and procedure intent. Sends hot prospect notifications immediately to your sales or intake team.'
    },
    {
      icon: <Users className="w-6 h-6 text-indigo-600" />,
      title: 'Warm Human Handoff',
      description: 'When complex inquiries or emergency clinical situations arise, ReceptionAI instantly bridges callers to on-duty staff with a structured conversational transcript.'
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-indigo-600" />,
      title: 'HIPAA & SOC 2 Security',
      description: 'Built with enterprise encryption, signed Business Associate Agreements (BAA), and zero-training data leakage protocols for sensitive medical or legal consultations.'
    },
    {
      icon: <BarChart3 className="w-6 h-6 text-indigo-600" />,
      title: 'Conversational Intelligence',
      description: 'Uncovers lost demand patterns, after-hours booking surges, common patient objections, and missed revenue opportunities with actionable AI insights.'
    }
  ];

  return (
    <section id="features" className="py-20 bg-white border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold border border-indigo-200/60">
            <Sparkles className="w-3.5 h-3.5" />
            Core Capabilities
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Engineered to Run Your Front Desk with Total Precision
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Everything your business needs to turn anonymous website visitors and ringing callers into confirmed, paid appointments.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((item, idx) => (
            <div
              key={idx}
              className="group p-7 rounded-2xl bg-slate-50/70 hover:bg-white border border-slate-200/80 hover:border-indigo-200 hover:shadow-xl hover:shadow-indigo-500/5 transition-all duration-300 flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-center group-hover:scale-110 group-hover:border-indigo-300 transition-all">
                  {item.icon}
                </div>
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {item.title}
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-200/60 flex items-center text-xs font-semibold text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity">
                <span>Learn how it works &rarr;</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
