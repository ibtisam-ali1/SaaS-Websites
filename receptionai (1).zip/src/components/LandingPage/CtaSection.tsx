import React from 'react';
import { AppView } from '../../types';
import { Bot, ArrowRight, Calendar, ShieldCheck, Sparkles } from 'lucide-react';

interface CtaSectionProps {
  onNavigate: (view: AppView) => void;
}

export const CtaSection: React.FC<CtaSectionProps> = ({ onNavigate }) => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative bg-gradient-to-tr from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-8 sm:p-14 text-white overflow-hidden shadow-2xl">
          
          {/* Decorative background blurs */}
          <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-96 h-96 bg-violet-500/20 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 max-w-3xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-900/60 text-indigo-300 text-xs font-semibold border border-indigo-700/60">
              <Sparkles className="w-3.5 h-3.5" />
              Instant 15-Minute Deployment
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-tight">
              Ready to Upgrade to a 24/7 AI Receptionist?
            </h2>

            <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
              Join more than 1,400 forward-thinking clinics, practices, law firms, and studios. Deliver instant, compassionate client service without burning out your front desk.
            </p>

            {/* CTAs */}
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => onNavigate('receptionist')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm sm:text-base shadow-xl shadow-indigo-600/30 transition-all transform hover:-translate-y-0.5"
              >
                <Bot className="w-5 h-5" />
                Test AI Receptionist Live
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigate('booking')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-4 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-sm sm:text-base border border-white/20 backdrop-blur-sm transition-all"
              >
                <Calendar className="w-5 h-5 text-indigo-300" />
                Book Client Appointment
              </button>
            </div>

            {/* Trust points */}
            <div className="pt-6 border-t border-slate-800/80 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>14-Day Full Access Trial</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>No Credit Card Required</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Cancel Anytime with 1 Click</span>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
