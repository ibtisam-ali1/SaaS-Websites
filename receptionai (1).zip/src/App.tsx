import React, { useState } from 'react';
import { 
  AppView, 
  DashboardSubView, 
  Appointment, 
  Conversation, 
  Lead, 
  BusinessConfig 
} from './types';
import { 
  mockConversations, 
  mockAppointments, 
  mockLeads, 
  initialBusinessConfig 
} from './data/mockData';
import { ToastProvider } from './components/Toast';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

// Landing Page Components
import { HeroSection } from './components/LandingPage/HeroSection';
import { FeaturesSection } from './components/LandingPage/FeaturesSection';
import { HowItWorksSection } from './components/LandingPage/HowItWorksSection';
import { IndustrySolutions } from './components/LandingPage/IndustrySolutions';
import { BenefitsSection } from './components/LandingPage/BenefitsSection';
import { TestimonialsSection } from './components/LandingPage/TestimonialsSection';
import { PricingSection } from './components/LandingPage/PricingSection';
import { FaqSection } from './components/LandingPage/FaqSection';
import { CtaSection } from './components/LandingPage/CtaSection';

// Receptionist Live Interactive Interface
import { ReceptionistInterface } from './components/ReceptionistDemo/ReceptionistInterface';
import { FloatingReceptionistWidget } from './components/FloatingReceptionistWidget';

// Appointment Booking Flow
import { BookingFlow } from './components/Booking/BookingFlow';

// Dashboard Components
import { DashboardLayout } from './components/Dashboard/DashboardLayout';
import { OverviewView } from './components/Dashboard/OverviewView';
import { ConversationsView } from './components/Dashboard/ConversationsView';
import { AppointmentsView } from './components/Dashboard/AppointmentsView';
import { LeadsView } from './components/Dashboard/LeadsView';
import { AnalyticsView } from './components/Dashboard/AnalyticsView';
import { SettingsView } from './components/Dashboard/SettingsView';

export default function App() {
  // Primary application navigation
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [dashboardSubView, setDashboardSubView] = useState<DashboardSubView>('overview');

  // Shared persistent state across the session
  const [conversations, setConversations] = useState<Conversation[]>(mockConversations);
  const [appointments, setAppointments] = useState<Appointment[]>(mockAppointments);
  const [leads, setLeads] = useState<Lead[]>(mockLeads);
  const [businessConfig, setBusinessConfig] = useState<BusinessConfig>(initialBusinessConfig);

  // Selected state for deep linking between views
  const [selectedConversationId, setSelectedConversationId] = useState<string | undefined>(undefined);
  const [preselectedServiceId, setPreselectedServiceId] = useState<string | undefined>(undefined);

  // Navigate handler with window scroll reset
  const handleNavigate = (view: AppView, subView?: DashboardSubView) => {
    setCurrentView(view);
    if (subView) {
      setDashboardSubView(subView);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Add new appointment handler
  const handleAppointmentCreated = (newApt: Appointment) => {
    setAppointments((prev) => [newApt, ...prev]);
  };

  // Add new lead handler
  const handleLeadCreated = (newLead: Lead) => {
    setLeads((prev) => [newLead, ...prev]);
  };

  // Update conversation handler
  const handleConversationUpdated = (updated: Conversation) => {
    setConversations((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
  };

  return (
    <ToastProvider>
      <div className="min-h-screen bg-white text-slate-900 font-sans antialiased flex flex-col selection:bg-indigo-500 selection:text-white">
        
        {/* Global Navigation Bar - shown on landing, booking, and receptionist demo */}
        {currentView !== 'dashboard' && (
          <Navbar currentView={currentView} onNavigate={handleNavigate} />
        )}

        {/* ================= VIEW 1: PUBLIC MARKETING LANDING PAGE ================= */}
        {currentView === 'landing' && (
          <main className="flex-1">
            <HeroSection onNavigate={handleNavigate} />
            <FeaturesSection />
            <HowItWorksSection onNavigate={handleNavigate} />
            <IndustrySolutions onNavigate={handleNavigate} />
            <BenefitsSection />
            <TestimonialsSection />
            <PricingSection onNavigate={handleNavigate} />
            <FaqSection />
            <CtaSection onNavigate={handleNavigate} />
            <Footer onNavigate={handleNavigate} />
          </main>
        )}

        {/* ================= VIEW 2: AI RECEPTIONIST FULL-SCREEN DEMO ================= */}
        {currentView === 'receptionist' && (
          <main className="flex-1 bg-slate-950">
            <ReceptionistInterface 
              onNavigate={handleNavigate} 
              onLaunchBooking={() => handleNavigate('booking')}
              onBookService={(serviceId) => {
                if (serviceId) setPreselectedServiceId(serviceId);
                handleNavigate('booking');
              }}
              businessConfig={businessConfig}
              onAppointmentCreated={handleAppointmentCreated}
              onLeadCaptured={handleLeadCreated}
            />
          </main>
        )}

        {/* ================= VIEW 3: APPOINTMENT BOOKING WIZARD ================= */}
        {currentView === 'booking' && (
          <main className="flex-1 bg-slate-50">
            <BookingFlow
              onNavigate={handleNavigate}
              preselectedServiceId={preselectedServiceId}
              onAppointmentCreated={handleAppointmentCreated}
            />
          </main>
        )}

        {/* ================= VIEW 4: BUSINESS DASHBOARD SUITE ================= */}
        {currentView === 'dashboard' && (
          <DashboardLayout
            currentSubView={dashboardSubView}
            onSelectSubView={setDashboardSubView}
            onNavigate={handleNavigate}
            businessConfig={businessConfig}
            unreadCount={conversations.filter((c) => c.status === 'escalated').length}
          >
            {/* Sub-view: Overview */}
            {dashboardSubView === 'overview' && (
              <OverviewView
                conversations={conversations}
                appointments={appointments}
                leads={leads}
                onSelectSubView={setDashboardSubView}
                onSelectConversation={(convId) => {
                  setSelectedConversationId(convId);
                  setDashboardSubView('conversations');
                }}
                onNavigate={handleNavigate}
              />
            )}

            {/* Sub-view: Conversations Inbox */}
            {dashboardSubView === 'conversations' && (
              <ConversationsView
                conversations={conversations}
                selectedConvId={selectedConversationId}
                onUpdateConversation={handleConversationUpdated}
                onBookForCustomer={(custName) => {
                  handleNavigate('booking');
                }}
              />
            )}

            {/* Sub-view: Appointments Schedule */}
            {dashboardSubView === 'appointments' && (
              <AppointmentsView
                appointments={appointments}
                onOpenBooking={() => handleNavigate('booking')}
                onUpdateAppointment={(apt) => {
                  setAppointments((prev) => prev.map((a) => (a.id === apt.id ? apt : a)));
                }}
              />
            )}

            {/* Sub-view: Leads Pipeline */}
            {dashboardSubView === 'leads' && (
              <LeadsView
                leads={leads}
                onAddLead={handleLeadCreated}
                onUpdateLead={(updated) => {
                  setLeads((prev) => prev.map((l) => (l.id === updated.id ? updated : l)));
                }}
                onBookForLead={(leadName) => {
                  handleNavigate('booking');
                }}
              />
            )}

            {/* Sub-view: Analytics & AI Insights */}
            {dashboardSubView === 'analytics' && <AnalyticsView />}

            {/* Sub-view: Settings */}
            {dashboardSubView === 'settings' && (
              <SettingsView
                businessConfig={businessConfig}
                onUpdateConfig={setBusinessConfig}
              />
            )}
          </DashboardLayout>
        )}

        {/* Global Floating AI Receptionist (available on Landing, Booking, Dashboard) */}
        {currentView !== 'receptionist' && (
          <FloatingReceptionistWidget
            businessConfig={businessConfig}
            onNavigate={handleNavigate}
            onLaunchBooking={(serviceId) => {
              if (serviceId) setPreselectedServiceId(serviceId);
              handleNavigate('booking');
            }}
          />
        )}

      </div>
    </ToastProvider>
  );
}
