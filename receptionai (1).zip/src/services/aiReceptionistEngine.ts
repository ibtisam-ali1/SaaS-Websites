import { Service, ChatMessage, BusinessConfig, KnowledgeItem } from '../types';
import { mockServices } from '../data/mockData';

export interface AIContextState {
  currentIndustry: 'medical' | 'salon' | 'legal' | 'realestate' | 'hvac';
  selectedService?: Service | null;
  selectedDate?: string | null;
  selectedTime?: string | null;
  selectedDoctor?: string | null;
  patientName?: string | null;
  patientPhone?: string | null;
  bookingStep?: 'idle' | 'service_selected' | 'time_selected' | 'contact_needed' | 'confirmed';
  lastIntent?: string;
  conversationHistory: { role: 'user' | 'ai'; text: string }[];
}

export interface AIResponseResult {
  replyText: string;
  type: ChatMessage['type'];
  data?: any;
  aiAnalysis: {
    intent: string;
    confidence: number;
    sentiment: 'positive' | 'neutral' | 'urgent' | 'frustrated';
    entities?: Record<string, string>;
    suggestedFollowUps: string[];
  };
  updatedContext: AIContextState;
}

// Industry specific provider rosters and facts
export const INDUSTRY_DATA = {
  medical: {
    businessName: 'Apex Health Clinic',
    aiName: 'Aria',
    address: '742 Evergreen Terrace, Suite 300, San Francisco, CA',
    phone: '+1 (555) 899-4422',
    hours: 'Monday – Thursday: 8:00 AM – 6:00 PM | Friday: 8:00 AM – 5:00 PM | Saturday: 9:00 AM – 2:00 PM | Sunday: Closed (On-Call triage 24/7)',
    providers: [
      { name: 'Dr. Sarah Chen, MD', specialty: 'Family & Preventive Medicine', rating: 4.9, available: 'Mon, Tue, Wed, Fri' },
      { name: 'Dr. Marcus Vance, MD', specialty: 'Cardiology & Internal Medicine', rating: 5.0, available: 'Mon, Wed, Thu' },
      { name: 'Dr. Elena Rostova, MD', specialty: 'Dermatology & Skin Health', rating: 4.8, available: 'Tue, Thu, Fri' },
      { name: 'Dr. David Kim, DO', specialty: 'Sports Medicine & Orthopedics', rating: 4.9, available: 'Mon, Tue, Sat' },
      { name: 'Sarah Lin, NP', specialty: 'Urgent Care & Family Practice', rating: 4.9, available: 'Daily Walk-in' }
    ],
    insurance: [
      'Blue Cross Blue Shield (PPO/EPO)',
      'Aetna (PPO/HMO with referral)',
      'Cigna HealthCare',
      'UnitedHealthcare (Choice Plus/PPO)',
      'Medicare Part B',
      'Kaiser Permanente (Added Choice only)'
    ],
    faqs: [
      { q: 'What do I need to bring to my visit?', a: 'Please bring a valid government photo ID, your active insurance card, a list of current prescription medications, and copay payment method (Credit card, HSA, FSA).' },
      { q: 'Do I need to fast for blood tests?', a: 'Routine lipid panels and fasting blood glucose require 8 to 12 hours of water-only fasting. Medication is fine with water unless directed otherwise.' },
      { q: 'Is there parking available?', a: 'Yes! We provide 2 hours of complimentary validated parking in the Sutter Square Garage located directly behind our clinic building. Bring your ticket for stamping.' },
      { q: 'What is your cancellation policy?', a: 'We request at least 24 hours advance notice for cancellations or rescheduling. Cancellations made with less than 24h notice may incur a $40 late-cancellation fee.' },
      { q: 'Do you offer telehealth consultations?', a: 'Yes, we conduct secure HIPAA-compliant video consultations for follow-ups, medication reviews, and non-emergency checkups. The rate is $85 or standard insurance copay.' }
    ]
  },
  salon: {
    businessName: 'Luxe & Mane Salon & Day Spa',
    aiName: 'Chloe',
    address: '1048 Ocean Avenue, Santa Monica, CA',
    phone: '+1 (555) 742-8899',
    hours: 'Tuesday – Saturday: 9:00 AM – 7:30 PM | Sunday: 10:00 AM – 5:00 PM | Monday: Closed',
    providers: [
      { name: 'Chloe Laurent', specialty: 'Master Colorist & Balayage Specialist', rating: 5.0, available: 'Tue, Wed, Thu, Fri' },
      { name: 'Alexander Wright', specialty: 'Precision Hair Sculpting & Men\'s Grooming', rating: 4.9, available: 'Tue, Thu, Sat, Sun' },
      { name: 'Sophia Rossi', specialty: 'Aesthetician & Hydrafacial Expert', rating: 4.9, available: 'Wed, Fri, Sat, Sun' }
    ],
    services: [
      { name: 'Signature Balayage & Glaze', price: 240, duration: '150 min' },
      { name: 'Custom Precision Cut & Blowout', price: 95, duration: '60 min' },
      { name: 'Hydrafacial Glow & Lymphatic', price: 185, duration: '60 min' },
      { name: 'Full Keratin Smoothing Treatment', price: 290, duration: '120 min' },
      { name: 'Aromatherapy Deep Tissue Massage', price: 145, duration: '60 min' }
    ]
  },
  legal: {
    businessName: 'Vanguard Legal Advisory Group',
    aiName: 'Justin',
    address: '555 California Street, 42nd Floor, San Francisco, CA',
    phone: '+1 (555) 301-4490',
    hours: 'Monday – Friday: 8:30 AM – 6:30 PM | Weekends by appointment',
    providers: [
      { name: 'Justin Vance, Esq.', specialty: 'Corporate Law, M&A, VC Financing', rating: 5.0, available: 'Mon, Tue, Wed, Thu' },
      { name: 'Rachel Ross, Esq.', specialty: 'Commercial Litigation & IP Protection', rating: 4.9, available: 'Mon, Wed, Fri' },
      { name: 'Michael Chen, Esq.', specialty: 'Estate Planning & Asset Protection', rating: 4.9, available: 'Tue, Thu, Fri' }
    ],
    services: [
      { name: 'Initial Case Evaluation (30 min)', price: 150, duration: '30 min (credited toward retainer)' },
      { name: 'Contract & Operating Agreement Review', price: 450, duration: '60 min' },
      { name: 'Comprehensive Estate Planning Package', price: 1800, duration: '90 min consultation' }
    ]
  },
  realestate: {
    businessName: 'Crestview Luxury Realty',
    aiName: 'Maya',
    address: '8800 Wilshire Blvd, Beverly Hills, CA',
    phone: '+1 (555) 620-1199',
    hours: 'Monday – Saturday: 8:00 AM – 7:00 PM | Sunday: 10:00 AM – 5:00 PM',
    providers: [
      { name: 'Maya Lin', specialty: 'Luxury Residential & Waterfront Estates', rating: 5.0, available: 'Daily' },
      { name: 'David Torres', specialty: 'Investment Properties & Commercial Acquisitions', rating: 4.9, available: 'Mon - Fri' }
    ]
  },
  hvac: {
    businessName: 'Apex Emergency Home & HVAC Services',
    aiName: 'Tyler',
    address: '1200 Industrial Parkway, Oakland, CA',
    phone: '+1 (555) 911-4822',
    hours: '24/7 Emergency Dispatch 365 Days a Year',
    providers: [
      { name: 'Senior Master HVAC Tech Team', specialty: 'AC & Furnace Emergency Repair', rating: 4.9, available: '24/7 Dispatch' },
      { name: 'Certified Plumbing Emergency Specialists', specialty: 'Leak Detection & Pipe Burst', rating: 4.9, available: '24/7 Dispatch' }
    ]
  }
};

/**
 * Intelligent Zero-API Local Natural Language Reasoning Engine
 * Parses natural input, detects intent, extracts entities, and formats rich 100% relevant answers.
 */
export function processUserQuery(
  rawQuery: string,
  context: AIContextState,
  businessConfig: BusinessConfig,
  availableServices: Service[] = mockServices
): AIResponseResult {
  const query = rawQuery.trim();
  const lower = query.toLowerCase();
  const ind = context.currentIndustry;
  const indData = INDUSTRY_DATA[ind] || INDUSTRY_DATA.medical;

  // Track conversation turn
  const updatedContext: AIContextState = {
    ...context,
    conversationHistory: [
      ...context.conversationHistory.slice(-8),
      { role: 'user', text: query }
    ]
  };

  // 1. Check custom business knowledge base first if provided
  if (businessConfig.customKnowledge && businessConfig.customKnowledge.length > 0) {
    for (const item of businessConfig.customKnowledge) {
      const qWords = item.question.toLowerCase().split(/\s+/).filter(w => w.length > 3);
      const matchCount = qWords.filter(w => lower.includes(w)).length;
      if (matchCount >= 2 || lower.includes(item.question.toLowerCase())) {
        return {
          replyText: item.answer,
          type: 'text',
          aiAnalysis: {
            intent: 'custom_knowledge_retrieval',
            confidence: 0.96,
            sentiment: 'positive',
            suggestedFollowUps: ['Schedule an appointment', 'Speak with front desk', 'View operating hours']
          },
          updatedContext
        };
      }
    }
  }

  // 2. Emergency / High Urgency Detection
  const emergencyKeywords = ['chest pain', 'heart attack', 'cannot breathe', 'stroke', 'bleeding heavily', 'passed out', 'pipe burst', 'flooding', 'gas leak', 'sparks', 'fire'];
  const hasEmergency = emergencyKeywords.some(kw => lower.includes(kw));

  if (hasEmergency) {
    if (ind === 'medical') {
      return {
        replyText: '⚠️ URGENT CLINICAL NOTICE: If you or someone you are with is experiencing severe chest pain, shortness of breath, loss of consciousness, or signs of a stroke, please immediately dial 911 or visit the nearest Emergency Room.\n\nFor non-life-threatening urgent triage, our on-call clinical nurse line is reachable 24/7 at +1 (555) 899-4422 (Press 1 for Urgent).',
        type: 'emergency_banner',
        data: {
          phone: '+1 (555) 899-4422',
          title: 'Emergency Medical Triage Protocol',
          urgentInstruction: 'For immediate life threats call 911 immediately'
        },
        aiAnalysis: {
          intent: 'emergency_urgent',
          confidence: 0.99,
          sentiment: 'urgent',
          suggestedFollowUps: ['Call 911 Emergency', 'Call On-Duty Nurse', 'Book Urgent Care slot']
        },
        updatedContext
      };
    } else if (ind === 'hvac') {
      return {
        replyText: '🚨 EMERGENCY DISPATCH ALERT: For active water pipe bursts, electrical sparks, or gas odors, please shut off your main valve immediately. Our on-call emergency crew can be dispatched in under 45 minutes.\n\nCalling dispatch hotline: +1 (555) 911-4822.',
        type: 'emergency_banner',
        data: {
          phone: '+1 (555) 911-4822',
          title: 'Urgent Home Emergency Dispatch',
          urgentInstruction: '24/7 Fast Response Team on standby'
        },
        aiAnalysis: {
          intent: 'emergency_urgent',
          confidence: 0.99,
          sentiment: 'urgent',
          suggestedFollowUps: ['Request Immediate Dispatch', 'Call Dispatch Hotline', 'Get Emergency Valve Guide']
        },
        updatedContext
      };
    }
  }

  // 3. Greeting / Pleasantry Detection
  const greetingKeywords = ['hello', 'hi ', 'hi!', 'hey', 'good morning', 'good afternoon', 'good evening', 'howdy', 'greetings'];
  const isGreeting = greetingKeywords.some(kw => lower.startsWith(kw) || lower === kw.trim());
  if (isGreeting && query.length < 35) {
    const greetingText = `Hello and welcome! I am ${businessConfig.aiName || indData.aiName}, your dedicated 24/7 virtual receptionist for ${businessConfig.name || indData.businessName}.\n\nI can instantly help you with:\n• 📅 Scheduling & rescheduling appointments\n• 💰 Checking pricing, treatments & specialist bios\n• 🛡️ Verifying insurance coverage & payment options\n• 📍 Hours, address & validated parking directions\n\nHow may I assist you today?`;
    return {
      replyText: greetingText,
      type: 'text',
      aiAnalysis: {
        intent: 'greeting',
        confidence: 0.98,
        sentiment: 'positive',
        suggestedFollowUps: [
          'Book an appointment',
          'What are your services and prices?',
          'What insurance do you accept?',
          'What are your hours today?'
        ]
      },
      updatedContext
    };
  }

  // 4. Booking Request & Appointment Intent Detection
  const bookingKeywords = [
    'book', 'appointment', 'schedule', 'reserve', 'slot', 'see a doctor', 'see dr', 'consultation',
    'visit', 'checkup', 'exam', 'haircut', 'massage', 'facial', 'reserving', 'meeting'
  ];
  const isBookingIntent = bookingKeywords.some(kw => lower.includes(kw));

  // Date and time entity extraction
  let detectedDate = '';
  if (lower.includes('today')) detectedDate = 'Today';
  else if (lower.includes('tomorrow')) detectedDate = 'Tomorrow';
  else if (lower.includes('monday')) detectedDate = 'Monday';
  else if (lower.includes('tuesday')) detectedDate = 'Tuesday';
  else if (lower.includes('wednesday')) detectedDate = 'Wednesday';
  else if (lower.includes('thursday')) detectedDate = 'Thursday';
  else if (lower.includes('friday')) detectedDate = 'Friday';
  else if (lower.includes('saturday')) detectedDate = 'Saturday';
  else if (lower.includes('next week')) detectedDate = 'Next Week';

  let detectedTime = '';
  if (lower.includes('morning') || lower.includes('am')) detectedTime = 'Morning (9:00 AM – 12:00 PM)';
  else if (lower.includes('afternoon') || lower.includes('pm')) detectedTime = 'Afternoon (1:00 PM – 4:00 PM)';
  else if (lower.includes('evening') || lower.includes('late')) detectedTime = 'Evening (4:30 PM – 6:00 PM)';

  // Check if user specifically requested a service
  const matchedService = availableServices.find(s => 
    lower.includes(s.name.toLowerCase()) || 
    (s.category && lower.includes(s.category.toLowerCase())) ||
    (s.id && lower.includes(s.id.toLowerCase()))
  );

  if (isBookingIntent) {
    if (matchedService) {
      updatedContext.selectedService = matchedService;
      updatedContext.bookingStep = 'service_selected';
      
      return {
        replyText: `Excellent choice! I have marked you for a **${matchedService.name}** ($${matchedService.price}, ${matchedService.durationMinutes} minutes).\n\nHere are our upcoming verified openings. Select a convenient time slot below or click to confirm:`,
        type: 'interactive_slots',
        data: {
          service: matchedService,
          slots: [
            { id: 's1', day: 'Tomorrow', time: '09:30 AM', doctor: 'Dr. Sarah Chen, MD' },
            { id: 's2', day: 'Tomorrow', time: '02:15 PM', doctor: 'Dr. Marcus Vance, MD' },
            { id: 's3', day: 'Thursday', time: '11:00 AM', doctor: 'Dr. Elena Rostova, MD' },
            { id: 's4', day: 'Friday', time: '03:45 PM', doctor: 'Dr. Sarah Chen, MD' }
          ]
        },
        aiAnalysis: {
          intent: 'booking_service_selected',
          confidence: 0.95,
          sentiment: 'positive',
          entities: { service: matchedService.name, date: detectedDate, time: detectedTime },
          suggestedFollowUps: [
            'Tomorrow at 09:30 AM',
            'Tomorrow at 02:15 PM',
            'Choose another doctor',
            'Do you take my insurance?'
          ]
        },
        updatedContext
      };
    }

    // General booking without specific service selected
    return {
      replyText: `I would be delighted to schedule your visit at ${businessConfig.name || indData.businessName}! We have openings throughout this week.\n\nPlease select the service you would like to book, or click below to open our interactive booking scheduler:`,
      type: 'service_list',
      data: availableServices,
      aiAnalysis: {
        intent: 'booking_inquiry',
        confidence: 0.94,
        sentiment: 'positive',
        entities: { date: detectedDate, time: detectedTime },
        suggestedFollowUps: [
          'Comprehensive Physical ($195)',
          'Urgent Illness Consultation ($120)',
          'Cardiology Consultation ($285)',
          'Telehealth Video Visit ($85)'
        ]
      },
      updatedContext
    };
  }

  // 5. Pricing, Costs & Payment Questions
  const pricingKeywords = ['price', 'pricing', 'cost', 'how much', 'fee', 'charge', 'rate', 'expensive', 'copay', 'bill', 'afford', 'cash'];
  if (pricingKeywords.some(kw => lower.includes(kw))) {
    if (matchedService) {
      return {
        replyText: `The fee for **${matchedService.name}** is **$${matchedService.price}** for a ${matchedService.durationMinutes}-minute session.\n\n• **With In-Network Insurance**: Most patients pay only their standard specialist copay ($20 – $45).\n• **Self-Pay Patients**: We provide a 20% prompt-pay discount if paid at the time of service, as well as 0% interest payment plans via CareCredit.\n• **HSA/FSA**: Fully eligible with an itemized receipt provided on the spot.`,
        type: 'text',
        aiAnalysis: {
          intent: 'pricing_inquiry',
          confidence: 0.97,
          sentiment: 'neutral',
          entities: { service: matchedService.name, price: `$${matchedService.price}` },
          suggestedFollowUps: [
            `Book ${matchedService.name}`,
            'Check insurance acceptance',
            'What payment methods are accepted?'
          ]
        },
        updatedContext
      };
    }

    // General pricing overview
    const servicePriceLines = availableServices.slice(0, 5).map(s => `• **${s.name}**: $${s.price} (${s.durationMinutes} min)`).join('\n');
    return {
      replyText: `Here is our transparent price guide for standard outpatient services at ${businessConfig.name || indData.businessName}:\n\n${servicePriceLines}\n\n*All clinical services include full medical intake, evaluation, prescription routing, and physician follow-up instructions. We also accept all major PPO health insurances which usually cover 70%–100% of costs.*`,
      type: 'service_list',
      data: availableServices,
      aiAnalysis: {
        intent: 'pricing_catalog',
        confidence: 0.95,
        sentiment: 'neutral',
        suggestedFollowUps: [
          'Book an appointment',
          'Do you accept Blue Cross or Aetna?',
          'Do you offer payment plans?'
        ]
      },
      updatedContext
    };
  }

  // 6. Insurance & Coverage Queries
  const insuranceKeywords = ['insurance', 'coverage', 'covered', 'ppo', 'hmo', 'medicare', 'aetna', 'blue cross', 'blueshield', 'cigna', 'unitedhealthcare', 'uhc', 'kaiser', 'hsa', 'fsa'];
  if (insuranceKeywords.some(kw => lower.includes(kw))) {
    const insuranceList = (indData as any).insurance ? (indData as any).insurance.map((ins: string) => `• ${ins}`).join('\n') : '• Major PPO plans accepted';
    return {
      replyText: `At ${businessConfig.name || indData.businessName}, we are proud to be in-network with the following major providers:\n\n${insuranceList}\n\n**Key Details:**\n• **Copays**: Collected at check-in (usually $20 to $50 based on your plan tier).\n• **HSA & FSA**: All medical services and prescribed lab tests are 100% HSA/FSA eligible.\n• **Out-of-Network**: We provide a formal Superbill with ICD-10 diagnostic codes for full reimbursement from your carrier.\n\nWould you like our front desk to verify your specific policy number right now?`,
      type: 'insurance_card',
      data: {
        acceptedCarriers: (indData as any).insurance || [],
        hsaEligible: true,
        superbillProvided: true
      },
      aiAnalysis: {
        intent: 'insurance_verification',
        confidence: 0.98,
        sentiment: 'positive',
        suggestedFollowUps: [
          'Verify my insurance plan',
          'Book with Dr. Sarah Chen',
          'What is self-pay pricing?'
        ]
      },
      updatedContext
    };
  }

  // 7. Hours, Operating Schedule & Walk-ins
  const hoursKeywords = ['hour', 'open', 'close', 'schedule', 'sunday', 'saturday', 'weekend', 'today', 'holiday', 'walk in', 'walk-in', 'time'];
  if (hoursKeywords.some(kw => lower.includes(kw))) {
    return {
      replyText: `Here is our current operating schedule at **${businessConfig.name || indData.businessName}**:\n\n• **Monday – Thursday**: 8:00 AM – 6:00 PM\n• **Friday**: 8:00 AM – 5:00 PM\n• **Saturday**: 9:00 AM – 2:00 PM (Urgent Care & Family Practice)\n• **Sunday**: Closed for routine visits (On-Call Nurse Triage 24/7)\n\n**Walk-in Policy**: Walk-in patients are welcomed for urgent issues without an appointment! For specialist consultations, advance booking is recommended to avoid waiting.`,
      type: 'hours_card',
      data: {
        hours: indData.hours,
        address: indData.address,
        phone: indData.phone
      },
      aiAnalysis: {
        intent: 'hours_inquiry',
        confidence: 0.97,
        sentiment: 'neutral',
        suggestedFollowUps: [
          'Book a morning slot',
          'Where is your clinic located?',
          'Is parking free?'
        ]
      },
      updatedContext
    };
  }

  // 8. Location, Directions, Parking & Accessibility
  const locationKeywords = ['location', 'where', 'address', 'directions', 'park', 'parking', 'garage', 'transit', 'bus', 'subway', 'wheelchair', 'accessible'];
  if (locationKeywords.some(kw => lower.includes(kw))) {
    return {
      replyText: `We are conveniently located in central San Francisco:\n\n📍 **Address**: ${businessConfig.address || indData.address}\n\n🚗 **Complimentary Parking**: 2 hours of free validated parking is provided at the **Sutter Square Garage** located directly behind our building (entrance on Pine St). Bring your parking ticket to reception for validation!\n\n♿ **Accessibility**: Fully ADA compliant with street-level wheelchair ramps and dual elevators directly to Suite 300.`,
      type: 'text',
      aiAnalysis: {
        intent: 'location_parking',
        confidence: 0.96,
        sentiment: 'positive',
        suggestedFollowUps: [
          'Schedule my visit',
          'What are your hours today?',
          'Call front desk'
        ]
      },
      updatedContext
    };
  }

  // 9. Doctor, Specialist & Staff Inquiries
  const doctorKeywords = ['doctor', 'physician', 'specialist', 'dr', 'who works', 'staff', 'team', 'pediatrician', 'cardiologist', 'dermatologist', 'chen', 'vance', 'rostova'];
  if (doctorKeywords.some(kw => lower.includes(kw))) {
    const providersList = (indData.providers || []).map((p: any) => `• **${p.name}** — ${p.specialty} ⭐ ${p.rating}/5.0 (Available: ${p.available})`).join('\n');
    return {
      replyText: `Our board-certified attending specialists at ${businessConfig.name || indData.businessName} include:\n\n${providersList}\n\nAll of our physicians have over 10+ years of clinical experience from top academic medical centers and hold active state licenses.\n\nWould you like to schedule with a specific doctor?`,
      type: 'provider_card',
      data: indData.providers,
      aiAnalysis: {
        intent: 'doctor_inquiry',
        confidence: 0.96,
        sentiment: 'positive',
        suggestedFollowUps: [
          'Book with Dr. Sarah Chen',
          'Book with Dr. Marcus Vance',
          'Book with Dr. Elena Rostova',
          'View services & pricing'
        ]
      },
      updatedContext
    };
  }

  // 10. Rescheduling, Cancellation & Appointment Status
  const rescheduleKeywords = ['reschedule', 'cancel', 'change my appointment', 'move my slot', 'running late', 'postpone', 'check status'];
  if (rescheduleKeywords.some(kw => lower.includes(kw))) {
    return {
      replyText: `I can easily help you reschedule or cancel your appointment without any hassle!\n\n• **Our Policy**: Free rescheduling anytime up to 24 hours prior to your scheduled time.\n• **Quick Action**: Please provide your booking reference code (e.g. #APX-4829) or your phone number, and I will pull up your appointment right away.`,
      type: 'reschedule_tool',
      data: {
        policy: '24-hour notice requested. No fee for rescheduling.',
        supportPhone: businessConfig.phone || indData.phone
      },
      aiAnalysis: {
        intent: 'reschedule_cancellation',
        confidence: 0.97,
        sentiment: 'neutral',
        suggestedFollowUps: [
          'Lookup with Phone Number',
          'Check cancellation policy',
          'Speak with Receptionist'
        ]
      },
      updatedContext
    };
  }

  // 11. Pre-Visit Preparation & Intake Checklist
  const prepKeywords = ['prepare', 'bring', 'fast', 'fasting', 'intake', 'paperwork', 'what to expect', 'first visit', 'new patient'];
  if (prepKeywords.some(kw => lower.includes(kw))) {
    return {
      replyText: `Here is our **New Patient Checklist** to ensure a smooth visit:\n\n1. **Identification**: Government-issued photo ID (Driver's License or Passport).\n2. **Insurance**: Active insurance card or digital policy barcode.\n3. **Medications**: List of current prescriptions, supplements, and dosages.\n4. **Fasting Notice**: If you have scheduled blood panels (lipid or comprehensive metabolic), remember to fast for 8–12 hours (water only).\n5. **Arrival Time**: Please arrive 10 minutes prior to your slot to complete check-in on our digital iPads.\n\nYou can also complete your intake forms online beforehand!`,
      type: 'text',
      aiAnalysis: {
        intent: 'visit_preparation',
        confidence: 0.96,
        sentiment: 'positive',
        suggestedFollowUps: [
          'Book New Patient Physical',
          'Where do I park?',
          'Check accepted insurance'
        ]
      },
      updatedContext
    };
  }

  // 12. Human Receptionist Escalation / Handoff
  const humanKeywords = ['human', 'real person', 'agent', 'operator', 'representative', 'talk to someone', 'speak to staff', 'call me', 'manager'];
  if (humanKeywords.some(kw => lower.includes(kw))) {
    return {
      replyText: `Certainly! I will immediately facilitate a warm connection with our on-duty front desk coordinator at ${businessConfig.name || indData.businessName}.\n\nYou can directly call our line at **${businessConfig.escalationPhone || businessConfig.phone || indData.phone}**, or leave your contact details below for an immediate callback:`,
      type: 'lead_form',
      data: {
        phone: businessConfig.escalationPhone || businessConfig.phone || indData.phone,
        directTransferAvailable: true
      },
      aiAnalysis: {
        intent: 'human_escalation',
        confidence: 0.98,
        sentiment: 'neutral',
        suggestedFollowUps: [
          'Request instant callback',
          'Call front desk now',
          'Return to AI Assistant'
        ]
      },
      updatedContext
    };
  }

  // 13. Symptom Triage & "Help me choose" Service Guidance
  const symptomKeywords = ['sick', 'headache', 'cough', 'fever', 'pain', 'symptom', 'not feeling well', 'hurt', 'dizzy', 'rash', 'advice', 'help me choose', 'recommend'];
  if (symptomKeywords.some(kw => lower.includes(kw))) {
    let guidance = '';
    if (lower.includes('fever') || lower.includes('cough') || lower.includes('cold') || lower.includes('flu') || lower.includes('throat')) {
      guidance = `Based on your respiratory symptoms, an **Urgent Illness Consultation** ($120) or a same-day **Telehealth Video Visit** ($85) would be most suitable. Our clinicians can evaluate you, perform rapid strep/flu testing, and send prescriptions directly to your pharmacy.`;
    } else if (lower.includes('rash') || lower.includes('skin') || lower.includes('mole') || lower.includes('acne')) {
      guidance = `For dermatological concerns, we recommend a **Dermatology Consultation** ($160) with Dr. Elena Rostova. She specializes in skin checks, dermatitis treatments, and custom skin care regimens.`;
    } else if (lower.includes('chest') || lower.includes('heart') || lower.includes('blood pressure') || lower.includes('palpitation')) {
      guidance = `For cardiovascular or blood pressure monitoring, an in-depth **Specialist Cardiology Consultation** ($285) with Dr. Marcus Vance includes a 12-lead resting ECG and clinical assessment. *(Note: For sudden acute chest pressure, dial 911).*`;
    } else {
      guidance = `To ensure you get the best personalized care, our **Comprehensive Annual Physical & Wellness Exam** ($195) or a targeted **Consultation** ($120) covers complete vitals, diagnostic review, and lab orders.`;
    }

    return {
      replyText: `${guidance}\n\nWould you like me to reserve a priority slot with our attending physician?`,
      type: 'triage_card',
      data: {
        symptomSummary: query,
        recommendedServices: availableServices.slice(0, 3)
      },
      aiAnalysis: {
        intent: 'symptom_triage',
        confidence: 0.94,
        sentiment: 'neutral',
        suggestedFollowUps: [
          'Book recommended service',
          'Check next available doctor',
          'Speak with on-duty nurse'
        ]
      },
      updatedContext
    };
  }

  // 14. Intelligent Fallback with deep context preservation
  // Instead of a generic "I don't know", generate an intelligent, context-aware receptionist answer
  return {
    replyText: `Thank you for asking about **"${query}"**.\n\nAt ${businessConfig.name || indData.businessName}, we specialize in comprehensive patient care and seamless coordination. While I am happy to answer any specific questions about our treatments, doctor credentials, insurance, or parking, you can also book directly with our lead clinicians or speak with our front desk team.\n\nHere are some quick actions to assist you:`,
    type: 'booking_prompt',
    data: {
      topic: query,
      services: availableServices.slice(0, 3)
    },
    aiAnalysis: {
      intent: 'general_inquiry_fallback',
      confidence: 0.88,
      sentiment: 'positive',
      suggestedFollowUps: [
        'View all services & prices',
        'Check doctor availability',
        'Ask about insurance plans',
        'Connect with human front desk'
      ]
    },
    updatedContext
  };
}
