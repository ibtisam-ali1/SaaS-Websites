/**
 * Web Speech API and Web Audio API Synthesis Service
 * Provides zero-dependency Text-to-Speech, Speech-to-Text, and procedural audio chimes.
 */

class VoiceService {
  private synth: SpeechSynthesis | null = null;
  private recognition: any = null;
  private audioCtx: AudioContext | null = null;
  public isRecognitionActive: boolean = false;

  constructor() {
    if (typeof window !== 'undefined') {
      if ('speechSynthesis' in window) {
        this.synth = window.speechSynthesis;
      }
      
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = false;
        this.recognition.interimResults = true;
        this.recognition.lang = 'en-US';
      }
    }
  }

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  /**
   * Play procedural pleasant UI chimes with Web Audio API (zero audio files needed)
   */
  public playSound(type: 'message_incoming' | 'message_sent' | 'call_connect' | 'call_disconnect' | 'button_tap') {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;

      if (type === 'message_incoming') {
        // High soft two-tone chime
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.12); // A5
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
        osc.start(now);
        osc.stop(now + 0.3);
      } else if (type === 'message_sent') {
        // Light pop chime
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.08);
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.start(now);
        osc.stop(now + 0.16);
      } else if (type === 'call_connect') {
        // Phone pickup melodic triad
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(659.25, now + 0.1); // E5
        osc.frequency.setValueAtTime(783.99, now + 0.2); // G5
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
        osc.start(now);
        osc.stop(now + 0.48);
      } else if (type === 'call_disconnect') {
        // Soft drop tone
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, now);
        osc.frequency.exponentialRampToValueAtTime(261.63, now + 0.25);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
        osc.start(now);
        osc.stop(now + 0.3);
      } else {
        // Button tap
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, now);
        gain.gain.setValueAtTime(0.03, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
        osc.start(now);
        osc.stop(now + 0.06);
      }
    } catch {
      // Gracefully ignore audio restrictions
    }
  }

  /**
   * Speak text using Web Speech Synthesis
   */
  public speak(
    text: string, 
    options?: { 
      rate?: number; 
      pitch?: number; 
      voiceName?: string;
      onStart?: () => void;
      onEnd?: () => void;
    }
  ) {
    if (!this.synth) return;

    try {
      this.synth.cancel(); // cancel previous utterance

      // Clean markdown tags for natural speech
      const cleaned = text
        .replace(/\*\*(.*?)\*\*/g, '$1')
        .replace(/\*(.*?)\*/g, '$1')
        .replace(/•/g, '')
        .replace(/#+/g, '')
        .replace(/⚠️|📍|🚗|♿|📅|💰|🛡️|🚨/g, '');

      const utterance = new SpeechSynthesisUtterance(cleaned);
      utterance.rate = options?.rate ?? 1.05;
      utterance.pitch = options?.pitch ?? 1.0;

      const voices = this.synth.getVoices();
      if (voices.length > 0) {
        // Prefer natural female English voices like Samantha, Google US English, Victoria, Ava
        const preferredVoice = voices.find(v => 
          (options?.voiceName && v.name.includes(options.voiceName)) ||
          v.name.includes('Samantha') ||
          v.name.includes('Google US English') ||
          v.name.includes('Victoria') ||
          (v.lang.startsWith('en') && v.name.includes('Female')) ||
          (v.lang.startsWith('en') && !v.name.includes('Male'))
        );
        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }
      }

      if (options?.onStart) utterance.onstart = options.onStart;
      if (options?.onEnd) utterance.onend = options.onEnd;
      utterance.onerror = () => {
        if (options?.onEnd) options.onEnd();
      };

      this.synth.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error:', e);
      if (options?.onEnd) options.onEnd();
    }
  }

  /**
   * Stop any active speech synthesis
   */
  public stopSpeaking() {
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch {}
    }
  }

  /**
   * Start listening using SpeechRecognition
   */
  public startListening(callbacks: {
    onTranscript: (transcript: string, isFinal: boolean) => void;
    onStart?: () => void;
    onEnd?: () => void;
    onError?: (err: any) => void;
  }) {
    if (!this.recognition) {
      callbacks.onError?.('Speech recognition is not supported in this browser.');
      return;
    }

    try {
      this.stopSpeaking();
      this.isRecognitionActive = true;

      this.recognition.onstart = () => {
        callbacks.onStart?.();
      };

      this.recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        if (finalTranscript) {
          callbacks.onTranscript(finalTranscript, true);
        } else if (interimTranscript) {
          callbacks.onTranscript(interimTranscript, false);
        }
      };

      this.recognition.onerror = (event: any) => {
        this.isRecognitionActive = false;
        callbacks.onError?.(event.error);
      };

      this.recognition.onend = () => {
        this.isRecognitionActive = false;
        callbacks.onEnd?.();
      };

      this.recognition.start();
    } catch (err) {
      this.isRecognitionActive = false;
      callbacks.onError?.(err);
    }
  }

  /**
   * Stop listening
   */
  public stopListening() {
    if (this.recognition && this.isRecognitionActive) {
      try {
        this.recognition.stop();
      } catch {}
      this.isRecognitionActive = false;
    }
  }

  /**
   * Check if speech recognition is available in current browser
   */
  public isSpeechSupported(): boolean {
    if (typeof window === 'undefined') return false;
    return !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
  }
}

export const voiceService = new VoiceService();
