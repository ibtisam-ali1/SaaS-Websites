export type AppView = 
  | 'landing'
  | 'receptionist'
  | 'booking'
  | 'dashboard';

export type DashboardSubView = 
  | 'overview'
  | 'conversations'
  | 'appointments'
  | 'leads'
  | 'customers'
  | 'analytics'
  | 'settings';

export interface Service {
  id: string;
  name: string;
  category: string;
  durationMinutes: number;
  price: number;
  description: string;
  popular?: boolean;
}

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  avatar: string;
  specialties: string[];
  rating: number;
  availableDays: string[];
}

export interface TimeSlot {
  id: string;
  time: string;
  available: boolean;
  period: 'morning' | 'afternoon' | 'evening';
}

export interface Appointment {
  id: string;
  serviceId: string;
  serviceName: string;
  staffId: string;
  staffName: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  notes?: string;
  date: string; // YYYY-MM-DD
  time: string; // e.g. "10:30 AM"
  status: 'confirmed' | 'pending' | 'completed' | 'cancelled';
  price: number;
  createdAt: string;
}

export interface ChatAiAnalysis {
  intent: string;
  confidence: number;
  sentiment: 'positive' | 'neutral' | 'urgent' | 'frustrated';
  entities?: Record<string, string>;
  suggestedFollowUps?: string[];
}

export interface ChatMessage {
  id: string;
  sender: 'ai' | 'user' | 'system' | 'human_agent';
  text: string;
  timestamp: string;
  type?: 
    | 'text' 
    | 'service_list' 
    | 'lead_form' 
    | 'booking_prompt' 
    | 'hours_card' 
    | 'confirmation_card'
    | 'interactive_slots'
    | 'insurance_card'
    | 'triage_card'
    | 'reschedule_tool'
    | 'faq_card'
    | 'emergency_banner'
    | 'provider_card';
  data?: any;
  aiAnalysis?: ChatAiAnalysis;
}

export interface KnowledgeItem {
  id: string;
  question: string;
  answer: string;
  category: string;
  tags?: string[];
}

export interface Conversation {
  id: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  avatar?: string;
  channel: 'web' | 'phone' | 'sms' | 'whatsapp';
  status: 'active' | 'resolved' | 'escalated' | 'appointment_booked';
  isAiHandled: boolean;
  lastMessage: string;
  lastMessageTime: string;
  unread: boolean;
  tags: string[];
  internalNotes: string[];
  leadScore: number;
  estimatedValue: number;
  messages: ChatMessage[];
}

export interface Lead {
  id: string;
  name: string;
  company?: string;
  email: string;
  phone: string;
  source: 'AI Web Chat' | 'AI Phone Call' | 'Inbound SMS' | 'WhatsApp';
  status: 'New' | 'Qualified' | 'Meeting Scheduled' | 'Follow Up' | 'Won' | 'Archived';
  date: string;
  estimatedValue: number;
  intent: 'High' | 'Medium' | 'Low';
  interestService: string;
  notes: string;
  conversationsCount: number;
}

export interface WorkingHourDay {
  day: string;
  isOpen: boolean;
  openTime: string;
  closeTime: string;
}

export interface BusinessConfig {
  name: string;
  industry: string;
  phone: string;
  email: string;
  address: string;
  timezone: string;
  aiName: string;
  aiTone: string;
  welcomeMessage: string;
  bufferMinutes: number;
  noticeHours: number;
  autoConfirm: boolean;
  smsNotifications: boolean;
  emailNotifications: boolean;
  escalationPhone: string;
  aiVoice?: string;
  escalationThreshold?: string;
  systemPrompt?: string;
  bookingBufferMinutes?: number;
  maxAdvanceBookingDays?: number;
  smsNotificationsEnabled?: boolean;
  emailNotificationsEnabled?: boolean;
  workingHours?: WorkingHourDay[];
  customKnowledge?: KnowledgeItem[];
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  title: string;
  message?: string;
}
