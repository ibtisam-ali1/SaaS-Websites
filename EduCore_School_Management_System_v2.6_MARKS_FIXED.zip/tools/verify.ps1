$ErrorActionPreference='Stop'
Write-Host '=== EduCore School Management System Verification ===' -ForegroundColor Cyan
php -v
$files=Get-ChildItem -Recurse -Filter *.php | Where-Object {$_.FullName -notmatch '\\storage\\'}
$failed=0
foreach($f in $files){$out=php -l $f.FullName 2>&1;if($LASTEXITCODE -ne 0){Write-Host "FAIL $($f.FullName)" -ForegroundColor Red;Write-Host $out;$failed++}else{Write-Host "PASS $($f.FullName)" -ForegroundColor Green}}
if(!(Test-Path '.\database\migration_v2_1.sql')){Write-Host 'FAIL database/migration_v2_1.sql missing' -ForegroundColor Red;$failed++}
if(!(Test-Path '.\index.php')){Write-Host 'FAIL root index.php missing' -ForegroundColor Red;$failed++}
if($failed -gt 0){throw "$failed verification checks failed."}
Write-Host "PHP files checked: $($files.Count)" -ForegroundColor Green
Write-Host 'All verification checks passed.' -ForegroundColor Green
