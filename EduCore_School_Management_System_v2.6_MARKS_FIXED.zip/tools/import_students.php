<?php
declare(strict_types=1);
require_once __DIR__.'/../config/bootstrap.php';
if(PHP_SAPI!=='cli'){exit("CLI only\n");}
$file=$argv[1]??''; if(!$file||!is_file($file)){exit("Usage: php tools/import_students.php students.csv\n");}
$fh=fopen($file,'rb');$headers=fgetcsv($fh);$expected=['admission_no','first_name','last_name','date_of_birth','gender','phone','email','address','class_id','enrollment_status','admission_date'];if($headers!==$expected){exit('CSV header must be: '.implode(',',$expected)."\n");}$m=new Student();$ok=0;$fail=0;while(($row=fgetcsv($fh))!==false){if(count($row)!==count($expected)){$fail++;continue;}try{$d=array_combine($expected,$row);$m->create($d);$ok++;}catch(Throwable $e){$fail++;}}fclose($fh);echo "Imported: $ok; Failed: $fail\n";
