USE school_management;
CREATE TABLE IF NOT EXISTS class_subjects(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 class_id BIGINT UNSIGNED NOT NULL,
 subject_id BIGINT UNSIGNED NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_class_subject(class_id,subject_id),
 FOREIGN KEY(class_id) REFERENCES classes(id) ON DELETE CASCADE,
 FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB;
INSERT IGNORE INTO class_subjects(class_id,subject_id)
SELECT c.id,s.id FROM classes c JOIN subjects s ON (c.id=1 OR (c.id=2 AND s.code='SCI'));
