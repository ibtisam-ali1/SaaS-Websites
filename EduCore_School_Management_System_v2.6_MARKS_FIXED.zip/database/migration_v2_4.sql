USE school_management;

-- EduCore 2.4 integrity/usability migration. Safe for an existing v2.x database.
-- Back up school_management before running this file.

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS parent_students(
 parent_id BIGINT UNSIGNED NOT NULL,
 student_id BIGINT UNSIGNED NOT NULL,
 PRIMARY KEY(parent_id,student_id),
 FOREIGN KEY(parent_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS class_subjects(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 class_id BIGINT UNSIGNED NOT NULL,
 subject_id BIGINT UNSIGNED NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_class_subject(class_id,subject_id),
 FOREIGN KEY(class_id) REFERENCES classes(id) ON DELETE CASCADE,
 FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB;

SET @old_name_index := (SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='classes' AND index_name='name');
SET @sql := IF(@old_name_index>0,'ALTER TABLE classes DROP INDEX name','SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @new_index := (SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='classes' AND index_name='uq_class_section_year');
SET @sql2 := IF(@new_index=0,'ALTER TABLE classes ADD UNIQUE KEY uq_class_section_year(name,section,academic_year)','SELECT 1');
PREPARE s2 FROM @sql2; EXECUTE s2; DEALLOCATE PREPARE s2;

ALTER TABLE invoices ADD COLUMN IF NOT EXISTS fee_structure_id BIGINT UNSIGNED NULL AFTER status;
SET @fee_fk := (SELECT COUNT(*) FROM information_schema.table_constraints WHERE constraint_schema=DATABASE() AND table_name='invoices' AND constraint_name='fk_invoice_fee_structure');
SET @sql3 := IF(@fee_fk=0,'ALTER TABLE invoices ADD CONSTRAINT fk_invoice_fee_structure FOREIGN KEY(fee_structure_id) REFERENCES fee_structures(id) ON DELETE SET NULL','SELECT 1');
PREPARE s3 FROM @sql3; EXECUTE s3; DEALLOCATE PREPARE s3;

INSERT IGNORE INTO classes(name,section,academic_year,room) VALUES ('Grade 6','A','2026-27','101'),('Grade 7','A','2026-27','102');
INSERT IGNORE INTO subjects(code,name,max_marks) VALUES ('ENG','English',100),('MATH','Mathematics',100),('SCI','Science',100),('CS','Computer Science',100);
INSERT IGNORE INTO class_subjects(class_id,subject_id) SELECT c.id,s.id FROM classes c CROSS JOIN subjects s;
INSERT INTO users(full_name,email,password_hash,role,status,student_id)
VALUES('Sarah Teacher','teacher@school.test','$2y$12$AGfItMWoCOAv2h0gc6417ehSRDQan98sRWLZns9AGEVxVHyXsU6i2','teacher','active',NULL)
ON DUPLICATE KEY UPDATE full_name=VALUES(full_name),role='teacher',status='active';

SET FOREIGN_KEY_CHECKS=1;
