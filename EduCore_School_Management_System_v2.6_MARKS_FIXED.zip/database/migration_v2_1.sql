USE school_management;

CREATE TABLE IF NOT EXISTS class_subjects(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 class_id BIGINT UNSIGNED NOT NULL,
 subject_id BIGINT UNSIGNED NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_class_subject(class_id,subject_id),
 FOREIGN KEY(class_id) REFERENCES classes(id) ON DELETE CASCADE,
 FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT IGNORE INTO classes(name,section,academic_year,room)
VALUES ('Grade 6','A','2026-27','101');

INSERT IGNORE INTO classes(name,section,academic_year,room)
VALUES ('Grade 7','A','2026-27','102');

INSERT IGNORE INTO subjects(code,name,max_marks)
VALUES ('ENG','English',100);

INSERT IGNORE INTO subjects(code,name,max_marks)
VALUES ('MATH','Mathematics',100);

INSERT IGNORE INTO subjects(code,name,max_marks)
VALUES ('SCI','Science',100);

INSERT IGNORE INTO subjects(code,name,max_marks)
VALUES ('CS','Computer Science',100);

INSERT INTO users(full_name,email,password_hash,role,status,student_id)
VALUES ('Sarah Teacher','teacher@school.test','$2y$12$AGfItMWoCOAv2h0gc6417ehSRDQan98sRWLZns9AGEVxVHyXsU6i2','teacher','active',NULL)
ON DUPLICATE KEY UPDATE full_name=VALUES(full_name),role='teacher',status='active';

INSERT IGNORE INTO class_subjects(class_id,subject_id)
SELECT c.id,s.id FROM classes c CROSS JOIN subjects s WHERE c.name='Grade 6';

INSERT IGNORE INTO class_subjects(class_id,subject_id)
SELECT c.id,s.id FROM classes c JOIN subjects s ON s.code='SCI' WHERE c.name='Grade 7';

INSERT IGNORE INTO timetable(class_id,subject_id,teacher_id,day_of_week,start_time,end_time,room)
SELECT c.id,s.id,u.id,'Monday','08:00','08:45',c.room
FROM classes c JOIN subjects s ON s.code='ENG' JOIN users u ON u.email='teacher@school.test'
WHERE c.name='Grade 6';

INSERT IGNORE INTO timetable(class_id,subject_id,teacher_id,day_of_week,start_time,end_time,room)
SELECT c.id,s.id,u.id,'Monday','09:00','09:45',c.room
FROM classes c JOIN subjects s ON s.code='MATH' JOIN users u ON u.email='teacher@school.test'
WHERE c.name='Grade 6';

INSERT IGNORE INTO timetable(class_id,subject_id,teacher_id,day_of_week,start_time,end_time,room)
SELECT c.id,s.id,u.id,'Tuesday','08:00','08:45',c.room
FROM classes c JOIN subjects s ON s.code='SCI' JOIN users u ON u.email='teacher@school.test'
WHERE c.name='Grade 7';
