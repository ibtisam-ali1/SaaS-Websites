USE school_management;

-- Allow the same class name to have different sections/years.
SET @has_name_index := (SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='classes' AND index_name='name');
SET @drop_name_index := IF(@has_name_index>0,'ALTER TABLE classes DROP INDEX name','SELECT 1');
PREPARE stmt FROM @drop_name_index; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @has_new_index := (SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='classes' AND index_name='uq_class_section_year');
SET @add_new_index := IF(@has_new_index=0,'ALTER TABLE classes ADD UNIQUE KEY uq_class_section_year(name,section,academic_year)','SELECT 1');
PREPARE stmt2 FROM @add_new_index; EXECUTE stmt2; DEALLOCATE PREPARE stmt2;

CREATE TABLE IF NOT EXISTS class_subjects(
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 class_id BIGINT UNSIGNED NOT NULL,
 subject_id BIGINT UNSIGNED NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_class_subject(class_id,subject_id),
 FOREIGN KEY(class_id) REFERENCES classes(id) ON DELETE CASCADE,
 FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT IGNORE INTO classes(name,section,academic_year,room) VALUES ('Grade 6','A','2026-27','101');
INSERT IGNORE INTO classes(name,section,academic_year,room) VALUES ('Grade 7','A','2026-27','102');
INSERT IGNORE INTO subjects(code,name,max_marks) VALUES ('ENG','English',100),('MATH','Mathematics',100),('SCI','Science',100),('CS','Computer Science',100);
INSERT INTO users(full_name,email,password_hash,role,status,student_id)
VALUES ('Sarah Teacher','teacher@school.test','$2y$12$AGfItMWoCOAv2h0gc6417ehSRDQan98sRWLZns9AGEVxVHyXsU6i2','teacher','active',NULL)
ON DUPLICATE KEY UPDATE full_name=VALUES(full_name),role='teacher',status='active';

INSERT IGNORE INTO class_subjects(class_id,subject_id)
SELECT c.id,s.id FROM classes c CROSS JOIN subjects s WHERE c.name='Grade 6';
INSERT IGNORE INTO class_subjects(class_id,subject_id)
SELECT c.id,s.id FROM classes c JOIN subjects s ON s.code='SCI' WHERE c.name='Grade 7';
