# EduCore School Management System v2.6.0

Production-minded PHP 8.3 / MySQL school management application for XAMPP on Windows.

## Core workflows
- Secure login, logout and CSRF-protected POST actions
- Role checks for Super Admin, Teacher, Student, Accountant and Parent
- Student registration, editing, status/archiving and search
- Simple class/section management
- Subject management and automatic allocation to classes
- Teacher management and assignment in timetable/lesson plans
- Timetable creation, editing, deletion and overlap protection
- Lesson plan creation, editing and deletion
- Examination creation and safe class changes
- Direct student mark entry with blank-as-not-entered behavior
- Automatic grades and final result only when all subjects are complete
- Printable report cards
- Class/date attendance with Present, Absent, Late and Not marked
- Fee structures, simple invoices and payment recording
- Light/dark theme with readable contrast

## Existing database upgrade
Back up `school_management` first, then run:

`database/migration_v2_4.sql`

Do not import `database/schema.sql` over an existing production/test database because `schema.sql` intentionally recreates the complete database for fresh installations.

## Fresh installation
1. Copy the project to `C:\xampp\htdocs\SchoolManagementSystem`.
2. Start Apache and MySQL in XAMPP.
3. Import `database/schema.sql` into phpMyAdmin.
4. Open `http://localhost/SchoolManagementSystem/`.
5. Development admin: `admin@school.test` / `Admin@123`.

## Validation
From the project root:

`php -v`

`php -m | findstr /I "PDO pdo_mysql"`

`node --check assets/js/app.js`

`Get-ChildItem -Recurse -Filter *.php | ForEach-Object { php -l $_.FullName }`

Never deploy the seeded development password or XAMPP's empty root password to a public server.


## v2.6 Marks reliability fix
If an existing installation reports that marks could not be saved, run `database/migration_v2_6.sql` once in phpMyAdmin against `school_management`. The marks saver now uses portable INSERT/UPDATE logic and records technical failures in the PHP error log while showing a simple user message.
