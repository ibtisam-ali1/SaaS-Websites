<?php
declare(strict_types=1);
const APP_NAME='EduCore School Management System';
const APP_VERSION='2.6.0';
const BASE_PATH='/SchoolManagementSystem';
const DB_HOST='127.0.0.1';
const DB_NAME='school_management';
const DB_USER='root';
const DB_PASS='';
const SESSION_NAME='educore_session';
const TIMEZONE='Asia/Karachi';
date_default_timezone_set(TIMEZONE);
if(session_status()!==PHP_SESSION_ACTIVE){session_name(SESSION_NAME);session_start(['cookie_httponly'=>true,'cookie_samesite'=>'Lax','use_strict_mode'=>true]);}
