<?php
declare(strict_types=1);
function e(mixed $v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function redirect(string $path):never{header('Location: '.BASE_PATH.$path);exit;}
function flash(string $type,string $message):void{$_SESSION['_flash'][]=['type'=>$type,'message'=>$message];}
function pull_flashes():array{$f=$_SESSION['_flash']??[];unset($_SESSION['_flash']);return $f;}
function csrf_token():string{if(empty($_SESSION['_csrf']))$_SESSION['_csrf']=bin2hex(random_bytes(32));return $_SESSION['_csrf'];}
function csrf_field():string{return '<input type="hidden" name="_csrf" value="'.e(csrf_token()).'">';}
function verify_csrf():void{if(!hash_equals((string)($_SESSION['_csrf']??''),(string)($_POST['_csrf']??''))){http_response_code(419);exit('Invalid or expired CSRF token. Please go back and try again.');}}
function auth_user():?array{return isset($_SESSION['user'])&&is_array($_SESSION['user'])?$_SESSION['user']:null;}
function require_auth():void{if(!auth_user())redirect('/login');}
function require_role(array $roles):void{require_auth();if(!in_array(auth_user()['role']??'', $roles,true)){http_response_code(403);require __DIR__.'/../views/errors/403.php';exit;}}
function old(string $key):string{return e($_POST[$key]??'');}
function post_string(string $key,int $max=255):string{
 $value=trim((string)($_POST[$key]??''));
 return function_exists('mb_substr')?mb_substr($value,0,$max):substr($value,0,$max);
}
function post_int(string $key):int{return max(0,(int)($_POST[$key]??0));}
function post_float(string $key):float{return max(0,(float)($_POST[$key]??0));}
function app_url(string $path=''):string{return BASE_PATH.$path;}
function money(float $v):string{return number_format($v,2);}
function valid_date(string $v):bool{$d=DateTime::createFromFormat('!Y-m-d',$v);return $d && $d->format('Y-m-d')===$v;}
function valid_time(string $v):bool{$d=DateTime::createFromFormat('!H:i',$v);return $d && $d->format('H:i')===$v;}
function selected(mixed $a,mixed $b):string{return (string)$a===(string)$b?'selected':'';}
function checked(bool $v):string{return $v?'checked':'';}
function current_academic_year():string{$y=(int)date('Y');return date('n')>=4?($y.'-'.($y+1)): (($y-1).'-'.$y);}
