<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
require_once __DIR__.'/Database.php';
require_once __DIR__.'/helpers.php';
require_once __DIR__.'/Router.php';
require_once __DIR__.'/../models/BaseModel.php';
foreach (glob(__DIR__.'/../models/*.php') as $file) { if (basename($file)!=='BaseModel.php') require_once $file; }
foreach (glob(__DIR__.'/../controllers/*.php') as $file) require_once $file;
