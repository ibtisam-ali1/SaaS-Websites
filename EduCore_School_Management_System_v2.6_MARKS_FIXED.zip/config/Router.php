<?php
declare(strict_types=1);
final class Router{
 private array $routes=['GET'=>[],'POST'=>[]];
 public function get(string $path,callable $handler):void{$this->routes['GET'][$path]=$handler;}
 public function post(string $path,callable $handler):void{$this->routes['POST'][$path]=$handler;}
 public function dispatch(string $method,string $path):void{
  $path=rtrim($path,'/')?:'/';
  if(isset($this->routes[$method][$path])){call_user_func($this->routes[$method][$path]);return;}
  http_response_code(404);require __DIR__.'/../views/errors/404.php';
 }
}
