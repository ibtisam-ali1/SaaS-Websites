<?php
final class AuthController {
 public function login(): void { if(auth_user()) redirect('/dashboard'); require __DIR__.'/../views/auth/login.php'; }
 public function authenticate(): void { verify_csrf(); $email=filter_var(post_string('email',190),FILTER_VALIDATE_EMAIL); $password=(string)($_POST['password']??''); if(!$email||$password===''){flash('error','Enter a valid email and password.');redirect('/login');} $u=(new User())->findByEmail($email); if(!$u||!password_verify($password,$u['password_hash'])){flash('error','Invalid credentials.');redirect('/login');} session_regenerate_id(true); $_SESSION['user']=['id'=>(int)$u['id'],'full_name'=>$u['full_name'],'email'=>$u['email'],'role'=>$u['role'],'student_id'=>(int)($u['student_id']??0)]; redirect('/dashboard'); }
 public function logout(): void { verify_csrf(); $_SESSION=[]; if(ini_get('session.use_cookies')){ $p=session_get_cookie_params(); setcookie(session_name(),'',['expires'=>time()-42000,'path'=>$p['path'],'domain'=>$p['domain'],'secure'=>$p['secure'],'httponly'=>$p['httponly'],'samesite'=>$p['samesite']??'Lax']); } session_destroy(); redirect('/login'); }
}
