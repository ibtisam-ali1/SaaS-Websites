<?php
declare(strict_types=1);
final class ExamController{
 public function index():void{require_role(['super_admin','teacher']);$m=new Exam();$exams=$m->exams();$classes=(new Academic())->classes();require __DIR__.'/../views/exams/index.php';}
 public function createExam():void{require_role(['super_admin','teacher']);verify_csrf();$name=post_string('name',150);$classId=post_int('class_id');$date=post_string('exam_date',10);$max=post_float('max_marks');if($name===''||!$classId||!valid_date($date)||$max<=0){flash('error','Enter the examination name, class, date and maximum marks.');redirect('/exams');}try{$m=new Exam();$a=new Academic();if(!$a->classExists($classId)){throw new RuntimeException('Class not found.');}$subjects=$m->subjectsForClass($classId);if(!$subjects){flash('error','This class has no subjects yet. Add a subject or assign one in Academics first.');redirect('/exams');}$m->createExam($name,$classId,$date,$max);flash('success','Examination created. You can now enter marks.');}catch(Throwable $e){flash('error','Examination could not be created. Check the class and details.');}redirect('/exams');}
 public function updateExam():void{require_role(['super_admin','teacher']);verify_csrf();$id=post_int('id');$name=post_string('name',150);$classId=post_int('class_id');$date=post_string('exam_date',10);$max=post_float('max_marks');if(!$id||$name===''||!$classId||!valid_date($date)||$max<=0){flash('error','Invalid examination details.');redirect('/exams');}try{$m=new Exam();$old=$m->findExam($id);if(!$old)throw new RuntimeException('notfound');if((int)$old['class_id']!==$classId&&$m->markCount($id)>0)throw new RuntimeException('hasmarks');$m->updateExam($id,$name,$classId,$date,$max);flash('success','Examination updated.');}catch(Throwable $e){flash('error',$e->getMessage()==='hasmarks'?'This examination already has marks, so its class cannot be changed. Create a new examination for another class.':'Examination could not be updated.');}redirect('/exams');}
 public function deleteExam():void{require_role(['super_admin']);verify_csrf();try{(new Exam())->deleteExam(post_int('id'));flash('success','Examination and its marks were deleted.');}catch(Throwable $e){flash('error','Examination could not be deleted.');}redirect('/exams');}
 public function marks():void{require_role(['super_admin','teacher']);$m=new Exam();$examId=max(0,(int)($_GET['exam_id']??0));$exams=$m->exams();$selectedExam=$examId?$m->findExam($examId):null;$rows=$selectedExam?$m->marks($examId):[];require __DIR__.'/../views/exams/marks.php';}
 public function saveMarks():void{
  require_role(['super_admin','teacher']); verify_csrf();
  $examId=post_int('exam_id'); $marks=$_POST['mark']??[];
  if(!$examId||!is_array($marks)){flash('error','Choose an examination first.');redirect('/exams/marks');}
  $m=new Exam(); $exam=$m->findExam($examId);
  if(!$exam){flash('error','Examination not found.');redirect('/exams/marks');}
  $db=Database::connection(); $db->beginTransaction();
  try{
    $find=$db->prepare('SELECT id FROM exam_marks WHERE exam_id=? AND student_id=? AND subject_id=? LIMIT 1');
    $insert=$db->prepare('INSERT INTO exam_marks(exam_id,student_id,subject_id,marks_obtained,max_marks,grade,remarks) VALUES(?,?,?,?,?,?,?)');
    $update=$db->prepare('UPDATE exam_marks SET marks_obtained=?,max_marks=?,grade=?,remarks=? WHERE id=?');
    $delete=$db->prepare('DELETE FROM exam_marks WHERE exam_id=? AND student_id=? AND subject_id=?');
    $saved=0; $cleared=0;
    foreach($marks as $studentId=>$subjects){
      $sid=(int)$studentId; if(!is_array($subjects))continue;
      foreach($subjects as $subjectId=>$val){
        $subId=(int)$subjectId;
        if(!$m->validStudentSubject($examId,$sid,$subId))throw new RuntimeException('Invalid student or subject selection.');
        $subject=$m->oneSubject($subId); if(!$subject)throw new RuntimeException('Subject not found.');
        if(trim((string)$val)===''){$delete->execute([$examId,$sid,$subId]);$cleared++;continue;}
        if(!is_numeric($val))throw new RuntimeException('Enter valid numeric marks.');
        $max=(float)$subject['max_marks']; $obt=(float)$val;
        if($obt<0||$obt>$max)throw new RuntimeException('A mark is outside its allowed range.');
        $pct=$max>0?($obt/$max*100):0;
        $grade=$pct>=90?'A+':($pct>=80?'A':($pct>=70?'B':($pct>=60?'C':($pct>=50?'D':'F'))));
        $rawRemark=(string)($_POST['remarks'][$sid][$subId]??'');
        $remarks=function_exists('mb_substr')?mb_substr(trim($rawRemark),0,255):substr(trim($rawRemark),0,255);
        $find->execute([$examId,$sid,$subId]); $existing=$find->fetch();
        if($existing){$update->execute([$obt,$max,$grade,$remarks,(int)$existing['id']]);}
        else{$insert->execute([$examId,$sid,$subId,$obt,$max,$grade,$remarks]);}
        $saved++;
      }
    }
    $db->commit();
    flash('success',"Marks saved successfully. {$saved} mark(s) updated.".($cleared?' '.$cleared.' mark(s) cleared.':''));
  }catch(Throwable $e){
    if($db->inTransaction())$db->rollBack();
    error_log('[EduCore marks save] '.$e->getMessage().' | exam_id='.$examId);
    $message=$e->getMessage();
    if($message==='A mark is outside its allowed range.')$message='Enter marks between 0 and the subject maximum.';
    elseif($message==='Invalid student or subject selection.')$message='One of the selected students or subjects is not valid for this examination. Refresh the page and try again.';
    elseif($message==='Enter valid numeric marks.')$message='Please enter numbers only for marks.';
    elseif(str_contains(strtolower($message),'table')||str_contains(strtolower($message),'column')||str_contains(strtolower($message),'unknown'))$message='The marks table in the database is not ready. Run database/migration_v2_6.sql once, then try again.';
    else $message='Marks could not be saved. No partial changes were applied. Please check the database setup and try again.';
    flash('error',$message);
  }
  redirect('/exams/marks?exam_id='.$examId);
 }
 public function report():void{require_role(['super_admin','teacher','student','parent']);$studentId=max(0,(int)($_GET['student_id']??0));$examId=max(0,(int)($_GET['exam_id']??0));$user=auth_user();if(($user['role']??'')==='student')$studentId=(int)($user['student_id']??0);if(($user['role']??'')==='parent'){ $linked=(new User())->parentChildren((int)$user['id']); $allowed=false; foreach($linked as $child){if((int)$child['id']===$studentId){$allowed=true;break;}} if(!$allowed){$this->reportError('This student is not linked to your parent account.');return;}}if(!$studentId||!$examId){$this->reportError('Please choose a student and examination.');return;}$student=(new Student())->find($studentId);$m=new Exam();$exam=$m->findExam($examId);if(!$student||!$exam){$this->reportError('The selected record could not be found.');return;}if((int)$exam['class_id']!==(int)($student['class_id']??0)){$this->reportError('The selected examination belongs to a different class.');return;}$rows=$m->report($studentId,$examId);$total=$max=0;$entered=0;foreach($rows as $r){if($r['marks_obtained']!==null){$total+=(float)$r['marks_obtained'];$max+=(float)$r['max_marks'];$entered++;}}$subjectCount=count($rows);$complete=$subjectCount>0&&$entered===$subjectCount;$percentage=$max?round($total/$max*100,2):0;$gpa=$complete?($percentage>=90?4:($percentage>=80?3.5:($percentage>=70?3:($percentage>=60?2:($percentage>=50?1:0))))):null;require __DIR__.'/../views/exams/report.php';}
 private function oneSubject(int $id):?array{return $this->fetchSubject($id);}
 private function fetchSubject(int $id):?array{$s=Database::connection()->prepare('SELECT id,max_marks FROM subjects WHERE id=? LIMIT 1');$s->execute([$id]);return $s->fetch()?:null;}
 private function reportError(string $message):void{http_response_code(400);$errorMessage=$message;require __DIR__.'/../views/exams/report.php';}
}
