(() => {
  const root=document.documentElement;
  const key='educore-theme';
  const saved=localStorage.getItem(key);
  const system=matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';
  const apply=(theme)=>{root.dataset.theme=theme;root.style.colorScheme=theme;localStorage.setItem(key,theme);const b=document.getElementById('themeBtn');if(b){b.textContent=theme==='dark'?'☀':'☾';b.title=theme==='dark'?'Switch to light mode':'Switch to dark mode';}};
  apply(saved==='dark'||saved==='light'?saved:system);
  document.getElementById('themeBtn')?.addEventListener('click',()=>apply(root.dataset.theme==='dark'?'light':'dark'));
  document.getElementById('menuBtn')?.addEventListener('click',()=>document.getElementById('sidebar')?.classList.toggle('open'));
  document.querySelectorAll('.sidebar a').forEach(a=>a.addEventListener('click',()=>document.getElementById('sidebar')?.classList.remove('open')));
  document.querySelectorAll('form[data-confirm]').forEach(f=>f.addEventListener('submit',e=>{if(!window.confirm(f.dataset.confirm))e.preventDefault();}));

  const student=document.getElementById('reportStudent');
  const exam=document.getElementById('reportExam');
  const button=document.getElementById('reportButton');
  const hint=document.getElementById('selectionHint');
  const syncReport=()=>{
    if(!student||!exam)return;
    const classId=student.selectedOptions[0]?.dataset.class||'';
    let visibleCount=0;
    Array.from(exam.options).forEach((o,index)=>{
      if(index===0){o.hidden=false;return;}
      const compatible=!classId || !o.dataset.class || o.dataset.class===classId;
      o.hidden=!compatible;
      if(compatible)visibleCount++;
    });
    if(exam.value && exam.selectedOptions[0]?.hidden)exam.value='';
    const valid=!!student.value&&!!exam.value&&!exam.selectedOptions[0]?.hidden;
    if(button)button.disabled=!valid;
    if(hint){
      if(!student.value)hint.textContent='Choose a student first.';
      else if(!classId)hint.textContent='This student has no class assigned. Assign a class before generating a report card.';
      else if(!visibleCount)hint.textContent='No examination exists for this student’s class yet. Create one from the examination section above.';
      else hint.textContent=valid?'Ready — the selected student and examination match.':'Now choose a compatible examination.';
      hint.classList.toggle('ready',valid);
    }
  };
  student?.addEventListener('change',syncReport);
  exam?.addEventListener('change',syncReport);
  syncReport();

  const paymentInvoice=document.getElementById('paymentInvoice');
  const paymentAmount=document.getElementById('paymentAmount');
  const paymentBalance=document.getElementById('paymentBalance');
  const syncPayment=()=>{
    if(!paymentInvoice)return;
    const balance=parseFloat(paymentInvoice.selectedOptions[0]?.dataset.balance||'0');
    if(paymentAmount){
      paymentAmount.max=balance>0?balance:'';
      if(balance>0 && (!paymentAmount.value || parseFloat(paymentAmount.value)>balance))paymentAmount.value=balance.toFixed(2);
    }
    if(paymentBalance)paymentBalance.textContent=balance>0?`Remaining balance: PKR ${balance.toFixed(2)}`:'Select an invoice to see its balance.';
  };
  paymentInvoice?.addEventListener('change',syncPayment);
  syncPayment();


  const invoiceStructure=document.getElementById('invoiceStructure');
  const invoiceAmount=document.getElementById('invoiceAmount');
  const invoiceStudent=document.getElementById('invoiceStudent');
  const syncInvoice=()=>{
    if(!invoiceStructure||!invoiceAmount)return;
    const classId=invoiceStudent?.selectedOptions[0]?.dataset.class||'';
    Array.from(invoiceStructure.options).forEach((opt,i)=>{
      if(i===0){opt.hidden=false;return;}
      const feeClass=opt.dataset.class||'';
      opt.hidden=!!feeClass && !!classId && feeClass!==classId;
    });
    const selected=invoiceStructure.selectedOptions[0];
    if(selected?.hidden) invoiceStructure.value='0';
    const amount=invoiceStructure.selectedOptions[0]?.dataset.amount||'';
    if(amount) invoiceAmount.value=Number(amount).toFixed(2);
  };
  invoiceStudent?.addEventListener('change',syncInvoice);
  invoiceStructure?.addEventListener('change',syncInvoice);
  syncInvoice();
})();
