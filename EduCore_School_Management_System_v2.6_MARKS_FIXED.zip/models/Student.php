<?php
declare(strict_types=1);
final class Student extends BaseModel{
 public function all(string $q=''):array{$like='%'.$q.'%';return $this->fetchAll('SELECT s.*,c.name class_name,c.section FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.admission_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR s.email LIKE ? ORDER BY s.id DESC',[$like,$like,$like,$like]);}
 public function find(int $id):?array{return $this->one('SELECT s.*,c.name class_name,c.section FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=?',[$id]);}
 public function create(array $d):int{$s=$this->db->prepare('INSERT INTO students(admission_no,first_name,last_name,date_of_birth,gender,phone,email,address,class_id,enrollment_status,admission_date) VALUES(?,?,?,?,?,?,?,?,?,?,?)');$s->execute([$d['admission_no'],$d['first_name'],$d['last_name'],$d['date_of_birth']?:null,$d['gender'],$d['phone'],$d['email']?:null,$d['address'],$d['class_id']?:null,$d['enrollment_status'],$d['admission_date']]);return(int)$this->db->lastInsertId();}
 public function update(int $id,array $d):bool{return $this->execute('UPDATE students SET admission_no=?,first_name=?,last_name=?,date_of_birth=?,gender=?,phone=?,email=?,address=?,class_id=?,enrollment_status=?,admission_date=? WHERE id=?',[$d['admission_no'],$d['first_name'],$d['last_name'],$d['date_of_birth']?:null,$d['gender'],$d['phone'],$d['email']?:null,$d['address'],$d['class_id']?:null,$d['enrollment_status'],$d['admission_date'],$id]);}
 public function delete(int $id):bool{return $this->execute('DELETE FROM students WHERE id=?',[$id]);}
 public function updateStatus(int $id,string $status):bool{return $this->execute('UPDATE students SET enrollment_status=? WHERE id=?',[$status,$id]);}
 public function count():int{$r=$this->one('SELECT COUNT(*) c FROM students WHERE enrollment_status="active"');return(int)($r['c']??0);}
 public function attendanceRate():float{$r=$this->one('SELECT COALESCE(SUM(status IN ("Present","Late"))/NULLIF(COUNT(*),0)*100,0) rate FROM attendance');return(float)($r['rate']??0);}
}
