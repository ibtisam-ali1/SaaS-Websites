<?php
declare(strict_types=1);
abstract class BaseModel {
    protected PDO $db;
    public function __construct(){ $this->db=Database::connection(); }
    protected function one(string $sql,array $params=[]): ?array { $s=$this->db->prepare($sql); $s->execute($params); $r=$s->fetch(); return $r?:null; }
    protected function fetchAll(string $sql,array $params=[]): array { $s=$this->db->prepare($sql); $s->execute($params); return $s->fetchAll(); }
    protected function execute(string $sql,array $params=[]): bool { $s=$this->db->prepare($sql); return $s->execute($params); }
}
