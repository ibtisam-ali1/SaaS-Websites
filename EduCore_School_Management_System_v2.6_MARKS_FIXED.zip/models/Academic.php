<?php
declare(strict_types=1);
final class Academic extends BaseModel{
 public function classes():array{return $this->fetchAll('SELECT * FROM classes ORDER BY name,section,academic_year');}
 public function subjects():array{return $this->fetchAll('SELECT * FROM subjects ORDER BY name');}
 public function teachers():array{return $this->fetchAll('SELECT id,full_name,email FROM users WHERE role="teacher" AND status="active" ORDER BY full_name');}
 public function timetable():array{return $this->fetchAll('SELECT t.*,c.name class_name,c.section,s.name subject_name,u.full_name teacher_name FROM timetable t JOIN classes c ON c.id=t.class_id JOIN subjects s ON s.id=t.subject_id LEFT JOIN users u ON u.id=t.teacher_id ORDER BY FIELD(t.day_of_week,"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"),t.start_time');}
 public function lessonPlans():array{return $this->fetchAll('SELECT lp.*,s.name subject_name,c.name class_name,c.section,u.full_name teacher_name FROM lesson_plans lp JOIN subjects s ON s.id=lp.subject_id JOIN classes c ON c.id=lp.class_id LEFT JOIN users u ON u.id=lp.teacher_id ORDER BY lp.lesson_date DESC,lp.id DESC LIMIT 200');}
 public function allocationExists(int $classId,int $subjectId):bool{return (bool)$this->one('SELECT id FROM class_subjects WHERE class_id=? AND subject_id=?',[$classId,$subjectId]);}
 public function classExists(int $id):bool{return (bool)$this->one('SELECT id FROM classes WHERE id=?',[$id]);}
 public function subjectExists(int $id):bool{return (bool)$this->one('SELECT id FROM subjects WHERE id=?',[$id]);}
 public function teacherExists(int $id):bool{return (bool)$this->one('SELECT id FROM users WHERE id=? AND role="teacher" AND status="active"',[$id]);}
 public function createTimetable(int $c,int $s,?int $t,string $d,string $st,string $et,string $r):bool{return $this->execute('INSERT INTO timetable(class_id,subject_id,teacher_id,day_of_week,start_time,end_time,room) VALUES(?,?,?,?,?,?,?)',[$c,$s,$t,$d,$st,$et,$r]);}
 public function updateTimetable(int $id,int $c,int $s,?int $t,string $d,string $st,string $et,string $r):bool{return $this->execute('UPDATE timetable SET class_id=?,subject_id=?,teacher_id=?,day_of_week=?,start_time=?,end_time=?,room=? WHERE id=?',[$c,$s,$t,$d,$st,$et,$r,$id]);}
 public function timetableConflict(int $classId,?int $teacherId,string $day,string $start,string $end,?int $ignoreId=null):bool{
  $sql='SELECT id FROM timetable WHERE day_of_week=? AND start_time < ? AND end_time > ? AND (class_id=? OR (? IS NOT NULL AND teacher_id=?))';
  $p=[$day,$end,$start,$classId,$teacherId,$teacherId]; if($ignoreId){$sql.=' AND id<>?';$p[]=$ignoreId;} return (bool)$this->one($sql,$p);
 }
 public function deleteTimetable(int $id):bool{return $this->execute('DELETE FROM timetable WHERE id=?',[$id]);}
 public function createLesson(int $c,int $s,?int $t,string $d,string $topic,string $o,string $n):bool{return $this->execute('INSERT INTO lesson_plans(class_id,subject_id,teacher_id,lesson_date,topic,objectives,notes) VALUES(?,?,?,?,?,?,?)',[$c,$s,$t,$d,$topic,$o,$n]);}
 public function updateLesson(int $id,int $c,int $s,?int $t,string $d,string $topic,string $o,string $n):bool{return $this->execute('UPDATE lesson_plans SET class_id=?,subject_id=?,teacher_id=?,lesson_date=?,topic=?,objectives=?,notes=? WHERE id=?',[$c,$s,$t,$d,$topic,$o,$n,$id]);}
 public function deleteLesson(int $id):bool{return $this->execute('DELETE FROM lesson_plans WHERE id=?',[$id]);}
 public function createClass(string $n,string $s,string $y,string $r):bool{ $this->db->beginTransaction(); try{ $this->execute('INSERT INTO classes(name,section,academic_year,room) VALUES(?,?,?,?)',[$n,$s,$y,$r]); $classId=(int)$this->db->lastInsertId(); $this->execute('INSERT IGNORE INTO class_subjects(class_id,subject_id) SELECT ?,id FROM subjects',[$classId]); $this->db->commit(); return true; }catch(Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;} }
 public function updateClass(int $id,string $n,string $s,string $y,string $r):bool{return $this->execute('UPDATE classes SET name=?,section=?,academic_year=?,room=? WHERE id=?',[$n,$s,$y,$r,$id]);}
 public function classHasHistory(int $id):bool{return (bool)$this->one('SELECT id FROM students WHERE class_id=? LIMIT 1',[$id]) || (bool)$this->one('SELECT id FROM enrollments WHERE class_id=? LIMIT 1',[$id]) || (bool)$this->one('SELECT id FROM exams WHERE class_id=? LIMIT 1',[$id]) || (bool)$this->one('SELECT id FROM timetable WHERE class_id=? LIMIT 1',[$id]) || (bool)$this->one('SELECT id FROM lesson_plans WHERE class_id=? LIMIT 1',[$id]);}
 public function deleteClass(int $id):bool{return $this->execute('DELETE FROM classes WHERE id=?',[$id]);}
 public function createSubject(string $c,string $n,float $m):bool{ $this->db->beginTransaction(); try{$this->execute('INSERT INTO subjects(code,name,max_marks) VALUES(?,?,?)',[$c,$n,$m]);$sid=(int)$this->db->lastInsertId();$this->execute('INSERT IGNORE INTO class_subjects(class_id,subject_id) SELECT id,? FROM classes',[$sid]);$this->db->commit();return true;}catch(Throwable $e){if($this->db->inTransaction())$this->db->rollBack();throw $e;} }
 public function updateSubject(int $id,string $c,string $n,float $m):bool{return $this->execute('UPDATE subjects SET code=?,name=?,max_marks=? WHERE id=?',[$c,$n,$m,$id]);}
 public function subjectHasHistory(int $id):bool{return (bool)$this->one('SELECT id FROM exam_marks WHERE subject_id=? LIMIT 1',[$id]) || (bool)$this->one('SELECT id FROM timetable WHERE subject_id=? LIMIT 1',[$id]) || (bool)$this->one('SELECT id FROM lesson_plans WHERE subject_id=? LIMIT 1',[$id]);}
 public function deleteSubject(int $id):bool{return $this->execute('DELETE FROM subjects WHERE id=?',[$id]);}
 public function allocations():array{return $this->fetchAll('SELECT cs.class_id,cs.subject_id,c.name class_name,c.section,s.name subject_name,s.code FROM class_subjects cs JOIN classes c ON c.id=cs.class_id JOIN subjects s ON s.id=cs.subject_id ORDER BY c.name,c.section,s.name');}
 public function createAllocation(int $classId,int $subjectId):bool{return $this->execute('INSERT INTO class_subjects(class_id,subject_id) VALUES(?,?)',[$classId,$subjectId]);}
 public function deleteAllocation(int $classId,int $subjectId):bool{return $this->execute('DELETE FROM class_subjects WHERE class_id=? AND subject_id=?',[$classId,$subjectId]);}
 public function createTeacher(string $name,string $email,string $password):bool{return $this->execute('INSERT INTO users(full_name,email,password_hash,role,status,student_id) VALUES(?,?,?,"teacher","active",NULL)',[$name,$email,password_hash($password,PASSWORD_DEFAULT)]);}
 public function updateTeacher(int $id,string $name,string $email,string $password):bool{if($password!==''){return $this->execute('UPDATE users SET full_name=?,email=?,password_hash=? WHERE id=? AND role="teacher"',[$name,$email,password_hash($password,PASSWORD_DEFAULT),$id]);}return $this->execute('UPDATE users SET full_name=?,email=? WHERE id=? AND role="teacher"',[$name,$email,$id]);}
 public function deleteTeacher(int $id):bool{return $this->execute('UPDATE users SET status="inactive" WHERE id=? AND role="teacher"',[$id]);}
}
