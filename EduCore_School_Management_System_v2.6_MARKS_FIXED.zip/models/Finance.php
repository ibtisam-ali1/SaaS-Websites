<?php
declare(strict_types=1);
final class Finance extends BaseModel{
 public function structures():array{return $this->fetchAll('SELECT fs.*,c.name class_name,c.section FROM fee_structures fs LEFT JOIN classes c ON c.id=fs.class_id ORDER BY fs.id DESC');}
 public function structure(int $id):?array{return $this->one('SELECT * FROM fee_structures WHERE id=?',[$id]);}
 public function createStructure(?int $classId,string $name,float $amount,string $frequency):bool{return $this->execute('INSERT INTO fee_structures(class_id,name,amount,frequency) VALUES(?,?,?,?)',[$classId,$name,$amount,$frequency]);}
 public function updateStructure(int $id,?int $classId,string $name,float $amount,string $frequency):bool{return $this->execute('UPDATE fee_structures SET class_id=?,name=?,amount=?,frequency=? WHERE id=?',[$classId,$name,$amount,$frequency,$id]);}
 public function deleteStructure(int $id):bool{return $this->execute('DELETE FROM fee_structures WHERE id=?',[$id]);}
 public function invoices():array{return $this->fetchAll('SELECT i.*,CONCAT(s.first_name," ",s.last_name) student_name,s.admission_no,COALESCE(SUM(p.amount),0) paid,GREATEST(i.amount-COALESCE(SUM(p.amount),0),0) balance FROM invoices i JOIN students s ON s.id=i.student_id LEFT JOIN payments p ON p.invoice_id=i.id GROUP BY i.id ORDER BY i.due_date DESC,i.id DESC');}
 public function openInvoices():array{return $this->fetchAll('SELECT i.id,i.invoice_no,i.amount,i.due_date,CONCAT(s.first_name," ",s.last_name) student_name,s.admission_no,GREATEST(i.amount-COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.invoice_id=i.id),0),0) balance FROM invoices i JOIN students s ON s.id=i.student_id WHERE i.status IN ("Unpaid","Partially Paid") ORDER BY i.due_date,i.id');}
 public function payments():array{return $this->fetchAll('SELECT p.*,i.invoice_no,CONCAT(s.first_name," ",s.last_name) student_name FROM payments p JOIN invoices i ON i.id=p.invoice_id JOIN students s ON s.id=i.student_id ORDER BY p.payment_date DESC,p.id DESC');}
 public function totals():array{return $this->one('SELECT COALESCE((SELECT SUM(amount) FROM invoices WHERE status<>"Cancelled"),0) billed,COALESCE((SELECT SUM(amount) FROM payments),0) collected');}
}
