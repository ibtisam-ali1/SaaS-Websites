<?php
final class User extends BaseModel {
 public function findByEmail(string $email): ?array { return $this->one('SELECT * FROM users WHERE email=? AND status="active" LIMIT 1',[$email]); }
 public function count(): int { return (int)$this->one('SELECT COUNT(*) c FROM users WHERE status="active"')['c']; }
 public function parentChildren(int $parentId):array{return $this->fetchAll('SELECT s.id,s.admission_no,CONCAT(s.first_name," ",s.last_name) student_name,s.class_id,c.name class_name,c.section FROM parent_students ps JOIN students s ON s.id=ps.student_id LEFT JOIN classes c ON c.id=s.class_id WHERE ps.parent_id=? AND s.enrollment_status="active" ORDER BY s.first_name,s.last_name',[$parentId]);}
}
