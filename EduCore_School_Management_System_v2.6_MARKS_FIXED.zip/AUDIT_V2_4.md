# EduCore v2.4 Audit Checklist

## Static checks completed
- PHP syntax checked for every PHP file: PASS
- JavaScript syntax checked with Node: PASS
- No TODO/FIXME/var_dump/print_r/phpinfo debug calls found in application PHP/JS
- Sensitive application directories deny direct web access via `.htaccess`
- Directory indexing disabled
- State-changing logout is POST + CSRF protected
- Forms use CSRF tokens
- Database access uses PDO prepared statements
- Output is escaped with `htmlspecialchars`

## Academic integrity fixes
- Attendance requires class selection and defaults to `Not marked`; it no longer silently marks every student Present.
- Attendance writes are restricted to students belonging to the selected class.
- Marks are saved only for the selected examination's class and assigned subjects.
- Blank mark fields clear an existing mark rather than converting blank input to zero.
- Subject maximum marks come from the subject definition and are not editable per mark row.
- Marks are transactionally saved; invalid rows do not produce partial saves.
- Grades use a clear A+/A/B/C/D/F scale.
- Report-card percentage/GPA is final only after every configured subject has a mark.
- An examination class cannot be changed after marks exist.
- Timetable prevents overlapping class or teacher lessons.
- Timetable/lesson-plan records require valid class, subject and teacher selections.
- Class and subject deletion is blocked when academic history depends on them.
- Student deletion is converted to archive/inactive behavior to preserve financial and academic history.

## Finance fixes
- Fee structures are manageable by Super Admin.
- Invoice creation can use a saved fee structure or a custom amount.
- Payment entry automatically shows the outstanding balance.
- Overpayment is rejected inside a transaction.
- Existing invoices remain unchanged when a fee structure is removed.

## Privacy/RBAC fixes
- Students page is not shown to Student/Parent roles.
- Student users can only view their own report card.
- Parent report access requires an explicit `parent_students` relationship.
- School-wide finance totals are not shown on the parent dashboard.

## Integration note
The package was statically validated in the build environment. Live MySQL integration must be run against the user's XAMPP `school_management` database after importing the supplied migration, because the build environment does not contain the user's local MySQL data.
